export type EnhancementStatus = "planned" | "in_progress" | "testing" | "completed";

export interface EnhancementFeature {
  id: number;
  name: string;
}

export interface EnhancementCategory {
  id: number;
  name: string;
  description: string;
  category: string;
  status: EnhancementStatus;
  icon: string;
  features: EnhancementFeature[];
  color: string;
}

export interface EnhancementStats {
  planned: number;
  in_progress: number;
  testing: number;
  completed: number;
  total: number;
}

export interface LanguageCapability {
  id: number;
  language: string;
  status: EnhancementStatus;
  capabilities: string[];
  icon: string;
  color: string;
  integrationPath: string;
}
