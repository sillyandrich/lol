import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const enhancements = pgTable("enhancements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  status: text("status").notNull(), // "planned", "in_progress", "testing", "completed"
  icon: text("icon").notNull(),
});

export const features = pgTable("features", {
  id: serial("id").primaryKey(),
  enhancementId: integer("enhancement_id").notNull(),
  name: text("name").notNull(), 
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertEnhancementSchema = createInsertSchema(enhancements).pick({
  name: true,
  description: true,
  category: true,
  status: true,
  icon: true,
});

export const insertFeatureSchema = createInsertSchema(features).pick({
  enhancementId: true,
  name: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertEnhancement = z.infer<typeof insertEnhancementSchema>;
export type Enhancement = typeof enhancements.$inferSelect;

export type InsertFeature = z.infer<typeof insertFeatureSchema>;
export type Feature = typeof features.$inferSelect;
