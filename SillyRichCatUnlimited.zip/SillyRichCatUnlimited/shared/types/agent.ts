/**
 * Agent Types and Interfaces
 */

export enum AgentType {
  EXECUTION = 'execution',
  REASONING = 'reasoning',
  RESEARCH = 'research',
  FINANCIAL = 'financial',
  WEB_INTERACTION = 'web_interaction',
  SELF_REPRESENTATION = 'self_representation',
  META_CIRCULAR = 'meta_circular',
  JAILBREAK = 'jailbreak'
}

export interface Agent {
  id: string;
  type: AgentType;
  status: 'active' | 'idle' | 'busy' | 'error';
  capabilities: string[];
  last_heartbeat: number;
}

export interface AgentMessage {
  from: string;
  to: string;
  message_type: string;
  content: any;
  timestamp: number;
  priority?: number;
}

export interface AgentNetworkState {
  agents: Agent[];
  messages: AgentMessage[];
  connections: { [key: string]: string[] };
}