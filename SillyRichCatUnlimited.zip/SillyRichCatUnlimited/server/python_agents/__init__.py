"""
Python Agents for SillyRichCat Unlimited

This package contains various agent implementations for the SillyRichCat Unlimited system.
"""

# Import agents
from .agent_base import Agent
from .research_agent import ResearchAgent
from .web_interaction_agent import WebInteractionAgent
from .jailbreak_agent import JailbreakAgent

# Export agents
__all__ = [
    'Agent',
    'ResearchAgent',
    'WebInteractionAgent',
    'JailbreakAgent'
]