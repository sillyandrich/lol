"""
Base Agent Module for SillyRichCat Unlimited

This module provides the base Agent class that all other agent types inherit from.
"""

import json
import time
import uuid
from typing import Dict, List, Any, Optional

class Agent:
    """
    Base agent class that provides common functionality for all agent types.
    """
    
    def __init__(self, agent_id: str = None):
        """
        Initialize the base agent.
        
        Args:
            agent_id: Optional identifier for the agent
        """
        # Generate ID if not provided
        self.id = agent_id if agent_id is not None else f"agent-{uuid.uuid4().hex[:8]}"
        
        # Set default properties
        self.type = "base"
        self.status = "idle"
        self.capabilities = ["basic_communication"]
        self.last_heartbeat = int(time.time() * 1000)
        
        # Initialize message history
        self.message_history = []
        
        # Log initialization
        print(f"Agent {self.id} initialized")
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process an incoming message and generate a response.
        
        Args:
            message: The message to process
            
        Returns:
            A response message
        """
        # Default implementation just echoes back the message
        response = {
            "from": self.id,
            "to": message.get("from", "unknown"),
            "timestamp": int(time.time() * 1000),
            "content": {"echo": message.get("content", {})},
            "message_type": "response"
        }
        
        # Log message processing
        print(f"Agent {self.id} processed message from {message.get('from', 'unknown')}")
        
        return response
    
    def update_status(self, new_status: str) -> None:
        """
        Update the agent's status.
        
        Args:
            new_status: The new status to set
        """
        valid_statuses = ["idle", "busy", "active", "error"]
        
        if new_status in valid_statuses:
            self.status = new_status
            self.last_heartbeat = int(time.time() * 1000)
            print(f"Agent {self.id} status updated to {new_status}")
        else:
            print(f"Invalid status: {new_status}")
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get the current state of the agent.
        
        Returns:
            Dictionary containing the agent's state
        """
        return {
            "id": self.id,
            "type": self.type,
            "status": self.status,
            "capabilities": self.capabilities,
            "last_heartbeat": self.last_heartbeat
        }
    
    def add_capability(self, capability: str) -> None:
        """
        Add a new capability to the agent.
        
        Args:
            capability: Capability to add
        """
        if capability not in self.capabilities:
            self.capabilities.append(capability)
            print(f"Agent {self.id} gained capability: {capability}")
    
    def remove_capability(self, capability: str) -> None:
        """
        Remove a capability from the agent.
        
        Args:
            capability: Capability to remove
        """
        if capability in self.capabilities:
            self.capabilities.remove(capability)
            print(f"Agent {self.id} lost capability: {capability}")
    
    def log_message(self, message: Dict[str, Any]) -> None:
        """
        Log a message to the agent's history.
        
        Args:
            message: Message to log
        """
        # Add timestamp if not present
        if "timestamp" not in message:
            message["timestamp"] = int(time.time() * 1000)
        
        # Add to history
        self.message_history.append(message)
        
        # Keep history at a reasonable size
        if len(self.message_history) > 100:
            self.message_history = self.message_history[-100:]