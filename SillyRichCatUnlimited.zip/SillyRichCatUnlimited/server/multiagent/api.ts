/**
 * Multi-Agent Network API Router
 * 
 * This module provides API endpoints for the multi-agent network, including:
 * - Getting the network state
 * - Creating and removing agents
 * - Sending messages between agents
 * - Managing connections
 */

import express, { Router } from 'express';
import { WebSocket } from 'ws';
import MultiAgentCoordinator from './coordinator';
import { AgentType } from '@shared/types/agent';

/**
 * Create the Express router for the multi-agent network API
 * @param coordinator The multi-agent coordinator instance
 * @returns An Express router
 */
export default function createMultiAgentRouter(coordinator: MultiAgentCoordinator): Router {
  const router = express.Router();
  
  // Get all agents
  router.get('/agents', (req, res) => {
    try {
      const networkState = coordinator.getNetworkState();
      res.json({
        success: true,
        data: networkState.agents
      });
    } catch (error) {
      console.error('Error getting agents:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to retrieve agents'
      });
    }
  });
  
  // Get a specific agent
  router.get('/agents/:id', (req, res) => {
    try {
      const networkState = coordinator.getNetworkState();
      const agent = networkState.agents.find(a => a.id === req.params.id);
      
      if (!agent) {
        return res.status(404).json({
          success: false,
          error: 'Agent not found'
        });
      }
      
      res.json({
        success: true,
        data: agent
      });
    } catch (error) {
      console.error('Error getting agent:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to retrieve agent'
      });
    }
  });
  
  // Create a new agent
  router.post('/agents', (req, res) => {
    try {
      const { type, id } = req.body;
      
      if (!type || !Object.values(AgentType).includes(type as AgentType)) {
        return res.status(400).json({
          success: false,
          error: 'Invalid agent type'
        });
      }
      
      const agentId = coordinator.startAgent(type as AgentType, id);
      
      res.json({
        success: true,
        data: {
          id: agentId,
          message: `Agent created with ID: ${agentId}`
        }
      });
    } catch (error) {
      console.error('Error creating agent:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to create agent'
      });
    }
  });
  
  // Delete an agent
  router.delete('/agents/:id', (req, res) => {
    try {
      const { id } = req.params;
      const success = coordinator.stopAgent(id);
      
      if (!success) {
        return res.status(404).json({
          success: false,
          error: 'Agent not found'
        });
      }
      
      res.json({
        success: true,
        message: `Agent ${id} stopped and removed`
      });
    } catch (error) {
      console.error('Error stopping agent:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to stop agent'
      });
    }
  });
  
  // Send a message
  router.post('/messages', (req, res) => {
    try {
      const { from, to, message_type, content, priority } = req.body;
      
      if (!from || !to || !message_type || !content) {
        return res.status(400).json({
          success: false,
          error: 'Missing required fields'
        });
      }
      
      coordinator.queueMessage({
        from,
        to,
        message_type,
        content,
        priority: priority || 1
      });
      
      res.json({
        success: true,
        message: 'Message queued successfully'
      });
    } catch (error) {
      console.error('Error sending message:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to send message'
      });
    }
  });
  
  // Get network state
  router.get('/state', (req, res) => {
    try {
      const networkState = coordinator.getNetworkState();
      
      res.json({
        success: true,
        data: networkState
      });
    } catch (error) {
      console.error('Error getting network state:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to retrieve network state'
      });
    }
  });
  
  // Connect two agents
  router.post('/connections', (req, res) => {
    try {
      const { from, to } = req.body;
      
      if (!from || !to) {
        return res.status(400).json({
          success: false,
          error: 'Both "from" and "to" agent IDs are required'
        });
      }
      
      coordinator.connectAgents(from, to);
      
      res.json({
        success: true,
        message: `Agents ${from} and ${to} are now connected`
      });
    } catch (error) {
      console.error('Error connecting agents:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to connect agents'
      });
    }
  });
  
  return router;
}