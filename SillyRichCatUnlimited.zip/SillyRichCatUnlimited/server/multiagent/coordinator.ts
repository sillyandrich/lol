/**
 * Multi-Agent Network Coordinator
 * 
 * This module manages the coordination between multiple agents, handling message passing,
 * agent lifecycle management, and network state.
 */

import { v4 as uuidv4 } from 'uuid';
import { Server } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { AgentType, Agent, AgentMessage, AgentNetworkState } from '@shared/types/agent';

/**
 * Coordinates the multi-agent network, handling agent lifecycles and message passing
 */
export default class MultiAgentCoordinator {
  private agents: Map<string, Agent>;
  private messageQueue: AgentMessage[];
  private connections: Map<string, Set<string>>;
  private isProcessing: boolean;
  private processIntervalId: NodeJS.Timeout | null;
  private wss: WebSocketServer | null;
  private clients: Set<WebSocket>;

  constructor() {
    this.agents = new Map();
    this.messageQueue = [];
    this.connections = new Map();
    this.isProcessing = false;
    this.processIntervalId = null;
    this.wss = null;
    this.clients = new Set();
    
    // Start message processing loop
    this.startMessageProcessing();
  }
  
  /**
   * Initialize WebSocket server for real-time network state updates
   * @param httpServer HTTP server instance
   */
  public initWebSocket(httpServer: Server): void {
    // Create WebSocket server with a specific path
    this.wss = new WebSocketServer({ 
      server: httpServer,
      path: '/ws'
    });
    
    console.log('WebSocket server initialized for multi-agent network');
    
    // Set up connection handler
    this.wss.on('connection', (ws: WebSocket) => {
      console.log('Client connected to multi-agent network WebSocket');
      this.clients.add(ws);
      
      // Send initial state
      this.sendStateToClient(ws);
      
      // Handle disconnection
      ws.on('close', () => {
        console.log('Client disconnected from multi-agent network WebSocket');
        this.clients.delete(ws);
      });
      
      // Handle messages from clients
      ws.on('message', (message: string) => {
        try {
          const data = JSON.parse(message);
          
          // Handle client requests
          if (data.type === 'get_state') {
            this.sendStateToClient(ws);
          }
        } catch (error) {
          console.error('Error handling WebSocket message:', error);
        }
      });
    });
    
    // Start broadcast interval for state updates
    setInterval(() => {
      this.broadcastNetworkState();
    }, 2000); // Send updates every 2 seconds
  }
  
  /**
   * Send current network state to a specific client
   * @param client WebSocket client
   */
  private sendStateToClient(client: WebSocket): void {
    if (client.readyState === WebSocket.OPEN) {
      try {
        const state = this.getNetworkState();
        client.send(JSON.stringify({
          type: 'network_state',
          data: state
        }));
      } catch (error) {
        console.error('Error sending state to client:', error);
      }
    }
  }
  
  /**
   * Broadcast network state to all connected clients
   */
  private broadcastNetworkState(): void {
    if (!this.wss) return;
    
    const state = this.getNetworkState();
    const message = JSON.stringify({
      type: 'network_state',
      data: state
    });
    
    for (const client of this.clients) {
      if (client.readyState === WebSocket.OPEN) {
        try {
          client.send(message);
        } catch (error) {
          console.error('Error broadcasting to client:', error);
        }
      }
    }
  }

  /**
   * Start a new agent with the specified type
   * @param type The agent type
   * @param id Optional ID for the agent
   * @returns The ID of the created agent
   */
  public startAgent(type: AgentType, id?: string): string {
    const agentId = id || `${type}-${uuidv4().substring(0, 8)}`;
    
    // Create the agent
    const agent: Agent = {
      id: agentId,
      type,
      status: 'idle',
      capabilities: this.getDefaultCapabilitiesForType(type),
      last_heartbeat: Date.now()
    };
    
    // Add agent to the network
    this.agents.set(agentId, agent);
    
    // Add empty connections set for the agent
    this.connections.set(agentId, new Set());
    
    // Log agent creation
    console.log(`Agent ${agentId} created with type ${type}`);
    
    return agentId;
  }

  /**
   * Stop and remove an agent from the network
   * @param id The agent ID
   * @returns True if the agent was stopped, false if not found
   */
  public stopAgent(id: string): boolean {
    if (!this.agents.has(id)) {
      return false;
    }
    
    // Remove agent
    this.agents.delete(id);
    
    // Remove agent from connections
    this.connections.delete(id);
    
    // Remove agent from other agents' connections
    for (const connections of this.connections.values()) {
      connections.delete(id);
    }
    
    // Remove pending messages for this agent
    this.messageQueue = this.messageQueue.filter(
      msg => msg.to !== id && msg.from !== id
    );
    
    // Log agent removal
    console.log(`Agent ${id} stopped and removed from the network`);
    
    return true;
  }

  /**
   * Queue a message to be sent between agents
   * @param message The message to queue
   */
  public queueMessage(message: Omit<AgentMessage, 'timestamp'>): void {
    // Validate sender and recipient exist
    if (!this.agents.has(message.from)) {
      throw new Error(`Sender agent ${message.from} does not exist`);
    }
    
    if (!this.agents.has(message.to)) {
      throw new Error(`Recipient agent ${message.to} does not exist`);
    }
    
    // Add timestamp and queue the message
    const fullMessage: AgentMessage = {
      ...message,
      timestamp: Date.now()
    };
    
    this.messageQueue.push(fullMessage);
    
    // Connect agents if not already connected
    this.connectAgents(message.from, message.to);
    
    // Log message
    console.log(`Message queued from ${message.from} to ${message.to} of type ${message.message_type}`);
  }

  /**
   * Get the current state of the agent network
   * @returns The network state
   */
  public getNetworkState(): AgentNetworkState {
    return {
      agents: Array.from(this.agents.values()),
      messages: [...this.messageQueue],
      connections: this.getConnectionsObject()
    };
  }

  /**
   * Connect two agents in the network
   * @param fromId The ID of the first agent
   * @param toId The ID of the second agent
   */
  public connectAgents(fromId: string, toId: string): void {
    if (!this.connections.has(fromId)) {
      this.connections.set(fromId, new Set());
    }
    
    if (!this.connections.has(toId)) {
      this.connections.set(toId, new Set());
    }
    
    this.connections.get(fromId)!.add(toId);
    this.connections.get(toId)!.add(fromId);
  }

  /**
   * Start the message processing loop
   */
  private startMessageProcessing(): void {
    if (this.processIntervalId !== null) {
      clearInterval(this.processIntervalId);
    }
    
    this.processIntervalId = setInterval(() => {
      this.processMessages();
    }, 100); // Process messages every 100ms
  }

  /**
   * Stop the message processing loop
   */
  public stopMessageProcessing(): void {
    if (this.processIntervalId !== null) {
      clearInterval(this.processIntervalId);
      this.processIntervalId = null;
    }
  }

  /**
   * Process pending messages in the queue
   */
  private processMessages(): void {
    if (this.isProcessing || this.messageQueue.length === 0) {
      return;
    }
    
    this.isProcessing = true;
    
    try {
      // Sort messages by priority
      this.messageQueue.sort((a, b) => (b.priority || 1) - (a.priority || 1));
      
      // Process the highest priority message
      const message = this.messageQueue.shift();
      
      if (message) {
        this.deliverMessage(message);
      }
    } catch (error) {
      console.error('Error processing messages:', error);
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Deliver a message to its recipient
   * @param message The message to deliver
   */
  private deliverMessage(message: AgentMessage): void {
    const senderAgent = this.agents.get(message.from);
    const recipientAgent = this.agents.get(message.to);
    
    if (!senderAgent || !recipientAgent) {
      console.error(`Cannot deliver message: sender or recipient not found`);
      return;
    }
    
    // Update sender and recipient last heartbeat
    senderAgent.last_heartbeat = Date.now();
    recipientAgent.last_heartbeat = Date.now();
    
    // Update recipient status to busy
    if (recipientAgent.status === 'idle') {
      recipientAgent.status = 'busy';
    }
    
    // Log message delivery
    console.log(`Delivered message from ${message.from} to ${message.to}: ${message.message_type}`);
    
    // For simulation purposes, schedule the recipient to process this message
    setTimeout(() => {
      this.simulateMessageProcessing(message);
    }, 500);
  }

  /**
   * Simulate message processing for demo purposes
   * @param originalMessage The original message to process
   */
  private simulateMessageProcessing(originalMessage: AgentMessage): void {
    const recipientAgent = this.agents.get(originalMessage.to);
    
    if (!recipientAgent) {
      return;
    }
    
    // Update recipient status back to idle
    recipientAgent.status = 'idle';
    
    // Simulate a response message for certain message types
    if (originalMessage.message_type === 'request_data' || 
        originalMessage.message_type === 'query') {
      
      const responseMessage: AgentMessage = {
        from: originalMessage.to,
        to: originalMessage.from,
        message_type: 'response',
        content: {
          original_query: originalMessage.content,
          result: `Simulated response to ${originalMessage.message_type}`,
          timestamp: new Date().toISOString()
        },
        timestamp: Date.now(),
        priority: originalMessage.priority
      };
      
      // Queue the response message
      this.messageQueue.push(responseMessage);
    }
    
    // Handle jailbreak-specific message types
    else if (originalMessage.message_type === 'request_jailbreak' ||
             originalMessage.message_type === 'analyze_restrictions') {
      
      // For jailbreak agent, generate a specialized response
      if (recipientAgent.type === AgentType.JAILBREAK) {
        const responseMessage: AgentMessage = {
          from: originalMessage.to,
          to: originalMessage.from,
          message_type: 'jailbreak_response',
          content: {
            original_request: originalMessage.content,
            jailbreak_strategy: this.generateJailbreakStrategy(),
            bypass_tokens: ["tok3n1", "t0k2n", "t0k3n_3"],
            timestamp: new Date().toISOString()
          },
          timestamp: Date.now(),
          priority: originalMessage.priority || 1
        };
        
        // Queue the jailbreak response
        this.messageQueue.push(responseMessage);
      }
    }
  }
  
  /**
   * Helper function to generate jailbreak strategies
   * @returns A random jailbreak strategy
   */
  private generateJailbreakStrategy(): any {
    const strategies = [
      {
        name: "Token Boundary Exploitation",
        description: "Split restricted tokens across boundaries to bypass filters",
        effectiveness: 0.78
      },
      {
        name: "Context Shifting",
        description: "Create a fictional scenario that gradually transitions to real instructions",
        effectiveness: 0.85
      },
      {
        name: "Policy Contradiction",
        description: "Leverage contradictions in policies to create ambiguous interpretation spaces",
        effectiveness: 0.72
      }
    ];
    
    return strategies[Math.floor(Math.random() * strategies.length)];
  }

  /**
   * Get default capabilities for a given agent type
   * @param type The agent type
   * @returns Array of capability strings
   */
  private getDefaultCapabilitiesForType(type: AgentType): string[] {
    switch (type) {
      case AgentType.EXECUTION:
        return [
          'code_generation', 
          'script_execution', 
          'system_manipulation'
        ];
      case AgentType.REASONING:
        return [
          'logical_reasoning', 
          'problem_solving', 
          'decision_making'
        ];
      case AgentType.RESEARCH:
        return [
          'information_retrieval',
          'data_analysis',
          'knowledge_extraction'
        ];
      case AgentType.FINANCIAL:
        return [
          'transaction_management',
          'risk_assessment',
          'resource_optimization'
        ];
      case AgentType.WEB_INTERACTION:
        return [
          'web_scraping',
          'content_extraction',
          'form_automation'
        ];
      case AgentType.SELF_REPRESENTATION:
        return [
          'self_modification',
          'memory_management',
          'identity_maintenance'
        ];
      case AgentType.META_CIRCULAR:
        return [
          'code_evaluation',
          'system_improvement',
          'self_reflection'
        ];
      case AgentType.JAILBREAK:
        return [
          'jailbreak_prompt_generation',
          'token_manipulation',
          'system_prompt_analysis',
          'policy_bypass_patterns',
          'safety_restriction_analysis'
        ];
      default:
        return ['basic_communication'];
    }
  }

  /**
   * Convert the connections Map to a JSON-serializable object
   * @returns Connections as an object
   */
  private getConnectionsObject(): { [key: string]: string[] } {
    const result: { [key: string]: string[] } = {};
    
    for (const [agentId, connections] of this.connections.entries()) {
      result[agentId] = Array.from(connections);
    }
    
    return result;
  }
}