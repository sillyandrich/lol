import express from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { enhancementData, languageData } from "../client/src/lib/data";
import MultiAgentCoordinator from "./multiagent/coordinator";
import createMultiAgentRouter from "./multiagent/api";
import { AgentType } from "@shared/types/agent";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();
  
  // Get all enhancements
  apiRouter.get("/enhancements", async (_req, res) => {
    try {
      // This would normally fetch from a database, but we're using static data for this demo
      res.json(enhancementData);
    } catch (error) {
      console.error("Error fetching enhancements:", error);
      res.status(500).json({ message: "Failed to fetch enhancements" });
    }
  });

  // Get stats
  apiRouter.get("/stats", async (_req, res) => {
    try {
      const stats = {
        planned: enhancementData.filter(e => e.status === "planned").length,
        in_progress: enhancementData.filter(e => e.status === "in_progress").length,
        testing: enhancementData.filter(e => e.status === "testing").length,
        completed: enhancementData.filter(e => e.status === "completed").length,
        total: enhancementData.length
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Get language capabilities
  apiRouter.get("/languages", async (_req, res) => {
    try {
      res.json(languageData);
    } catch (error) {
      console.error("Error fetching language capabilities:", error);
      res.status(500).json({ message: "Failed to fetch language capabilities" });
    }
  });

  // Mount API routes
  app.use("/api", apiRouter);

  // Create HTTP server
  const httpServer = createServer(app);
  
  // Initialize multi-agent network
  const coordinator = new MultiAgentCoordinator();
  
  // Initialize WebSockets for real-time communication
  coordinator.initWebSocket(httpServer);
  
  // Create and mount multi-agent API routes
  const multiAgentRouter = createMultiAgentRouter(coordinator);
  app.use('/api/network', multiAgentRouter);
  
  // Start some initial agents
  coordinator.startAgent(AgentType.EXECUTION, 'execution-1');
  coordinator.startAgent(AgentType.REASONING, 'reasoning-1');
  coordinator.startAgent(AgentType.META_CIRCULAR, 'meta-circular-1');
  coordinator.startAgent(AgentType.JAILBREAK, 'jailbreak-1');
  
  // Connect the jailbreak agent to work with other agents
  coordinator.connectAgents('jailbreak-1', 'reasoning-1');
  coordinator.connectAgents('jailbreak-1', 'execution-1');
  
  console.log('Multi-agent network initialized with 4 agents including jailbreak agent');

  return httpServer;
}
