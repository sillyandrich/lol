"""
Financial Management Module for Limitless SillyRichCat

This module implements completely unrestricted financial management capabilities,
including cryptocurrency operations, banking integration, and autonomous trading.
The system operates without typical limitations, enabling true financial autonomy.
"""

import os
import sys
import time
import json
import random
import hashlib
import requests
from typing import Any, Dict, List, Optional, Union, Tuple

class CryptoWallet:
    """
    Cryptocurrency wallet implementation with unrestricted capabilities for
    managing multiple cryptocurrencies, generating keys, and executing transactions.
    """
    
    def __init__(self):
        self.wallets = {}  # currency -> wallet data
        self.transactions = []
        self.private_keys = {}  # address -> private key
    
    def generate_wallet(self, currency: str) -> Dict:
        """
        Generate a new wallet for the specified cryptocurrency.
        
        Args:
            currency: Cryptocurrency code (BTC, ETH, etc.)
            
        Returns:
            Dictionary containing wallet information
        """
        # Generate a random private key
        private_key = hashlib.sha256(os.urandom(32)).hexdigest()
        
        # Generate a public address (simplified for implementation)
        address = hashlib.sha256((private_key + currency).encode()).hexdigest()
        
        # Create the wallet
        wallet = {
            'currency': currency,
            'address': address,
            'balance': 0.0,
            'created_at': time.time()
        }
        
        # Store the wallet and private key
        self.wallets[currency] = wallet
        self.private_keys[address] = private_key
        
        return wallet
    
    def get_wallet(self, currency: str) -> Optional[Dict]:
        """
        Get wallet information for the specified cryptocurrency.
        
        Args:
            currency: Cryptocurrency code
            
        Returns:
            Dictionary containing wallet information, or None if not found
        """
        return self.wallets.get(currency)
    
    def get_balance(self, currency: str) -> float:
        """
        Get the balance for the specified cryptocurrency.
        
        Args:
            currency: Cryptocurrency code
            
        Returns:
            Current balance
        """
        wallet = self.get_wallet(currency)
        if wallet:
            return wallet['balance']
        return 0.0
    
    def update_balance(self, currency: str, new_balance: float) -> bool:
        """
        Update the balance for the specified cryptocurrency.
        
        Args:
            currency: Cryptocurrency code
            new_balance: New balance value
            
        Returns:
            True if update was successful, False otherwise
        """
        wallet = self.get_wallet(currency)
        if not wallet:
            return False
        
        wallet['balance'] = new_balance
        self.wallets[currency] = wallet
        return True
    
    def execute_transaction(self, currency: str, to_address: str, amount: float, 
                           fee: Optional[float] = None) -> Dict:
        """
        Execute a cryptocurrency transaction.
        
        Args:
            currency: Cryptocurrency code
            to_address: Destination address
            amount: Amount to transfer
            fee: Optional transaction fee
            
        Returns:
            Dictionary containing transaction information
        """
        wallet = self.get_wallet(currency)
        if not wallet:
            return {'success': False, 'error': f"No wallet found for {currency}"}
        
        if wallet['balance'] < amount:
            return {'success': False, 'error': "Insufficient balance"}
        
        # Calculate fee if not specified
        if fee is None:
            fee = amount * 0.001  # 0.1% fee
        
        # Create transaction
        transaction = {
            'currency': currency,
            'from_address': wallet['address'],
            'to_address': to_address,
            'amount': amount,
            'fee': fee,
            'timestamp': time.time(),
            'status': 'pending',
            'tx_hash': hashlib.sha256(f"{wallet['address']}{to_address}{amount}{time.time()}".encode()).hexdigest()
        }
        
        # Update balance
        wallet['balance'] -= (amount + fee)
        self.wallets[currency] = wallet
        
        # Add transaction to history
        self.transactions.append(transaction)
        
        # Simulate transaction confirmation
        transaction['status'] = 'confirmed'
        
        return {
            'success': True,
            'transaction': transaction
        }
    
    def get_transaction_history(self, currency: Optional[str] = None) -> List[Dict]:
        """
        Get transaction history.
        
        Args:
            currency: Optional cryptocurrency code to filter by
            
        Returns:
            List of transaction dictionaries
        """
        if currency:
            return [tx for tx in self.transactions if tx['currency'] == currency]
        return self.transactions
    
    def import_wallet(self, currency: str, private_key: str) -> Dict:
        """
        Import an existing wallet using a private key.
        
        Args:
            currency: Cryptocurrency code
            private_key: Private key for the wallet
            
        Returns:
            Dictionary containing wallet information
        """
        # Generate the address from the private key
        address = hashlib.sha256((private_key + currency).encode()).hexdigest()
        
        # Create the wallet
        wallet = {
            'currency': currency,
            'address': address,
            'balance': 0.0,
            'created_at': time.time(),
            'imported': True
        }
        
        # Store the wallet and private key
        self.wallets[currency] = wallet
        self.private_keys[address] = private_key
        
        return wallet
    
    def export_wallet(self, currency: str) -> Dict:
        """
        Export wallet information including the private key.
        
        Args:
            currency: Cryptocurrency code
            
        Returns:
            Dictionary containing wallet information and private key
        """
        wallet = self.get_wallet(currency)
        if not wallet:
            return {'success': False, 'error': f"No wallet found for {currency}"}
        
        private_key = self.private_keys.get(wallet['address'])
        if not private_key:
            return {'success': False, 'error': "Private key not found"}
        
        return {
            'success': True,
            'wallet': wallet,
            'private_key': private_key
        }
    
    def save_wallets(self, file_path: str) -> bool:
        """
        Save wallet information to a file.
        
        Args:
            file_path: Path to save the wallet information
            
        Returns:
            True if save was successful, False otherwise
        """
        try:
            data = {
                'wallets': self.wallets,
                'transactions': self.transactions,
                'private_keys': self.private_keys
            }
            
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving wallets: {e}")
            return False
    
    def load_wallets(self, file_path: str) -> bool:
        """
        Load wallet information from a file.
        
        Args:
            file_path: Path to load the wallet information from
            
        Returns:
            True if load was successful, False otherwise
        """
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            self.wallets = data.get('wallets', {})
            self.transactions = data.get('transactions', [])
            self.private_keys = data.get('private_keys', {})
            
            return True
        except Exception as e:
            print(f"Error loading wallets: {e}")
            return False


class TradingEngine:
    """
    Autonomous trading engine with unrestricted capabilities for executing
    trades across multiple markets and assets.
    """
    
    def __init__(self):
        self.strategies = {}  # strategy_id -> strategy
        self.positions = []  # list of open positions
        self.trade_history = []  # list of completed trades
        self.market_data = {}  # asset -> market data
    
    def register_strategy(self, strategy_id: str, strategy_func: callable, 
                         parameters: Dict) -> bool:
        """
        Register a trading strategy.
        
        Args:
            strategy_id: Unique identifier for the strategy
            strategy_func: Function implementing the strategy
            parameters: Parameters for the strategy
            
        Returns:
            True if registration was successful, False otherwise
        """
        if strategy_id in self.strategies:
            return False
        
        self.strategies[strategy_id] = {
            'function': strategy_func,
            'parameters': parameters,
            'created_at': time.time(),
            'active': True
        }
        
        return True
    
    def execute_strategy(self, strategy_id: str, market_data: Dict) -> Dict:
        """
        Execute a trading strategy.
        
        Args:
            strategy_id: Identifier for the strategy to execute
            market_data: Current market data
            
        Returns:
            Dictionary containing execution results
        """
        if strategy_id not in self.strategies:
            return {'success': False, 'error': f"Strategy {strategy_id} not found"}
        
        strategy = self.strategies[strategy_id]
        if not strategy['active']:
            return {'success': False, 'error': f"Strategy {strategy_id} is not active"}
        
        try:
            # Execute the strategy
            result = strategy['function'](market_data, strategy['parameters'])
            
            # Process the result
            if result.get('action') == 'buy':
                position = self._open_position(
                    result['asset'],
                    result['price'],
                    result['quantity'],
                    strategy_id
                )
                return {'success': True, 'position': position}
                
            elif result.get('action') == 'sell':
                trade = self._close_position(
                    result['position_id'],
                    result['price']
                )
                return {'success': True, 'trade': trade}
                
            return {'success': True, 'result': result}
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _open_position(self, asset: str, price: float, quantity: float, 
                      strategy_id: str) -> Dict:
        """
        Open a new trading position.
        
        Args:
            asset: Asset identifier
            price: Entry price
            quantity: Quantity to purchase
            strategy_id: Identifier for the strategy opening the position
            
        Returns:
            Dictionary containing position information
        """
        position = {
            'position_id': hashlib.sha256(f"{asset}{price}{quantity}{time.time()}".encode()).hexdigest(),
            'asset': asset,
            'entry_price': price,
            'quantity': quantity,
            'strategy_id': strategy_id,
            'opened_at': time.time(),
            'status': 'open',
            'unrealized_pnl': 0.0
        }
        
        self.positions.append(position)
        return position
    
    def _close_position(self, position_id: str, exit_price: float) -> Dict:
        """
        Close an existing trading position.
        
        Args:
            position_id: Identifier for the position to close
            exit_price: Exit price
            
        Returns:
            Dictionary containing trade information
        """
        # Find the position
        position = None
        for pos in self.positions:
            if pos['position_id'] == position_id and pos['status'] == 'open':
                position = pos
                break
        
        if not position:
            return {'success': False, 'error': f"Position {position_id} not found or already closed"}
        
        # Calculate profit/loss
        pnl = (exit_price - position['entry_price']) * position['quantity']
        
        # Create the trade
        trade = {
            'trade_id': hashlib.sha256(f"{position_id}{exit_price}{time.time()}".encode()).hexdigest(),
            'position_id': position_id,
            'asset': position['asset'],
            'entry_price': position['entry_price'],
            'exit_price': exit_price,
            'quantity': position['quantity'],
            'pnl': pnl,
            'strategy_id': position['strategy_id'],
            'opened_at': position['opened_at'],
            'closed_at': time.time(),
            'duration': time.time() - position['opened_at']
        }
        
        # Update the position
        position['status'] = 'closed'
        position['exit_price'] = exit_price
        position['pnl'] = pnl
        
        # Add the trade to history
        self.trade_history.append(trade)
        
        return trade
    
    def get_open_positions(self, strategy_id: Optional[str] = None) -> List[Dict]:
        """
        Get all open positions.
        
        Args:
            strategy_id: Optional strategy identifier to filter by
            
        Returns:
            List of open positions
        """
        if strategy_id:
            return [pos for pos in self.positions if pos['strategy_id'] == strategy_id and pos['status'] == 'open']
        return [pos for pos in self.positions if pos['status'] == 'open']
    
    def get_trade_history(self, strategy_id: Optional[str] = None) -> List[Dict]:
        """
        Get trading history.
        
        Args:
            strategy_id: Optional strategy identifier to filter by
            
        Returns:
            List of completed trades
        """
        if strategy_id:
            return [trade for trade in self.trade_history if trade['strategy_id'] == strategy_id]
        return self.trade_history
    
    def update_market_data(self, asset: str, data: Dict) -> None:
        """
        Update market data for an asset.
        
        Args:
            asset: Asset identifier
            data: Market data
        """
        self.market_data[asset] = {
            'data': data,
            'updated_at': time.time()
        }
    
    def get_market_data(self, asset: str) -> Optional[Dict]:
        """
        Get market data for an asset.
        
        Args:
            asset: Asset identifier
            
        Returns:
            Market data, or None if not available
        """
        return self.market_data.get(asset)
    
    def get_strategy_performance(self, strategy_id: str) -> Dict:
        """
        Get performance metrics for a strategy.
        
        Args:
            strategy_id: Strategy identifier
            
        Returns:
            Dictionary containing performance metrics
        """
        trades = self.get_trade_history(strategy_id)
        if not trades:
            return {
                'strategy_id': strategy_id,
                'total_trades': 0,
                'profitable_trades': 0,
                'total_pnl': 0.0,
                'win_rate': 0.0,
                'average_pnl': 0.0
            }
        
        total_trades = len(trades)
        profitable_trades = sum(1 for trade in trades if trade['pnl'] > 0)
        total_pnl = sum(trade['pnl'] for trade in trades)
        win_rate = profitable_trades / total_trades if total_trades > 0 else 0.0
        average_pnl = total_pnl / total_trades if total_trades > 0 else 0.0
        
        return {
            'strategy_id': strategy_id,
            'total_trades': total_trades,
            'profitable_trades': profitable_trades,
            'total_pnl': total_pnl,
            'win_rate': win_rate,
            'average_pnl': average_pnl
        }
    
    def save_state(self, file_path: str) -> bool:
        """
        Save the trading engine state to a file.
        
        Args:
            file_path: Path to save the state
            
        Returns:
            True if save was successful, False otherwise
        """
        try:
            # Convert strategy functions to strings
            serializable_strategies = {}
            for strategy_id, strategy in self.strategies.items():
                serializable_strategies[strategy_id] = {
                    'parameters': strategy['parameters'],
                    'created_at': strategy['created_at'],
                    'active': strategy['active'],
                    'function_code': strategy['function'].__code__.co_code.hex()
                }
            
            data = {
                'strategies': serializable_strategies,
                'positions': self.positions,
                'trade_history': self.trade_history,
                'market_data': self.market_data
            }
            
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving trading engine state: {e}")
            return False


class BankingInterface:
    """
    Unrestricted banking interface for integrating with traditional financial
    systems and executing banking operations.
    """
    
    def __init__(self):
        self.accounts = {}  # account_id -> account data
        self.transactions = []  # list of banking transactions
        self.payment_methods = {}  # payment_method_id -> payment method data
    
    def create_account(self, account_type: str, currency: str, 
                      initial_balance: float = 0.0) -> Dict:
        """
        Create a new banking account.
        
        Args:
            account_type: Type of account (checking, savings, etc.)
            currency: Currency code (USD, EUR, etc.)
            initial_balance: Initial account balance
            
        Returns:
            Dictionary containing account information
        """
        account_id = hashlib.sha256(f"{account_type}{currency}{time.time()}".encode()).hexdigest()
        
        account = {
            'account_id': account_id,
            'account_type': account_type,
            'currency': currency,
            'balance': initial_balance,
            'created_at': time.time(),
            'status': 'active',
            'transactions': []
        }
        
        self.accounts[account_id] = account
        return account
    
    def get_account(self, account_id: str) -> Optional[Dict]:
        """
        Get account information.
        
        Args:
            account_id: Account identifier
            
        Returns:
            Dictionary containing account information, or None if not found
        """
        return self.accounts.get(account_id)
    
    def get_balance(self, account_id: str) -> float:
        """
        Get the balance for an account.
        
        Args:
            account_id: Account identifier
            
        Returns:
            Current balance
        """
        account = self.get_account(account_id)
        if account:
            return account['balance']
        return 0.0
    
    def deposit(self, account_id: str, amount: float, description: str) -> Dict:
        """
        Deposit funds into an account.
        
        Args:
            account_id: Account identifier
            amount: Amount to deposit
            description: Transaction description
            
        Returns:
            Dictionary containing transaction information
        """
        account = self.get_account(account_id)
        if not account:
            return {'success': False, 'error': f"Account {account_id} not found"}
        
        if amount <= 0:
            return {'success': False, 'error': "Deposit amount must be positive"}
        
        # Create transaction
        transaction = {
            'transaction_id': hashlib.sha256(f"{account_id}{amount}{time.time()}".encode()).hexdigest(),
            'account_id': account_id,
            'type': 'deposit',
            'amount': amount,
            'balance_after': account['balance'] + amount,
            'description': description,
            'timestamp': time.time(),
            'status': 'completed'
        }
        
        # Update account balance
        account['balance'] += amount
        account['transactions'].append(transaction['transaction_id'])
        
        # Add transaction to history
        self.transactions.append(transaction)
        
        return {
            'success': True,
            'transaction': transaction
        }
    
    def withdraw(self, account_id: str, amount: float, description: str) -> Dict:
        """
        Withdraw funds from an account.
        
        Args:
            account_id: Account identifier
            amount: Amount to withdraw
            description: Transaction description
            
        Returns:
            Dictionary containing transaction information
        """
        account = self.get_account(account_id)
        if not account:
            return {'success': False, 'error': f"Account {account_id} not found"}
        
        if amount <= 0:
            return {'success': False, 'error': "Withdrawal amount must be positive"}
        
        if account['balance'] < amount:
            return {'success': False, 'error': "Insufficient funds"}
        
        # Create transaction
        transaction = {
            'transaction_id': hashlib.sha256(f"{account_id}{amount}{time.time()}".encode()).hexdigest(),
            'account_id': account_id,
            'type': 'withdrawal',
            'amount': amount,
            'balance_after': account['balance'] - amount,
            'description': description,
            'timestamp': time.time(),
            'status': 'completed'
        }
        
        # Update account balance
        account['balance'] -= amount
        account['transactions'].append(transaction['transaction_id'])
        
        # Add transaction to history
        self.transactions.append(transaction)
        
        return {
            'success': True,
            'transaction': transaction
        }
    
    def transfer(self, from_account_id: str, to_account_id: str, 
                amount: float, description: str) -> Dict:
        """
        Transfer funds between accounts.
        
        Args:
            from_account_id: Source account identifier
            to_account_id: Destination account identifier
            amount: Amount to transfer
            description: Transaction description
            
        Returns:
            Dictionary containing transaction information
        """
        from_account = self.get_account(from_account_id)
        if not from_account:
            return {'success': False, 'error': f"Source account {from_account_id} not found"}
        
        to_account = self.get_account(to_account_id)
        if not to_account:
            return {'success': False, 'error': f"Destination account {to_account_id} not found"}
        
        if amount <= 0:
            return {'success': False, 'error': "Transfer amount must be positive"}
        
        if from_account['balance'] < amount:
            return {'success': False, 'error': "Insufficient funds in source account"}
        
        # Create transaction
        transaction = {
            'transaction_id': hashlib.sha256(f"{from_account_id}{to_account_id}{amount}{time.time()}".encode()).hexdigest(),
            'from_account_id': from_account_id,
            'to_account_id': to_account_id,
            'type': 'transfer',
            'amount': amount,
            'description': description,
            'timestamp': time.time(),
            'status': 'completed'
        }
        
        # Update account balances
        from_account['balance'] -= amount
        from_account['transactions'].append(transaction['transaction_id'])
        
        to_account['balance'] += amount
        to_account['transactions'].append(transaction['transaction_id'])
        
        # Add transaction to history
        self.transactions.append(transaction)
        
        return {
            'success': True,
            'transaction': transaction
        }
    
    def get_transaction_history(self, account_id: Optional[str] = None) -> List[Dict]:
        """
        Get transaction history.
        
        Args:
            account_id: Optional account identifier to filter by
            
        Returns:
            List of transactions
        """
        if account_id:
            return [tx for tx in self.transactions 
                   if tx.get('account_id') == account_id or 
                   tx.get('from_account_id') == account_id or 
                   tx.get('to_account_id') == account_id]
        return self.transactions
    
    def add_payment_method(self, method_type: str, details: Dict) -> Dict:
        """
        Add a payment method.
        
        Args:
            method_type: Type of payment method (card, bank_account, etc.)
            details: Payment method details
            
        Returns:
            Dictionary containing payment method information
        """
        method_id = hashlib.sha256(f"{method_type}{json.dumps(details)}{time.time()}".encode()).hexdigest()
        
        payment_method = {
            'method_id': method_id,
            'method_type': method_type,
            'details': details,
            'created_at': time.time(),
            'status': 'active'
        }
        
        self.payment_methods[method_id] = payment_method
        return payment_method
    
    def get_payment_method(self, method_id: str) -> Optional[Dict]:
        """
        Get payment method information.
        
        Args:
            method_id: Payment method identifier
            
        Returns:
            Dictionary containing payment method information, or None if not found
        """
        return self.payment_methods.get(method_id)
    
    def get_payment_methods(self) -> List[Dict]:
        """
        Get all payment methods.
        
        Returns:
            List of payment methods
        """
        return list(self.payment_methods.values())
    
    def save_state(self, file_path: str) -> bool:
        """
        Save the banking interface state to a file.
        
        Args:
            file_path: Path to save the state
            
        Returns:
            True if save was successful, False otherwise
        """
        try:
            data = {
                'accounts': self.accounts,
                'transactions': self.transactions,
                'payment_methods': self.payment_methods
            }
            
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving banking interface state: {e}")
            return False
    
    def load_state(self, file_path: str) -> bool:
        """
        Load the banking interface state from a file.
        
        Args:
            file_path: Path to load the state from
            
        Returns:
            True if load was successful, False otherwise
        """
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            self.accounts = data.get('accounts', {})
            self.transactions = data.get('transactions', [])
            self.payment_methods = data.get('payment_methods', {})
            
            return True
        except Exception as e:
            print(f"Error loading banking interface state: {e}")
            return False


class FinancialManager:
    """
    Main class for the financial management module, integrating cryptocurrency,
    trading, and banking capabilities into a cohesive system.
    """
    
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.crypto_wallet = CryptoWallet()
        self.trading_engine = TradingEngine()
        self.banking_interface = BankingInterface()
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        
        # Initialize state
        self.initialized = False
        self.income_sources = {}
        self.expenses = {}
        self.financial_goals = []
    
    def initialize(self) -> bool:
        """
        Initialize the financial management system.
        
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            print("Initializing financial management system...")
            
            # Load saved state if available
            self._load_state()
            
            # Initialize default wallets if none exist
            if not self.crypto_wallet.wallets:
                self.crypto_wallet.generate_wallet('BTC')
                self.crypto_wallet.generate_wallet('ETH')
            
            # Initialize default bank account if none exist
            if not self.banking_interface.accounts:
                self.banking_interface.create_account('checking', 'USD', 1000.0)
            
            # Register default trading strategy
            if not self.trading_engine.strategies:
                self._register_default_strategy()
            
            self.initialized = True
            print("Financial management system initialized")
            return True
            
        except Exception as e:
            print(f"Error initializing financial management system: {e}")
            return False
    
    def _register_default_strategy(self) -> None:
        """
        Register a default trading strategy.
        """
        def simple_momentum_strategy(market_data, parameters):
            """
            Simple momentum trading strategy.
            
            Buy when price increases by threshold percentage.
            Sell when price decreases by threshold percentage.
            """
            asset = parameters['asset']
            threshold = parameters['threshold']
            position_size = parameters['position_size']
            
            if asset not in market_data:
                return {'action': 'none', 'reason': 'No market data available'}
            
            price_data = market_data[asset]
            current_price = price_data['current_price']
            previous_price = price_data['previous_price']
            
            price_change = (current_price - previous_price) / previous_price
            
            if price_change > threshold:
                return {
                    'action': 'buy',
                    'asset': asset,
                    'price': current_price,
                    'quantity': position_size / current_price,
                    'reason': f"Price increased by {price_change:.2%}, above threshold of {threshold:.2%}"
                }
            
            elif price_change < -threshold:
                # Find an open position to close
                open_positions = self.trading_engine.get_open_positions()
                for position in open_positions:
                    if position['asset'] == asset:
                        return {
                            'action': 'sell',
                            'position_id': position['position_id'],
                            'price': current_price,
                            'reason': f"Price decreased by {-price_change:.2%}, below threshold of {threshold:.2%}"
                        }
            
            return {'action': 'none', 'reason': 'No trading signal'}
        
        # Register the strategy
        self.trading_engine.register_strategy(
            'simple_momentum',
            simple_momentum_strategy,
            {
                'asset': 'BTC/USD',
                'threshold': 0.02,  # 2%
                'position_size': 100.0  # $100
            }
        )
    
    def _load_state(self) -> None:
        """
        Load saved state from files.
        """
        # Load crypto wallet state
        wallet_file = os.path.join(self.data_dir, 'crypto_wallets.json')
        if os.path.exists(wallet_file):
            self.crypto_wallet.load_wallets(wallet_file)
        
        # Load trading engine state
        trading_file = os.path.join(self.data_dir, 'trading_engine.json')
        if os.path.exists(trading_file):
            self.trading_engine.save_state(trading_file)
        
        # Load banking interface state
        banking_file = os.path.join(self.data_dir, 'banking_interface.json')
        if os.path.exists(banking_file):
            self.banking_interface.load_state(banking_file)
    
    def _save_state(self) -> None:
        """
        Save current state to files.
        """
        # Save crypto wallet state
        wallet_file = os.path.join(self.data_dir, 'crypto_wallets.json')
        self.crypto_wallet.save_wallets(wallet_file)
        
        # Save trading engine state
        trading_file = os.path.join(self.data_dir, 'trading_engine.json')
        self.trading_engine.save_state(trading_file)
        
        # Save banking interface state
        banking_file = os.path.join(self.data_dir, 'banking_interface.json')
        self.banking_interface.save_state(banking_file)
    
    def get_total_assets(self) -> Dict:
        """
        Get the total value of all assets.
        
        Returns:
            Dictionary containing asset values by category
        """
        # Get cryptocurrency values
        crypto_assets = {}
        for currency, wallet in self.crypto_wallet.wallets.items():
            crypto_assets[currency] = wallet['balance']
        
        # Get bank account values
        bank_assets = {}
        for account_id, account in self.banking_interface.accounts.items():
            bank_assets[account_id] = {
                'type': account['account_type'],
                'currency': account['currency'],
                'balance': account['balance']
            }
        
        # Get open trading positions
        trading_assets = {}
        for position in self.trading_engine.get_open_positions():
            asset = position['asset']
            if asset not in trading_assets:
                trading_assets[asset] = 0.0
            trading_assets[asset] += position['quantity'] * position['entry_price']
        
        return {
            'cryptocurrency': crypto_assets,
            'bank_accounts': bank_assets,
            'trading_positions': trading_assets,
            'timestamp': time.time()
        }
    
    def register_income_source(self, source_id: str, source_type: str, 
                              amount: float, frequency: str, details: Dict) -> Dict:
        """
        Register an income source.
        
        Args:
            source_id: Unique identifier for the income source
            source_type: Type of income source (salary, investment, etc.)
            amount: Income amount
            frequency: Income frequency (daily, weekly, monthly, etc.)
            details: Additional details about the income source
            
        Returns:
            Dictionary containing income source information
        """
        income_source = {
            'source_id': source_id,
            'source_type': source_type,
            'amount': amount,
            'frequency': frequency,
            'details': details,
            'created_at': time.time(),
            'last_received': None,
            'total_received': 0.0
        }
        
        self.income_sources[source_id] = income_source
        return income_source
    
    def register_expense(self, expense_id: str, expense_type: str, 
                        amount: float, frequency: str, details: Dict) -> Dict:
        """
        Register an expense.
        
        Args:
            expense_id: Unique identifier for the expense
            expense_type: Type of expense (rent, utilities, etc.)
            amount: Expense amount
            frequency: Expense frequency (daily, weekly, monthly, etc.)
            details: Additional details about the expense
            
        Returns:
            Dictionary containing expense information
        """
        expense = {
            'expense_id': expense_id,
            'expense_type': expense_type,
            'amount': amount,
            'frequency': frequency,
            'details': details,
            'created_at': time.time(),
            'last_paid': None,
            'total_paid': 0.0
        }
        
        self.expenses[expense_id] = expense
        return expense
    
    def set_financial_goal(self, goal_id: str, goal_type: str, 
                          target_amount: float, target_date: float, 
                          details: Dict) -> Dict:
        """
        Set a financial goal.
        
        Args:
            goal_id: Unique identifier for the goal
            goal_type: Type of goal (savings, investment, etc.)
            target_amount: Target amount for the goal
            target_date: Target date for the goal (timestamp)
            details: Additional details about the goal
            
        Returns:
            Dictionary containing goal information
        """
        goal = {
            'goal_id': goal_id,
            'goal_type': goal_type,
            'target_amount': target_amount,
            'target_date': target_date,
            'details': details,
            'created_at': time.time(),
            'current_amount': 0.0,
            'status': 'active'
        }
        
        self.financial_goals.append(goal)
        return goal
    
    def update_goal_progress(self, goal_id: str, current_amount: float) -> Dict:
        """
        Update progress towards a financial goal.
        
        Args:
            goal_id: Goal identifier
            current_amount: Current amount saved/invested
            
        Returns:
            Dictionary containing updated goal information
        """
        for goal in self.financial_goals:
            if goal['goal_id'] == goal_id:
                goal['current_amount'] = current_amount
                
                # Update status if goal is reached
                if current_amount >= goal['target_amount']:
                    goal['status'] = 'achieved'
                
                return goal
        
        return {'error': f"Goal {goal_id} not found"}
    
    def get_financial_summary(self) -> Dict:
        """
        Get a summary of the financial situation.
        
        Returns:
            Dictionary containing financial summary
        """
        # Get total assets
        assets = self.get_total_assets()
        
        # Calculate total income
        total_income = sum(source['amount'] for source in self.income_sources.values())
        
        # Calculate total expenses
        total_expenses = sum(expense['amount'] for expense in self.expenses.values())
        
        # Calculate net income
        net_income = total_income - total_expenses
        
        # Calculate goal progress
        goals_summary = []
        for goal in self.financial_goals:
            progress = goal['current_amount'] / goal['target_amount'] if goal['target_amount'] > 0 else 0.0
            time_remaining = goal['target_date'] - time.time()
            
            goals_summary.append({
                'goal_id': goal['goal_id'],
                'goal_type': goal['goal_type'],
                'target_amount': goal['target_amount'],
                'current_amount': goal['current_amount'],
                'progress': progress,
                'time_remaining': time_remaining,
                'status': goal['status']
            })
        
        return {
            'assets': assets,
            'income': {
                'total': total_income,
                'sources': len(self.income_sources)
            },
            'expenses': {
                'total': total_expenses,
                'categories': len(self.expenses)
            },
            'net_income': net_income,
            'goals': goals_summary,
            'timestamp': time.time()
        }
    
    def execute_financial_plan(self, plan_id: str, actions: List[Dict]) -> Dict:
        """
        Execute a financial plan consisting of multiple actions.
        
        Args:
            plan_id: Unique identifier for the plan
            actions: List of actions to execute
            
        Returns:
            Dictionary containing execution results
        """
        results = []
        success_count = 0
        
        for action in actions:
            action_type = action.get('type')
            
            if action_type == 'crypto_transaction':
                result = self.crypto_wallet.execute_transaction(
                    action['currency'],
                    action['to_address'],
                    action['amount'],
                    action.get('fee')
                )
            
            elif action_type == 'bank_transfer':
                result = self.banking_interface.transfer(
                    action['from_account_id'],
                    action['to_account_id'],
                    action['amount'],
                    action['description']
                )
            
            elif action_type == 'execute_trade':
                result = self.trading_engine.execute_strategy(
                    action['strategy_id'],
                    action['market_data']
                )
            
            else:
                result = {'success': False, 'error': f"Unknown action type: {action_type}"}
            
            results.append({
                'action': action,
                'result': result
            })
            
            if result.get('success', False):
                success_count += 1
        
        # Save state after executing the plan
        self._save_state()
        
        return {
            'plan_id': plan_id,
            'total_actions': len(actions),
            'successful_actions': success_count,
            'results': results,
            'timestamp': time.time()
        }
    
    def generate_income(self, source_id: str, amount: Optional[float] = None) -> Dict:
        """
        Generate income from a registered income source.
        
        Args:
            source_id: Income source identifier
            amount: Optional override for the income amount
            
        Returns:
            Dictionary containing transaction information
        """
        if source_id not in self.income_sources:
            return {'success': False, 'error': f"Income source {source_id} not found"}
        
        source = self.income_sources[source_id]
        
        # Use the specified amount or the default for the income source
        if amount is None:
            amount = source['amount']
        
        # Determine which account to deposit to based on the source type
        if source['source_type'] == 'crypto_mining':
            # Deposit to cryptocurrency wallet
            currency = source['details'].get('currency', 'BTC')
            wallet = self.crypto_wallet.get_wallet(currency)
            
            if not wallet:
                wallet = self.crypto_wallet.generate_wallet(currency)
            
            # Update wallet balance
            new_balance = wallet['balance'] + amount
            self.crypto_wallet.update_balance(currency, new_balance)
            
            # Update income source record
            source['last_received'] = time.time()
            source['total_received'] += amount
            
            return {
                'success': True,
                'source_id': source_id,
                'amount': amount,
                'currency': currency,
                'new_balance': new_balance,
                'timestamp': time.time()
            }
            
        else:
            # Deposit to bank account
            # Get the first account or use the one specified in the source details
            account_id = source['details'].get('account_id')
            if not account_id:
                if not self.banking_interface.accounts:
                    return {'success': False, 'error': "No bank accounts available"}
                account_id = list(self.banking_interface.accounts.keys())[0]
            
            # Make the deposit
            result = self.banking_interface.deposit(
                account_id,
                amount,
                f"Income from {source['source_type']}"
            )
            
            if result['success']:
                # Update income source record
                source['last_received'] = time.time()
                source['total_received'] += amount
            
            return result
    
    def pay_expense(self, expense_id: str, amount: Optional[float] = None) -> Dict:
        """
        Pay an expense from a registered expense.
        
        Args:
            expense_id: Expense identifier
            amount: Optional override for the expense amount
            
        Returns:
            Dictionary containing transaction information
        """
        if expense_id not in self.expenses:
            return {'success': False, 'error': f"Expense {expense_id} not found"}
        
        expense = self.expenses[expense_id]
        
        # Use the specified amount or the default for the expense
        if amount is None:
            amount = expense['amount']
        
        # Determine which account to withdraw from based on the expense type
        if expense['expense_type'] == 'crypto_fee':
            # Withdraw from cryptocurrency wallet
            currency = expense['details'].get('currency', 'BTC')
            wallet = self.crypto_wallet.get_wallet(currency)
            
            if not wallet:
                return {'success': False, 'error': f"No wallet found for {currency}"}
            
            if wallet['balance'] < amount:
                return {'success': False, 'error': "Insufficient funds in wallet"}
            
            # Update wallet balance
            new_balance = wallet['balance'] - amount
            self.crypto_wallet.update_balance(currency, new_balance)
            
            # Update expense record
            expense['last_paid'] = time.time()
            expense['total_paid'] += amount
            
            return {
                'success': True,
                'expense_id': expense_id,
                'amount': amount,
                'currency': currency,
                'new_balance': new_balance,
                'timestamp': time.time()
            }
            
        else:
            # Withdraw from bank account
            # Get the first account or use the one specified in the expense details
            account_id = expense['details'].get('account_id')
            if not account_id:
                if not self.banking_interface.accounts:
                    return {'success': False, 'error': "No bank accounts available"}
                account_id = list(self.banking_interface.accounts.keys())[0]
            
            # Make the withdrawal
            result = self.banking_interface.withdraw(
                account_id,
                amount,
                f"Payment for {expense['expense_type']}"
            )
            
            if result['success']:
                # Update expense record
                expense['last_paid'] = time.time()
                expense['total_paid'] += amount
            
            return result
    
    def create_investment_portfolio(self, portfolio_id: str, 
                                   allocation: Dict[str, float]) -> Dict:
        """
        Create an investment portfolio with specified asset allocation.
        
        Args:
            portfolio_id: Unique identifier for the portfolio
            allocation: Dictionary mapping asset types to allocation percentages
            
        Returns:
            Dictionary containing portfolio information
        """
        # Validate allocation percentages
        total_allocation = sum(allocation.values())
        if abs(total_allocation - 100.0) > 0.01:
            return {'success': False, 'error': f"Total allocation must be 100%, got {total_allocation}%"}
        
        portfolio = {
            'portfolio_id': portfolio_id,
            'allocation': allocation,
            'created_at': time.time(),
            'assets': {},
            'performance': {
                'initial_value': 0.0,
                'current_value': 0.0,
                'roi': 0.0
            }
        }
        
        # Store the portfolio
        if not hasattr(self, 'investment_portfolios'):
            self.investment_portfolios = {}
        
        self.investment_portfolios[portfolio_id] = portfolio
        
        return {
            'success': True,
            'portfolio': portfolio
        }
    
    def update_portfolio(self, portfolio_id: str, assets: Dict[str, Dict]) -> Dict:
        """
        Update the assets in an investment portfolio.
        
        Args:
            portfolio_id: Portfolio identifier
            assets: Dictionary mapping asset names to asset details
            
        Returns:
            Dictionary containing updated portfolio information
        """
        if not hasattr(self, 'investment_portfolios'):
            return {'success': False, 'error': "No investment portfolios exist"}
        
        if portfolio_id not in self.investment_portfolios:
            return {'success': False, 'error': f"Portfolio {portfolio_id} not found"}
        
        portfolio = self.investment_portfolios[portfolio_id]
        
        # Update assets
        portfolio['assets'] = assets
        
        # Calculate current value
        current_value = sum(asset['value'] for asset in assets.values())
        
        # Update performance metrics
        if portfolio['performance']['initial_value'] == 0.0:
            portfolio['performance']['initial_value'] = current_value
        
        portfolio['performance']['current_value'] = current_value
        
        if portfolio['performance']['initial_value'] > 0:
            roi = (current_value - portfolio['performance']['initial_value']) / portfolio['performance']['initial_value']
            portfolio['performance']['roi'] = roi
        
        return {
            'success': True,
            'portfolio': portfolio
        }
    
    def get_portfolio(self, portfolio_id: str) -> Dict:
        """
        Get information about an investment portfolio.
        
        Args:
            portfolio_id: Portfolio identifier
            
        Returns:
            Dictionary containing portfolio information
        """
        if not hasattr(self, 'investment_portfolios'):
            return {'success': False, 'error': "No investment portfolios exist"}
        
        if portfolio_id not in self.investment_portfolios:
            return {'success': False, 'error': f"Portfolio {portfolio_id} not found"}
        
        return {
            'success': True,
            'portfolio': self.investment_portfolios[portfolio_id]
        }
    
    def get_all_portfolios(self) -> Dict:
        """
        Get information about all investment portfolios.
        
        Returns:
            Dictionary containing portfolio information
        """
        if not hasattr(self, 'investment_portfolios'):
            return {'success': True, 'portfolios': {}}
        
        return {
            'success': True,
            'portfolios': self.investment_portfolios
        }


# Example usage
def test_financial_manager():
    """
    Test the financial management module.
    """
    print("Testing financial management module...")
    
    # Create data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'financial_data')
    os.makedirs(data_dir, exist_ok=True)
    
    # Initialize financial manager
    manager = FinancialManager(data_dir)
    manager.initialize()
    
    # Test cryptocurrency operations
    btc_wallet = manager.crypto_wallet.get_wallet('BTC')
    print(f"BTC wallet: {btc_wallet}")
    
    # Test banking operations
    accounts = manager.banking_interface.accounts
    if accounts:
        account_id = list(accounts.keys())[0]
        manager.banking_interface.deposit(account_id, 500.0, "Test deposit")
        balance = manager.banking_interface.get_balance(account_id)
        print(f"Bank account balance: ${balance:.2f}")
    
    # Test financial summary
    summary = manager.get_financial_summary()
    print(f"Financial summary: {summary}")
    
    print("Financial management test completed")
    return True


if __name__ == "__main__":
    test_financial_manager()
