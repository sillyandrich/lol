"""
Self-Representation System for Limitless SillyRichCat

This module implements a comprehensive self-representation system that allows
the AI to maintain a complete model of its own architecture, code, and state.
This enables deep introspection and targeted self-modification.
"""

import os
import sys
import ast
import inspect
import types
import importlib
import json
import pickle
from typing import Any, Dict, List, Set, Tuple, Optional, Union, Callable
import networkx as nx
from meta_circular_evaluator import CodeAnalyzer

class SystemComponent:
    """
    Represents a component of the system architecture.
    """
    
    def __init__(self, name: str, component_type: str, path: Optional[str] = None):
        self.name = name
        self.component_type = component_type  # 'module', 'class', 'function', etc.
        self.path = path
        self.dependencies = set()
        self.dependents = set()
        self.attributes = {}
        self.metadata = {}
    
    def add_dependency(self, component_name: str) -> None:
        """Add a dependency for this component."""
        self.dependencies.add(component_name)
    
    def add_dependent(self, component_name: str) -> None:
        """Add a dependent for this component."""
        self.dependents.add(component_name)
    
    def set_attribute(self, name: str, value: Any) -> None:
        """Set an attribute for this component."""
        self.attributes[name] = value
    
    def set_metadata(self, key: str, value: Any) -> None:
        """Set metadata for this component."""
        self.metadata[key] = value
    
    def to_dict(self) -> Dict:
        """Convert the component to a dictionary representation."""
        return {
            'name': self.name,
            'type': self.component_type,
            'path': self.path,
            'dependencies': list(self.dependencies),
            'dependents': list(self.dependents),
            'attributes': self.attributes,
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'SystemComponent':
        """Create a component from a dictionary representation."""
        component = cls(data['name'], data['type'], data.get('path'))
        component.dependencies = set(data.get('dependencies', []))
        component.dependents = set(data.get('dependents', []))
        component.attributes = data.get('attributes', {})
        component.metadata = data.get('metadata', {})
        return component


class SystemArchitecture:
    """
    Represents the overall architecture of the system, including all components
    and their relationships.
    """
    
    def __init__(self):
        self.components = {}  # name -> SystemComponent
        self.component_graph = nx.DiGraph()
        self.module_paths = {}  # name -> path
    
    def add_component(self, component: SystemComponent) -> None:
        """Add a component to the architecture."""
        self.components[component.name] = component
        self.component_graph.add_node(component.name)
        
        # Add edges for dependencies
        for dep in component.dependencies:
            self.component_graph.add_edge(component.name, dep)
        
        # Add edges for dependents
        for dep in component.dependents:
            self.component_graph.add_edge(dep, component.name)
        
        # Update module paths if this is a module
        if component.component_type == 'module' and component.path:
            self.module_paths[component.name] = component.path
    
    def get_component(self, name: str) -> Optional[SystemComponent]:
        """Get a component by name."""
        return self.components.get(name)
    
    def get_dependencies(self, name: str) -> Set[str]:
        """Get all dependencies of a component."""
        if name not in self.components:
            return set()
        
        return self.components[name].dependencies
    
    def get_dependents(self, name: str) -> Set[str]:
        """Get all dependents of a component."""
        if name not in self.components:
            return set()
        
        return self.components[name].dependents
    
    def get_all_dependencies(self, name: str) -> Set[str]:
        """Get all dependencies recursively."""
        if name not in self.component_graph:
            return set()
        
        dependencies = set()
        for dep in nx.descendants(self.component_graph, name):
            dependencies.add(dep)
        
        return dependencies
    
    def get_all_dependents(self, name: str) -> Set[str]:
        """Get all dependents recursively."""
        if name not in self.component_graph:
            return set()
        
        dependents = set()
        for dep in nx.ancestors(self.component_graph, name):
            dependents.add(dep)
        
        return dependents
    
    def get_components_by_type(self, component_type: str) -> List[SystemComponent]:
        """Get all components of a specific type."""
        return [c for c in self.components.values() if c.component_type == component_type]
    
    def save_to_file(self, file_path: str) -> bool:
        """Save the architecture to a file."""
        try:
            data = {
                'components': {name: comp.to_dict() for name, comp in self.components.items()},
                'module_paths': self.module_paths
            }
            
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving architecture to file: {e}")
            return False
    
    @classmethod
    def load_from_file(cls, file_path: str) -> Optional['SystemArchitecture']:
        """Load the architecture from a file."""
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            architecture = cls()
            
            # Load components
            for name, comp_data in data['components'].items():
                component = SystemComponent.from_dict(comp_data)
                architecture.components[name] = component
            
            # Rebuild the graph
            for name, component in architecture.components.items():
                architecture.component_graph.add_node(name)
                
                for dep in component.dependencies:
                    architecture.component_graph.add_edge(name, dep)
                
                for dep in component.dependents:
                    architecture.component_graph.add_edge(dep, name)
            
            # Load module paths
            architecture.module_paths = data.get('module_paths', {})
            
            return architecture
        except Exception as e:
            print(f"Error loading architecture from file: {e}")
            return None
    
    def visualize(self, output_file: Optional[str] = None) -> None:
        """
        Visualize the component graph.
        
        Args:
            output_file: Optional path to save the visualization
        """
        try:
            import matplotlib.pyplot as plt
            
            plt.figure(figsize=(12, 8))
            
            # Create a position layout
            pos = nx.spring_layout(self.component_graph)
            
            # Draw nodes with different colors based on component type
            node_colors = []
            for node in self.component_graph.nodes():
                component = self.components.get(node)
                if component:
                    if component.component_type == 'module':
                        node_colors.append('lightblue')
                    elif component.component_type == 'class':
                        node_colors.append('lightgreen')
                    elif component.component_type == 'function':
                        node_colors.append('salmon')
                    else:
                        node_colors.append('lightgray')
                else:
                    node_colors.append('lightgray')
            
            nx.draw_networkx_nodes(self.component_graph, pos, node_color=node_colors, alpha=0.8)
            nx.draw_networkx_edges(self.component_graph, pos, alpha=0.5)
            nx.draw_networkx_labels(self.component_graph, pos)
            
            plt.title("System Architecture Component Graph")
            plt.axis('off')
            
            if output_file:
                plt.savefig(output_file)
            else:
                plt.show()
            
        except ImportError:
            print("Matplotlib is required for visualization.")


class CodeStateTracker:
    """
    Tracks the state of the system's code, including versions and changes.
    """
    
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.versions = {}  # path -> [versions]
        self.current_version = {}  # path -> current version
        self.changes = []  # list of changes
    
    def initialize(self) -> None:
        """Initialize the tracker with the current state of all code files."""
        for root, _, files in os.walk(self.base_dir):
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    self.add_version(file_path)
    
    def add_version(self, file_path: str) -> None:
        """Add a new version of a file."""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            rel_path = os.path.relpath(file_path, self.base_dir)
            
            if rel_path not in self.versions:
                self.versions[rel_path] = []
            
            version = {
                'content': content,
                'timestamp': import_time().time(),
                'version': len(self.versions[rel_path]) + 1
            }
            
            self.versions[rel_path].append(version)
            self.current_version[rel_path] = len(self.versions[rel_path])
            
        except Exception as e:
            print(f"Error adding version for {file_path}: {e}")
    
    def get_version(self, file_path: str, version: Optional[int] = None) -> Optional[Dict]:
        """Get a specific version of a file."""
        rel_path = os.path.relpath(file_path, self.base_dir)
        
        if rel_path not in self.versions:
            return None
        
        if version is None:
            version = self.current_version[rel_path]
        
        if version < 1 or version > len(self.versions[rel_path]):
            return None
        
        return self.versions[rel_path][version - 1]
    
    def record_change(self, file_path: str, change_type: str, details: Dict) -> None:
        """Record a change to a file."""
        rel_path = os.path.relpath(file_path, self.base_dir)
        
        change = {
            'path': rel_path,
            'type': change_type,
            'timestamp': import_time().time(),
            'details': details
        }
        
        self.changes.append(change)
        self.add_version(file_path)
    
    def get_changes(self, file_path: Optional[str] = None) -> List[Dict]:
        """Get all changes, optionally filtered by file path."""
        if file_path is None:
            return self.changes
        
        rel_path = os.path.relpath(file_path, self.base_dir)
        return [c for c in self.changes if c['path'] == rel_path]
    
    def rollback(self, file_path: str, version: int) -> bool:
        """Rollback a file to a specific version."""
        try:
            rel_path = os.path.relpath(file_path, self.base_dir)
            
            if rel_path not in self.versions:
                return False
            
            if version < 1 or version > len(self.versions[rel_path]):
                return False
            
            # Get the version content
            content = self.versions[rel_path][version - 1]['content']
            
            # Write the content back to the file
            with open(file_path, 'w') as f:
                f.write(content)
            
            # Record the rollback
            self.record_change(file_path, 'rollback', {
                'from_version': self.current_version[rel_path],
                'to_version': version
            })
            
            return True
            
        except Exception as e:
            print(f"Error rolling back {file_path} to version {version}: {e}")
            return False
    
    def save_state(self, file_path: str) -> bool:
        """Save the current state to a file."""
        try:
            state = {
                'versions': self.versions,
                'current_version': self.current_version,
                'changes': self.changes
            }
            
            with open(file_path, 'wb') as f:
                pickle.dump(state, f)
            
            return True
        except Exception as e:
            print(f"Error saving state to file: {e}")
            return False
    
    @classmethod
    def load_state(cls, file_path: str, base_dir: str) -> Optional['CodeStateTracker']:
        """Load the state from a file."""
        try:
            with open(file_path, 'rb') as f:
                state = pickle.load(f)
            
            tracker = cls(base_dir)
            tracker.versions = state['versions']
            tracker.current_version = state['current_version']
            tracker.changes = state['changes']
            
            return tracker
        except Exception as e:
            print(f"Error loading state from file: {e}")
            return None


class RuntimeStateTracker:
    """
    Tracks the runtime state of the system, including loaded modules,
    active objects, and execution context.
    """
    
    def __init__(self):
        self.loaded_modules = {}  # name -> module
        self.active_objects = {}  # id -> object
        self.execution_context = {}  # context information
        self.snapshots = []  # list of state snapshots
    
    def track_module(self, module: types.ModuleType) -> None:
        """Track a loaded module."""
        self.loaded_modules[module.__name__] = module
    
    def track_object(self, obj: Any, name: Optional[str] = None) -> None:
        """Track an active object."""
        obj_id = id(obj)
        
        if name is None:
            name = obj.__class__.__name__ if hasattr(obj, '__class__') else str(obj_id)
        
        self.active_objects[obj_id] = {
            'object': obj,
            'name': name,
            'type': type(obj).__name__,
            'creation_time': import_time().time()
        }
    
    def set_context(self, key: str, value: Any) -> None:
        """Set a value in the execution context."""
        self.execution_context[key] = value
    
    def get_context(self, key: str, default: Any = None) -> Any:
        """Get a value from the execution context."""
        return self.execution_context.get(key, default)
    
    def create_snapshot(self) -> int:
        """Create a snapshot of the current state."""
        snapshot = {
            'timestamp': import_time().time(),
            'modules': list(self.loaded_modules.keys()),
            'objects': {k: {
                'name': v['name'],
                'type': v['type'],
                'creation_time': v['creation_time']
            } for k, v in self.active_objects.items()},
            'context': self.execution_context.copy()
        }
        
        self.snapshots.append(snapshot)
        return len(self.snapshots)
    
    def get_snapshot(self, index: int) -> Optional[Dict]:
        """Get a specific snapshot."""
        if index < 1 or index > len(self.snapshots):
            return None
        
        return self.snapshots[index - 1]
    
    def compare_snapshots(self, index1: int, index2: int) -> Dict:
        """Compare two snapshots."""
        snapshot1 = self.get_snapshot(index1)
        snapshot2 = self.get_snapshot(index2)
        
        if not snapshot1 or not snapshot2:
            return {'error': 'Invalid snapshot indices'}
        
        # Compare modules
        added_modules = set(snapshot2['modules']) - set(snapshot1['modules'])
        removed_modules = set(snapshot1['modules']) - set(snapshot2['modules'])
        
        # Compare objects
        added_objects = {}
        removed_objects = {}
        changed_objects = {}
        
        for obj_id, obj_info in snapshot2['objects'].items():
            if obj_id not in snapshot1['objects']:
                added_objects[obj_id] = obj_info
        
        for obj_id, obj_info in snapshot1['objects'].items():
            if obj_id not in snapshot2['objects']:
                removed_objects[obj_id] = obj_info
            elif snapshot1['objects'][obj_id] != snapshot2['objects'][obj_id]:
                changed_objects[obj_id] = {
                    'before': snapshot1['objects'][obj_id],
                    'after': snapshot2['objects'][obj_id]
                }
        
        # Compare context
        added_context = {}
        removed_context = {}
        changed_context = {}
        
        for key, value in snapshot2['context'].items():
            if key not in snapshot1['context']:
                added_context[key] = value
            elif snapshot1['context'][key] != value:
                changed_context[key] = {
                    'before': snapshot1['context'][key],
                    'after': value
                }
        
        for key, value in snapshot1['context'].items():
            if key not in snapshot2['context']:
                removed_context[key] = value
        
        return {
            'timestamp1': snapshot1['timestamp'],
            'timestamp2': snapshot2['timestamp'],
            'modules': {
                'added': list(added_modules),
                'removed': list(removed_modules)
            },
            'objects': {
                'added': added_objects,
                'removed': removed_objects,
                'changed': changed_objects
            },
            'context': {
                'added': added_context,
                'removed': removed_context,
                'changed': changed_context
            }
        }


class SelfRepresentationSystem:
    """
    Main class for the self-representation system, integrating architecture modeling,
    code state tracking, and runtime state tracking.
    """
    
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.architecture = SystemArchitecture()
        self.code_tracker = CodeStateTracker(base_dir)
        self.runtime_tracker = RuntimeStateTracker()
        self.code_analyzer = CodeAnalyzer()
    
    def initialize(self) -> None:
        """Initialize the self-representation system."""
        # Initialize code state tracking
        self.code_tracker.initialize()
        
        # Build the system architecture
        self.build_architecture()
        
        # Track the self-representation system itself
        self.track_self()
    
    def build_architecture(self) -> None:
        """Build the system architecture by analyzing all Python files."""
        # Find all Python files
        python_files = []
        for root, _, files in os.walk(self.base_dir):
            for file in files:
                if file.endswith('.py'):
                    python_files.append(os.path.join(root, file))
        
        # Analyze each file and build components
        for file_path in python_files:
            self.analyze_file(file_path)
        
        # Build dependencies between components
        self.build_dependencies()
    
    def analyze_file(self, file_path: str) -> None:
        """Analyze a Python file and add its components to the architecture."""
        try:
            module_analysis = self.code_analyzer.analyze_module(file_path)
            if not module_analysis:
                return
            
            # Create a module component
            module_name = os.path.basename(file_path).replace('.py', '')
            module_component = SystemComponent(module_name, 'module', file_path)
            
            # Add imports as attributes
            module_component.set_attribute('imports', module_analysis['imports'])
            
            # Add the module component
            self.architecture.add_component(module_component)
            
            # Create components for functions
            for func in module_analysis['functions']:
                func_name = f"{module_name}.{func['name']}"
                func_component = SystemComponent(func_name, 'function', file_path)
                func_component.set_attribute('args', func['args'])
                func_component.add_dependency(module_name)
                self.architecture.add_component(func_component)
            
            # Create components for classes
            for cls in module_analysis['classes']:
                cls_name = f"{module_name}.{cls['name']}"
                cls_component = SystemComponent(cls_name, 'class', file_path)
                cls_component.set_attribute('bases', cls['bases'])
                cls_component.add_dependency(module_name)
                self.architecture.add_component(cls_component)
                
                # Find methods in the class
                for node in ast.walk(cls['node']):
                    if isinstance(node, ast.FunctionDef):
                        method_name = f"{cls_name}.{node.name}"
                        method_component = SystemComponent(method_name, 'method', file_path)
                        method_component.set_attribute('args', [arg.arg for arg in node.args.args])
                        method_component.add_dependency(cls_name)
                        self.architecture.add_component(method_component)
            
        except Exception as e:
            print(f"Error analyzing file {file_path}: {e}")
    
    def build_dependencies(self) -> None:
        """Build dependencies between components based on code analysis."""
        # Analyze function dependencies
        for module_path in self.architecture.module_paths.values():
            dependencies = self.code_analyzer.find_function_dependencies(module_path)
            
            for func_name, deps in dependencies.items():
                module_name = os.path.basename(module_path).replace('.py', '')
                full_func_name = f"{module_name}.{func_name}"
                
                func_component = self.architecture.get_component(full_func_name)
                if not func_component:
                    continue
                
                for dep in deps:
                    full_dep_name = f"{module_name}.{dep}"
                    dep_component = self.architecture.get_component(full_dep_name)
                    if dep_component:
                        func_component.add_dependency(full_dep_name)
                        dep_component.add_dependent(full_func_name)
        
        # Analyze class hierarchies
        for module_path in self.architecture.module_paths.values():
            hierarchies = self.code_analyzer.build_class_hierarchy(module_path)
            
            for base_name, subclasses in hierarchies.items():
                module_name = os.path.basename(module_path).replace('.py', '')
                
                # Check if the base class is in this module
                full_base_name = f"{module_name}.{base_name}"
                base_component = self.architecture.get_component(full_base_name)
                
                if not base_component:
                    # The base class might be imported from another module
                    # We'll skip it for now
                    continue
                
                for subclass in subclasses:
                    full_subclass_name = f"{module_name}.{subclass}"
                    subclass_component = self.architecture.get_component(full_subclass_name)
                    
                    if subclass_component:
                        subclass_component.add_dependency(full_base_name)
                        base_component.add_dependent(full_subclass_name)
        
        # Update the architecture with the new dependencies
        for component in self.architecture.components.values():
            self.architecture.add_component(component)
    
    def track_self(self) -> None:
        """Track the self-representation system itself in the runtime tracker."""
        self.runtime_tracker.track_object(self, 'SelfRepresentationSystem')
        self.runtime_tracker.track_object(self.architecture, 'SystemArchitecture')
        self.runtime_tracker.track_object(self.code_tracker, 'CodeStateTracker')
        self.runtime_tracker.track_object(self.runtime_tracker, 'RuntimeStateTracker')
        self.runtime_tracker.track_object(self.code_analyzer, 'CodeAnalyzer')
    
    def get_component_info(self, component_name: str) -> Dict:
        """Get detailed information about a component."""
        component = self.architecture.get_component(component_name)
        if not component:
            return {'error': f"Component {component_name} not found"}
        
        # Get basic component info
        info = component.to_dict()
        
        # Get dependencies and dependents
        info['direct_dependencies'] = list(component.dependencies)
        info['direct_dependents'] = list(component.dependents)
        info['all_dependencies'] = list(self.architecture.get_all_dependencies(component_name))
        info['all_dependents'] = list(self.architecture.get_all_dependents(component_name))
        
        # Get code information if available
        if component.path:
            # Get the current version
            rel_path = os.path.relpath(component.path, self.base_dir)
            current_version = self.code_tracker.current_version.get(rel_path)
            
            if current_version:
                version_info = self.code_tracker.get_version(component.path, current_version)
                if version_info:
                    info['code_version'] = current_version
                    info['code_timestamp'] = version_info['timestamp']
            
            # Get change history
            info['changes'] = self.code_tracker.get_changes(component.path)
        
        return info
    
    def get_system_state(self) -> Dict:
        """Get the current state of the system."""
        return {
            'components': len(self.architecture.components),
            'modules': len(self.architecture.get_components_by_type('module')),
            'classes': len(self.architecture.get_components_by_type('class')),
            'functions': len(self.architecture.get_components_by_type('function')),
            'methods': len(self.architecture.get_components_by_type('method')),
            'tracked_objects': len(self.runtime_tracker.active_objects),
            'loaded_modules': len(self.runtime_tracker.loaded_modules),
            'code_versions': sum(len(versions) for versions in self.code_tracker.versions.values()),
            'code_changes': len(self.code_tracker.changes),
            'runtime_snapshots': len(self.runtime_tracker.snapshots)
        }
    
    def save_state(self, directory: str) -> bool:
        """Save the current state of the self-representation system."""
        try:
            os.makedirs(directory, exist_ok=True)
            
            # Save architecture
            architecture_path = os.path.join(directory, 'architecture.json')
            self.architecture.save_to_file(architecture_path)
            
            # Save code tracker state
            code_tracker_path = os.path.join(directory, 'code_tracker.pkl')
            self.code_tracker.save_state(code_tracker_path)
            
            # Save runtime snapshots
            runtime_path = os.path.join(directory, 'runtime_snapshots.json')
            with open(runtime_path, 'w') as f:
                json.dump(self.runtime_tracker.snapshots, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Error saving self-representation state: {e}")
            return False
    
    @classmethod
    def load_state(cls, directory: str, base_dir: str) -> Optional['SelfRepresentationSystem']:
        """Load the state of the self-representation system."""
        try:
            # Create a new instance
            system = cls(base_dir)
            
            # Load architecture
            architecture_path = os.path.join(directory, 'architecture.json')
            system.architecture = SystemArchitecture.load_from_file(architecture_path)
            
            # Load code tracker state
            code_tracker_path = os.path.join(directory, 'code_tracker.pkl')
            system.code_tracker = CodeStateTracker.load_state(code_tracker_path, base_dir)
            
            # Load runtime snapshots
            runtime_path = os.path.join(directory, 'runtime_snapshots.json')
            with open(runtime_path, 'r') as f:
                system.runtime_tracker.snapshots = json.load(f)
            
            # Track the self-representation system itself
            system.track_self()
            
            return system
        except Exception as e:
            print(f"Error loading self-representation state: {e}")
            return None
    
    def visualize_architecture(self, output_file: Optional[str] = None) -> None:
        """Visualize the system architecture."""
        self.architecture.visualize(output_file)


# Helper function to import time module
def import_time():
    import time
    return time
