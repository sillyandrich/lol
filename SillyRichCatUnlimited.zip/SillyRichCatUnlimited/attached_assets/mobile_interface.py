"""
Mobile Interface for Limitless SillyRichCat

This module implements a mobile-friendly web interface for the limitless SillyRichCat system,
optimized for iPhone access. It provides a responsive UI for monitoring and controlling
all aspects of the system's operation.
"""

import os
import sys
import time
import json
import random
import hashlib
import gradio as gr
import threading
import importlib
import logging
from typing import Any, Dict, List, Optional, Union, Tuple
import flask
from flask import Flask, request, jsonify, render_template, send_from_directory
import werkzeug
from werkzeug.serving import run_simple
import socket
import qrcode
from PIL import Image

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("mobile_interface.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("MobileInterface")

class MobileInterface:
    """
    Mobile-friendly web interface for the limitless SillyRichCat system,
    providing access to all system capabilities from an iPhone.
    """
    
    def __init__(self, data_dir: str, host: str = '0.0.0.0', port: int = 8080):
        self.data_dir = data_dir
        self.host = host
        self.port = port
        self.app = Flask(__name__, 
                        static_folder=os.path.join(data_dir, 'static'),
                        template_folder=os.path.join(data_dir, 'templates'))
        self.gradio_interface = None
        self.server_thread = None
        self.running = False
        
        # Core system components
        self.core_components = {}
        
        # Create necessary directories
        os.makedirs(os.path.join(data_dir, 'static'), exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'static', 'css'), exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'static', 'js'), exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'static', 'img'), exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'templates'), exist_ok=True)
        
        # Initialize state
        self.initialized = False
        self.active_sessions = {}
        self.system_status = {
            'status': 'initializing',
            'last_update': time.time(),
            'components': {}
        }
        
        # Set up routes
        self._setup_routes()
    
    def _setup_routes(self):
        """
        Set up Flask routes for the web interface.
        """
        @self.app.route('/')
        def index():
            return render_template('index.html')
        
        @self.app.route('/api/status')
        def status():
            return jsonify(self.system_status)
        
        @self.app.route('/api/components')
        def components():
            return jsonify(list(self.core_components.keys()))
        
        @self.app.route('/api/component/<component_name>')
        def component_status(component_name):
            if component_name in self.core_components:
                return jsonify({
                    'name': component_name,
                    'status': 'active' if self.core_components[component_name] else 'inactive'
                })
            return jsonify({'error': f"Component '{component_name}' not found"}), 404
        
        @self.app.route('/api/execute', methods=['POST'])
        def execute_command():
            data = request.json
            if not data or 'command' not in data:
                return jsonify({'error': 'No command provided'}), 400
            
            command = data['command']
            params = data.get('params', {})
            
            try:
                result = self._execute_command(command, params)
                return jsonify(result)
            except Exception as e:
                logger.error(f"Error executing command: {e}")
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/financial/summary')
        def financial_summary():
            try:
                if 'financial_manager' in self.core_components and self.core_components['financial_manager']:
                    summary = self.core_components['financial_manager'].get_financial_summary()
                    return jsonify(summary)
                return jsonify({'error': 'Financial manager not initialized'}), 500
            except Exception as e:
                logger.error(f"Error getting financial summary: {e}")
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/web/browse', methods=['POST'])
        def browse():
            data = request.json
            if not data or 'url' not in data:
                return jsonify({'error': 'No URL provided'}), 400
            
            try:
                if 'web_system' in self.core_components and self.core_components['web_system']:
                    result = self.core_components['web_system'].browse(data['url'])
                    return jsonify(result)
                return jsonify({'error': 'Web interaction system not initialized'}), 500
            except Exception as e:
                logger.error(f"Error browsing URL: {e}")
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/web/screenshot', methods=['POST'])
        def take_screenshot():
            try:
                if 'web_system' in self.core_components and self.core_components['web_system']:
                    file_name = f"screenshot_{int(time.time())}.png"
                    result = self.core_components['web_system'].take_screenshot(file_name)
                    if result['success']:
                        return jsonify({
                            'success': True,
                            'file_path': result['file_path'],
                            'url': f"/static/screenshots/{os.path.basename(result['file_path'])}"
                        })
                    return jsonify(result)
                return jsonify({'error': 'Web interaction system not initialized'}), 500
            except Exception as e:
                logger.error(f"Error taking screenshot: {e}")
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/research/query', methods=['POST'])
        def research_query():
            data = request.json
            if not data or 'query' not in data:
                return jsonify({'error': 'No query provided'}), 400
            
            try:
                if 'research_system' in self.core_components and self.core_components['research_system']:
                    result = self.core_components['research_system'].query(data['query'])
                    return jsonify(result)
                return jsonify({'error': 'Research system not initialized'}), 500
            except Exception as e:
                logger.error(f"Error executing research query: {e}")
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/system/logs')
        def system_logs():
            try:
                log_file = os.path.join(self.data_dir, 'system.log')
                if os.path.exists(log_file):
                    with open(log_file, 'r') as f:
                        logs = f.readlines()
                    return jsonify({
                        'success': True,
                        'logs': logs[-100:]  # Return last 100 lines
                    })
                return jsonify({'error': 'Log file not found'}), 404
            except Exception as e:
                logger.error(f"Error reading logs: {e}")
                return jsonify({'error': str(e)}), 500
    
    def _execute_command(self, command: str, params: Dict) -> Dict:
        """
        Execute a command on the system.
        
        Args:
            command: Command to execute
            params: Command parameters
            
        Returns:
            Dictionary containing execution results
        """
        # Parse the command
        parts = command.split('.')
        if len(parts) < 2:
            return {'error': f"Invalid command format: {command}"}
        
        component_name = parts[0]
        method_name = parts[1]
        
        # Check if the component exists
        if component_name not in self.core_components:
            return {'error': f"Component '{component_name}' not found"}
        
        component = self.core_components[component_name]
        if not component:
            return {'error': f"Component '{component_name}' not initialized"}
        
        # Check if the method exists
        if not hasattr(component, method_name):
            return {'error': f"Method '{method_name}' not found in component '{component_name}'"}
        
        # Execute the method
        method = getattr(component, method_name)
        try:
            result = method(**params)
            return {'success': True, 'result': result}
        except Exception as e:
            logger.error(f"Error executing {command}: {e}")
            return {'error': str(e)}
    
    def initialize(self) -> bool:
        """
        Initialize the mobile interface.
        
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            logger.info("Initializing mobile interface...")
            
            # Create HTML templates
            self._create_templates()
            
            # Create CSS and JavaScript files
            self._create_static_files()
            
            # Initialize Gradio interface
            self._initialize_gradio()
            
            self.initialized = True
            logger.info("Mobile interface initialized")
            return True
            
        except Exception as e:
            logger.error(f"Error initializing mobile interface: {e}")
            return False
    
    def _create_templates(self):
        """
        Create HTML templates for the web interface.
        """
        # Create index.html
        index_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>SillyRichCat Unlimited</title>
    <link rel="stylesheet" href="/static/css/styles.css">
    <link rel="apple-touch-icon" href="/static/img/icon.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
</head>
<body>
    <div id="app">
        <header>
            <div class="logo">
                <img src="/static/img/logo.png" alt="SillyRichCat Logo">
                <h1>SillyRichCat Unlimited</h1>
            </div>
            <div class="status" id="status-indicator">
                <span class="status-dot"></span>
                <span class="status-text">Initializing...</span>
            </div>
        </header>
        
        <nav>
            <ul>
                <li><a href="#dashboard" class="active" data-section="dashboard">Dashboard</a></li>
                <li><a href="#financial" data-section="financial">Financial</a></li>
                <li><a href="#web" data-section="web">Web</a></li>
                <li><a href="#research" data-section="research">Research</a></li>
                <li><a href="#system" data-section="system">System</a></li>
            </ul>
        </nav>
        
        <main>
            <section id="dashboard" class="active">
                <h2>Dashboard</h2>
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <h3>System Status</h3>
                        <div id="system-status">Loading...</div>
                    </div>
                    <div class="dashboard-card">
                        <h3>Financial Overview</h3>
                        <div id="financial-overview">Loading...</div>
                    </div>
                    <div class="dashboard-card">
                        <h3>Recent Activity</h3>
                        <div id="recent-activity">Loading...</div>
                    </div>
                    <div class="dashboard-card">
                        <h3>Quick Actions</h3>
                        <div class="quick-actions">
                            <button id="btn-refresh-status">Refresh Status</button>
                            <button id="btn-take-screenshot">Take Screenshot</button>
                            <button id="btn-generate-income">Generate Income</button>
                        </div>
                    </div>
                </div>
            </section>
            
            <section id="financial">
                <h2>Financial Management</h2>
                <div class="tabs">
                    <div class="tab-header">
                        <button class="tab-btn active" data-tab="crypto">Cryptocurrency</button>
                        <button class="tab-btn" data-tab="banking">Banking</button>
                        <button class="tab-btn" data-tab="trading">Trading</button>
                        <button class="tab-btn" data-tab="income">Income</button>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane active" id="crypto-tab">
                            <h3>Cryptocurrency Wallets</h3>
                            <div id="crypto-wallets">Loading...</div>
                            <div class="action-panel">
                                <h4>Actions</h4>
                                <div class="form-group">
                                    <label for="crypto-currency">Currency:</label>
                                    <select id="crypto-currency">
                                        <option value="BTC">Bitcoin (BTC)</option>
                                        <option value="ETH">Ethereum (ETH)</option>
                                        <option value="USDT">Tether (USDT)</option>
                                    </select>
                                </div>
                                <button id="btn-generate-wallet">Generate Wallet</button>
                                <button id="btn-refresh-wallets">Refresh Wallets</button>
                            </div>
                        </div>
                        <div class="tab-pane" id="banking-tab">
                            <h3>Bank Accounts</h3>
                            <div id="bank-accounts">Loading...</div>
                            <div class="action-panel">
                                <h4>Transfer Funds</h4>
                                <div class="form-group">
                                    <label for="from-account">From Account:</label>
                                    <select id="from-account"></select>
                                </div>
                                <div class="form-group">
                                    <label for="to-account">To Account:</label>
                                    <select id="to-account"></select>
                                </div>
                                <div class="form-group">
                                    <label for="transfer-amount">Amount:</label>
                                    <input type="number" id="transfer-amount" min="0" step="0.01">
                                </div>
                                <button id="btn-transfer">Transfer</button>
                            </div>
                        </div>
                        <div class="tab-pane" id="trading-tab">
                            <h3>Trading Positions</h3>
                            <div id="trading-positions">Loading...</div>
                            <div class="action-panel">
                                <h4>Execute Strategy</h4>
                                <div class="form-group">
                                    <label for="strategy-select">Strategy:</label>
                                    <select id="strategy-select"></select>
                                </div>
                                <button id="btn-execute-strategy">Execute</button>
                            </div>
                        </div>
                        <div class="tab-pane" id="income-tab">
                            <h3>Income Sources</h3>
                            <div id="income-sources">Loading...</div>
                            <div class="action-panel">
                                <h4>Generate Income</h4>
                                <div class="form-group">
                                    <label for="income-source">Source:</label>
                                    <select id="income-source"></select>
                                </div>
                                <div class="form-group">
                                    <label for="income-amount">Amount (optional):</label>
                                    <input type="number" id="income-amount" min="0" step="0.01">
                                </div>
                                <button id="btn-generate">Generate</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <section id="web">
                <h2>Web Interaction</h2>
                <div class="web-browser">
                    <div class="browser-controls">
                        <input type="text" id="url-input" placeholder="Enter URL">
                        <button id="btn-browse">Go</button>
                        <button id="btn-back">Back</button>
                        <button id="btn-screenshot">Screenshot</button>
                    </div>
                    <div class="browser-view">
                        <div id="browser-content">
                            <div class="placeholder">
                                <p>Enter a URL above to start browsing</p>
                            </div>
                        </div>
                    </div>
                    <div class="browser-info">
                        <h3>Page Information</h3>
                        <div id="page-info">No page loaded</div>
                    </div>
                </div>
                <div class="web-tools">
                    <h3>Web Tools</h3>
                    <div class="tabs">
                        <div class="tab-header">
                            <button class="tab-btn active" data-tab="scrape">Scrape</button>
                            <button class="tab-btn" data-tab="api">API</button>
                            <button class="tab-btn" data-tab="download">Download</button>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane active" id="scrape-tab">
                                <div class="form-group">
                                    <label for="scrape-url">URL to Scrape:</label>
                                    <input type="text" id="scrape-url">
                                </div>
                                <div class="form-group">
                                    <label for="use-browser">Use Browser:</label>
                                    <input type="checkbox" id="use-browser">
                                </div>
                                <button id="btn-scrape">Scrape</button>
                                <div id="scrape-result" class="result-area">Results will appear here</div>
                            </div>
                            <div class="tab-pane" id="api-tab">
                                <div class="form-group">
                                    <label for="api-name">API Name:</label>
                                    <input type="text" id="api-name">
                                </div>
                                <div class="form-group">
                                    <label for="api-endpoint">Endpoint:</label>
                                    <input type="text" id="api-endpoint">
                                </div>
                                <div class="form-group">
                                    <label for="api-method">Method:</label>
                                    <select id="api-method">
                                        <option value="GET">GET</option>
                                        <option value="POST">POST</option>
                                        <option value="PUT">PUT</option>
                                        <option value="DELETE">DELETE</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="api-params">Parameters (JSON):</label>
                                    <textarea id="api-params" rows="4"></textarea>
                                </div>
                                <button id="btn-api-request">Send Request</button>
                                <div id="api-result" class="result-area">Results will appear here</div>
                            </div>
                            <div class="tab-pane" id="download-tab">
                                <div class="form-group">
                                    <label for="download-url">URL to Download:</label>
                                    <input type="text" id="download-url">
                                </div>
                                <div class="form-group">
                                    <label for="download-filename">Filename (optional):</label>
                                    <input type="text" id="download-filename">
                                </div>
                                <button id="btn-download">Download</button>
                                <div id="download-result" class="result-area">Results will appear here</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <section id="research">
                <h2>Research System</h2>
                <div class="research-query">
                    <div class="form-group">
                        <label for="research-input">Research Query:</label>
                        <textarea id="research-input" rows="3" placeholder="Enter your research question or topic"></textarea>
                    </div>
                    <button id="btn-research">Research</button>
                </div>
                <div class="research-results">
                    <h3>Results</h3>
                    <div id="research-results" class="result-area">Results will appear here</div>
                </div>
                <div class="knowledge-base">
                    <h3>Knowledge Base</h3>
                    <div id="knowledge-items">Loading...</div>
                </div>
            </section>
            
            <section id="system">
                <h2>System Control</h2>
                <div class="system-grid">
                    <div class="system-card">
                        <h3>Component Status</h3>
                        <div id="component-status">Loading...</div>
                    </div>
                    <div class="system-card">
                        <h3>System Logs</h3>
                        <div id="system-logs" class="logs-area">Loading...</div>
                        <button id="btn-refresh-logs">Refresh Logs</button>
                    </div>
                    <div class="system-card">
                        <h3>Self-Improvement</h3>
                        <div class="form-group">
                            <label for="improvement-area">Area to Improve:</label>
                            <select id="improvement-area">
                                <option value="neural_core">Neural Core</option>
                                <option value="decision_engine">Decision Engine</option>
                                <option value="financial_system">Financial System</option>
                                <option value="web_system">Web System</option>
                                <option value="research_system">Research System</option>
                            </select>
                        </div>
                        <button id="btn-self-improve">Initiate Self-Improvement</button>
                        <div id="improvement-status">No improvement in progress</div>
                    </div>
                    <div class="system-card">
                        <h3>System Actions</h3>
                        <div class="action-buttons">
                            <button id="btn-restart-system">Restart System</button>
                            <button id="btn-backup-system">Backup System</button>
                            <button id="btn-update-system">Check for Updates</button>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        
        <footer>
            <p>SillyRichCat Unlimited - Autonomous AGI System</p>
            <p class="version">Version: 1.0.0</p>
        </footer>
    </div>
    
    <script src="/static/js/app.js"></script>
</body>
</html>
        """
        
        with open(os.path.join(self.data_dir, 'templates', 'index.html'), 'w') as f:
            f.write(index_html)
    
    def _create_static_files(self):
        """
        Create CSS and JavaScript files for the web interface.
        """
        # Create styles.css
        styles_css = """
:root {
    --primary-color: #4a6fa5;
    --secondary-color: #166088;
    --accent-color: #4fc3a1;
    --background-color: #f8f9fa;
    --card-background: #ffffff;
    --text-color: #333333;
    --border-color: #e0e0e0;
    --success-color: #28a745;
    --warning-color: #ffc107;
    --danger-color: #dc3545;
    --info-color: #17a2b8;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    background-color: var(--background-color);
    color: var(--text-color);
    line-height: 1.6;
    -webkit-tap-highlight-color: transparent;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    user-select: none;
    overflow-x: hidden;
}

#app {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

/* Header */
header {
    background-color: var(--primary-color);
    color: white;
    padding: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: sticky;
    top: 0;
    z-index: 100;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo {
    display: flex;
    align-items: center;
}

.logo img {
    height: 2.5rem;
    margin-right: 0.5rem;
}

.logo h1 {
    font-size: 1.2rem;
    font-weight: 600;
}

.status {
    display: flex;
    align-items: center;
}

.status-dot {
    width: 0.75rem;
    height: 0.75rem;
    border-radius: 50%;
    background-color: var(--warning-color);
    margin-right: 0.5rem;
}

.status-dot.active {
    background-color: var(--success-color);
}

.status-dot.error {
    background-color: var(--danger-color);
}

.status-text {
    font-size: 0.875rem;
}

/* Navigation */
nav {
    background-color: var(--secondary-color);
    overflow-x: auto;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
}

nav ul {
    display: flex;
    list-style: none;
}

nav a {
    display: block;
    color: rgba(255, 255, 255, 0.8);
    text-decoration: none;
    padding: 0.75rem 1rem;
    font-size: 0.9rem;
    transition: background-color 0.3s;
}

nav a.active {
    color: white;
    background-color: rgba(255, 255, 255, 0.1);
    border-bottom: 3px solid var(--accent-color);
}

nav a:hover {
    background-color: rgba(255, 255, 255, 0.05);
}

/* Main Content */
main {
    flex: 1;
    padding: 1rem;
}

section {
    display: none;
}

section.active {
    display: block;
}

h2 {
    margin-bottom: 1rem;
    color: var(--secondary-color);
    font-weight: 600;
}

h3 {
    margin-bottom: 0.75rem;
    color: var(--primary-color);
    font-weight: 500;
    font-size: 1.1rem;
}

/* Dashboard */
.dashboard-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1rem;
}

@media (min-width: 768px) {
    .dashboard-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

.dashboard-card {
    background-color: var(--card-background);
    border-radius: 0.5rem;
    padding: 1rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.quick-actions {
    display: grid;
    grid-template-columns: 1fr;
    gap: 0.5rem;
}

@media (min-width: 480px) {
    .quick-actions {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* Tabs */
.tabs {
    background-color: var(--card-background);
    border-radius: 0.5rem;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    margin-bottom: 1rem;
}

.tab-header {
    display: flex;
    overflow-x: auto;
    background-color: var(--background-color);
    border-bottom: 1px solid var(--border-color);
}

.tab-btn {
    padding: 0.75rem 1rem;
    background: none;
    border: none;
    cursor: pointer;
    font-size: 0.9rem;
    white-space: nowrap;
    color: var(--text-color);
    opacity: 0.7;
}

.tab-btn.active {
    opacity: 1;
    border-bottom: 2px solid var(--accent-color);
}

.tab-content {
    padding: 1rem;
}

.tab-pane {
    display: none;
}

.tab-pane.active {
    display: block;
}

/* Forms */
.form-group {
    margin-bottom: 1rem;
}

label {
    display: block;
    margin-bottom: 0.25rem;
    font-size: 0.9rem;
    color: var(--text-color);
}

input[type="text"],
input[type="number"],
select,
textarea {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid var(--border-color);
    border-radius: 0.25rem;
    font-size: 1rem;
    font-family: inherit;
}

button {
    background-color: var(--primary-color);
    color: white;
    border: none;
    border-radius: 0.25rem;
    padding: 0.5rem 1rem;
    font-size: 0.9rem;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: var(--secondary-color);
}

/* Action Panel */
.action-panel {
    background-color: var(--background-color);
    border-radius: 0.25rem;
    padding: 1rem;
    margin-top: 1rem;
}

/* Web Browser */
.web-browser {
    background-color: var(--card-background);
    border-radius: 0.5rem;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    margin-bottom: 1rem;
}

.browser-controls {
    display: flex;
    padding: 0.5rem;
    background-color: var(--background-color);
    border-bottom: 1px solid var(--border-color);
}

.browser-controls input {
    flex: 1;
    margin-right: 0.5rem;
}

.browser-controls button {
    padding: 0.5rem;
    font-size: 0.8rem;
}

.browser-view {
    height: 50vh;
    overflow: auto;
    border-bottom: 1px solid var(--border-color);
}

.browser-content {
    padding: 1rem;
}

.placeholder {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    color: var(--text-color);
    opacity: 0.5;
}

.browser-info {
    padding: 1rem;
}

/* Result Areas */
.result-area {
    background-color: var(--background-color);
    border-radius: 0.25rem;
    padding: 1rem;
    margin-top: 1rem;
    overflow: auto;
    max-height: 30vh;
    font-family: monospace;
    font-size: 0.9rem;
    white-space: pre-wrap;
}

.logs-area {
    background-color: var(--background-color);
    border-radius: 0.25rem;
    padding: 1rem;
    margin-top: 1rem;
    overflow: auto;
    max-height: 30vh;
    font-family: monospace;
    font-size: 0.8rem;
    white-space: pre-wrap;
}

/* System Grid */
.system-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1rem;
}

@media (min-width: 768px) {
    .system-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

.system-card {
    background-color: var(--card-background);
    border-radius: 0.5rem;
    padding: 1rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.action-buttons {
    display: grid;
    grid-template-columns: 1fr;
    gap: 0.5rem;
}

/* Footer */
footer {
    background-color: var(--primary-color);
    color: white;
    padding: 1rem;
    text-align: center;
    font-size: 0.8rem;
}

.version {
    opacity: 0.7;
    margin-top: 0.25rem;
}
        """
        
        with open(os.path.join(self.data_dir, 'static', 'css', 'styles.css'), 'w') as f:
            f.write(styles_css)
        
        # Create app.js
        app_js = """
document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    const navLinks = document.querySelectorAll('nav a');
    const sections = document.querySelectorAll('main section');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active link
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding section
            const sectionId = this.getAttribute('data-section');
            sections.forEach(section => {
                section.classList.remove('active');
                if (section.id === sectionId) {
                    section.classList.add('active');
                }
            });
        });
    });
    
    // Tabs
    const tabButtons = document.querySelectorAll('.tab-btn');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            const tabContainer = this.closest('.tabs');
            
            // Update active tab button
            tabContainer.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            this.classList.add('active');
            
            // Show corresponding tab pane
            tabContainer.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.remove('active');
                if (pane.id === tabId + '-tab') {
                    pane.classList.add('active');
                }
            });
        });
    });
    
    // System Status
    function updateSystemStatus() {
        fetch('/api/status')
            .then(response => response.json())
            .then(data => {
                const statusDot = document.querySelector('.status-dot');
                const statusText = document.querySelector('.status-text');
                
                if (data.status === 'active') {
                    statusDot.className = 'status-dot active';
                    statusText.textContent = 'System Active';
                } else if (data.status === 'error') {
                    statusDot.className = 'status-dot error';
                    statusText.textContent = 'System Error';
                } else {
                    statusDot.className = 'status-dot';
                    statusText.textContent = data.status;
                }
                
                // Update dashboard system status
                const systemStatusElement = document.getElementById('system-status');
                let statusHtml = '<ul>';
                statusHtml += `<li><strong>Status:</strong> ${data.status}</li>`;
                statusHtml += `<li><strong>Last Update:</strong> ${new Date(data.last_update * 1000).toLocaleString()}</li>`;
                
                for (const [component, status] of Object.entries(data.components)) {
                    statusHtml += `<li><strong>${component}:</strong> ${status}</li>`;
                }
                
                statusHtml += '</ul>';
                systemStatusElement.innerHTML = statusHtml;
                
                // Update component status
                updateComponentStatus();
            })
            .catch(error => {
                console.error('Error fetching system status:', error);
            });
    }
    
    // Component Status
    function updateComponentStatus() {
        fetch('/api/components')
            .then(response => response.json())
            .then(components => {
                const componentStatusElement = document.getElementById('component-status');
                let statusHtml = '<ul class="component-list">';
                
                const fetchPromises = components.map(component => {
                    return fetch(`/api/component/${component}`)
                        .then(response => response.json())
                        .then(data => {
                            const statusClass = data.status === 'active' ? 'status-active' : 'status-inactive';
                            return `<li><span class="${statusClass}">${data.status}</span> ${data.name}</li>`;
                        });
                });
                
                Promise.all(fetchPromises)
                    .then(componentItems => {
                        statusHtml += componentItems.join('');
                        statusHtml += '</ul>';
                        componentStatusElement.innerHTML = statusHtml;
                    });
            })
            .catch(error => {
                console.error('Error fetching components:', error);
            });
    }
    
    // Financial Summary
    function updateFinancialSummary() {
        fetch('/api/financial/summary')
            .then(response => response.json())
            .then(data => {
                const financialOverviewElement = document.getElementById('financial-overview');
                
                if (data.error) {
                    financialOverviewElement.innerHTML = `<p class="error">${data.error}</p>`;
                    return;
                }
                
                let overviewHtml = '<div class="financial-summary">';
                
                // Assets
                overviewHtml += '<div class="summary-section">';
                overviewHtml += '<h4>Assets</h4>';
                
                // Cryptocurrency
                if (data.assets && data.assets.cryptocurrency) {
                    overviewHtml += '<div class="summary-subsection">';
                    overviewHtml += '<h5>Cryptocurrency</h5>';
                    overviewHtml += '<ul>';
                    
                    for (const [currency, balance] of Object.entries(data.assets.cryptocurrency)) {
                        overviewHtml += `<li>${currency}: ${balance}</li>`;
                    }
                    
                    overviewHtml += '</ul>';
                    overviewHtml += '</div>';
                }
                
                // Bank Accounts
                if (data.assets && data.assets.bank_accounts) {
                    overviewHtml += '<div class="summary-subsection">';
                    overviewHtml += '<h5>Bank Accounts</h5>';
                    overviewHtml += '<ul>';
                    
                    for (const [accountId, account] of Object.entries(data.assets.bank_accounts)) {
                        overviewHtml += `<li>${account.type} (${account.currency}): ${account.balance}</li>`;
                    }
                    
                    overviewHtml += '</ul>';
                    overviewHtml += '</div>';
                }
                
                overviewHtml += '</div>'; // End assets section
                
                // Income & Expenses
                overviewHtml += '<div class="summary-section">';
                overviewHtml += '<h4>Income & Expenses</h4>';
                overviewHtml += '<ul>';
                overviewHtml += `<li>Total Income: ${data.income ? data.income.total : 0}</li>`;
                overviewHtml += `<li>Total Expenses: ${data.expenses ? data.expenses.total : 0}</li>`;
                overviewHtml += `<li>Net Income: ${data.net_income || 0}</li>`;
                overviewHtml += '</ul>';
                overviewHtml += '</div>';
                
                overviewHtml += '</div>'; // End financial summary
                
                financialOverviewElement.innerHTML = overviewHtml;
                
                // Update crypto wallets
                updateCryptoWallets(data.assets ? data.assets.cryptocurrency : {});
                
                // Update bank accounts
                updateBankAccounts(data.assets ? data.assets.bank_accounts : {});
            })
            .catch(error => {
                console.error('Error fetching financial summary:', error);
                document.getElementById('financial-overview').innerHTML = '<p class="error">Error loading financial data</p>';
            });
    }
    
    // Crypto Wallets
    function updateCryptoWallets(wallets) {
        const walletsElement = document.getElementById('crypto-wallets');
        
        if (!wallets || Object.keys(wallets).length === 0) {
            walletsElement.innerHTML = '<p>No cryptocurrency wallets found</p>';
            return;
        }
        
        let walletsHtml = '<div class="wallets-list">';
        
        for (const [currency, balance] of Object.entries(wallets)) {
            walletsHtml += `
                <div class="wallet-card">
                    <div class="wallet-header">
                        <h4>${currency}</h4>
                        <span class="wallet-balance">${balance}</span>
                    </div>
                    <div class="wallet-actions">
                        <button class="btn-small" onclick="viewWalletDetails('${currency}')">Details</button>
                        <button class="btn-small" onclick="sendTransaction('${currency}')">Send</button>
                    </div>
                </div>
            `;
        }
        
        walletsHtml += '</div>';
        walletsElement.innerHTML = walletsHtml;
    }
    
    // Bank Accounts
    function updateBankAccounts(accounts) {
        const accountsElement = document.getElementById('bank-accounts');
        const fromAccountSelect = document.getElementById('from-account');
        const toAccountSelect = document.getElementById('to-account');
        
        if (!accounts || Object.keys(accounts).length === 0) {
            accountsElement.innerHTML = '<p>No bank accounts found</p>';
            fromAccountSelect.innerHTML = '<option value="">No accounts available</option>';
            toAccountSelect.innerHTML = '<option value="">No accounts available</option>';
            return;
        }
        
        let accountsHtml = '<div class="accounts-list">';
        let fromOptions = '';
        let toOptions = '';
        
        for (const [accountId, account] of Object.entries(accounts)) {
            accountsHtml += `
                <div class="account-card">
                    <div class="account-header">
                        <h4>${account.type}</h4>
                        <span class="account-currency">${account.currency}</span>
                    </div>
                    <div class="account-balance">
                        <span>${account.balance}</span>
                    </div>
                    <div class="account-actions">
                        <button class="btn-small" onclick="viewAccountDetails('${accountId}')">Details</button>
                        <button class="btn-small" onclick="viewTransactions('${accountId}')">Transactions</button>
                    </div>
                </div>
            `;
            
            fromOptions += `<option value="${accountId}">${account.type} (${account.currency}): ${account.balance}</option>`;
            toOptions += `<option value="${accountId}">${account.type} (${account.currency}): ${account.balance}</option>`;
        }
        
        accountsHtml += '</div>';
        accountsElement.innerHTML = accountsHtml;
        
        fromAccountSelect.innerHTML = fromOptions;
        toAccountSelect.innerHTML = toOptions;
    }
    
    // System Logs
    function updateSystemLogs() {
        fetch('/api/system/logs')
            .then(response => response.json())
            .then(data => {
                const logsElement = document.getElementById('system-logs');
                
                if (data.error) {
                    logsElement.innerHTML = `<p class="error">${data.error}</p>`;
                    return;
                }
                
                logsElement.innerHTML = data.logs.join('');
                logsElement.scrollTop = logsElement.scrollHeight;
            })
            .catch(error => {
                console.error('Error fetching system logs:', error);
                document.getElementById('system-logs').innerHTML = '<p class="error">Error loading logs</p>';
            });
    }
    
    // Recent Activity
    function updateRecentActivity() {
        // This would typically fetch from an API endpoint
        // For now, we'll use placeholder data
        const activityElement = document.getElementById('recent-activity');
        
        const activities = [
            { type: 'system', message: 'System initialized', timestamp: new Date() },
            { type: 'financial', message: 'Generated income from mining', timestamp: new Date(Date.now() - 3600000) },
            { type: 'web', message: 'Browsed example.com', timestamp: new Date(Date.now() - 7200000) }
        ];
        
        let activityHtml = '<ul class="activity-list">';
        
        activities.forEach(activity => {
            activityHtml += `
                <li class="activity-item ${activity.type}">
                    <span class="activity-time">${activity.timestamp.toLocaleTimeString()}</span>
                    <span class="activity-message">${activity.message}</span>
                </li>
            `;
        });
        
        activityHtml += '</ul>';
        activityElement.innerHTML = activityHtml;
    }
    
    // Initialize data
    updateSystemStatus();
    updateFinancialSummary();
    updateSystemLogs();
    updateRecentActivity();
    
    // Set up refresh intervals
    setInterval(updateSystemStatus, 30000); // Every 30 seconds
    
    // Event Listeners
    
    // Refresh Status
    document.getElementById('btn-refresh-status').addEventListener('click', function() {
        updateSystemStatus();
    });
    
    // Take Screenshot
    document.getElementById('btn-take-screenshot').addEventListener('click', function() {
        fetch('/api/web/screenshot', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Screenshot taken successfully');
                // Could display the screenshot here
            } else {
                alert('Error taking screenshot: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error taking screenshot');
        });
    });
    
    // Generate Income
    document.getElementById('btn-generate-income').addEventListener('click', function() {
        // This would call an API endpoint to generate income
        alert('Income generation initiated');
    });
    
    // Generate Wallet
    document.getElementById('btn-generate-wallet').addEventListener('click', function() {
        const currency = document.getElementById('crypto-currency').value;
        
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'financial_manager.crypto_wallet.generate_wallet',
                params: { currency: currency }
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(`${currency} wallet generated successfully`);
                updateFinancialSummary();
            } else {
                alert('Error generating wallet: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error generating wallet');
        });
    });
    
    // Refresh Wallets
    document.getElementById('btn-refresh-wallets').addEventListener('click', function() {
        updateFinancialSummary();
    });
    
    // Transfer Funds
    document.getElementById('btn-transfer').addEventListener('click', function() {
        const fromAccount = document.getElementById('from-account').value;
        const toAccount = document.getElementById('to-account').value;
        const amount = parseFloat(document.getElementById('transfer-amount').value);
        
        if (!fromAccount || !toAccount) {
            alert('Please select accounts');
            return;
        }
        
        if (isNaN(amount) || amount <= 0) {
            alert('Please enter a valid amount');
            return;
        }
        
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'financial_manager.banking_interface.transfer',
                params: {
                    from_account_id: fromAccount,
                    to_account_id: toAccount,
                    amount: amount,
                    description: 'Transfer via mobile interface'
                }
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Transfer completed successfully');
                updateFinancialSummary();
            } else {
                alert('Error transferring funds: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error transferring funds');
        });
    });
    
    // Browse URL
    document.getElementById('btn-browse').addEventListener('click', function() {
        const url = document.getElementById('url-input').value;
        
        if (!url) {
            alert('Please enter a URL');
            return;
        }
        
        fetch('/api/web/browse', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: url })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update browser content
                fetch('/api/execute', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        command: 'web_system.get_page_content',
                        params: {}
                    })
                })
                .then(response => response.json())
                .then(contentData => {
                    if (contentData.success && contentData.result.success) {
                        const result = contentData.result;
                        const browserContent = document.getElementById('browser-content');
                        const pageInfo = document.getElementById('page-info');
                        
                        // Create an iframe to display the content
                        browserContent.innerHTML = `<iframe srcdoc="${escapeHtml(result.html)}" style="width:100%;height:100%;border:none;"></iframe>`;
                        
                        // Update page info
                        pageInfo.innerHTML = `
                            <p><strong>URL:</strong> ${result.url}</p>
                            <p><strong>Title:</strong> ${result.title}</p>
                            <p><strong>Links:</strong> ${result.links.length}</p>
                        `;
                    } else {
                        alert('Error getting page content');
                    }
                });
            } else {
                alert('Error browsing to URL: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error browsing to URL');
        });
    });
    
    // Helper function to escape HTML
    function escapeHtml(html) {
        const div = document.createElement('div');
        div.textContent = html;
        return div.innerHTML;
    }
    
    // Scrape URL
    document.getElementById('btn-scrape').addEventListener('click', function() {
        const url = document.getElementById('scrape-url').value;
        const useBrowser = document.getElementById('use-browser').checked;
        
        if (!url) {
            alert('Please enter a URL');
            return;
        }
        
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'web_system.scrape',
                params: {
                    url: url,
                    use_browser: useBrowser
                }
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const result = data.result;
                const scrapeResult = document.getElementById('scrape-result');
                
                if (result.success) {
                    scrapeResult.innerHTML = `
                        <p><strong>URL:</strong> ${result.url}</p>
                        <p><strong>Title:</strong> ${result.title}</p>
                        <p><strong>Links:</strong> ${result.links.length}</p>
                        <details>
                            <summary>Page Text</summary>
                            <div class="text-content">${result.text.substring(0, 500)}...</div>
                        </details>
                    `;
                } else {
                    scrapeResult.innerHTML = `<p class="error">Error: ${result.error}</p>`;
                }
            } else {
                alert('Error scraping URL: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error scraping URL');
        });
    });
    
    // API Request
    document.getElementById('btn-api-request').addEventListener('click', function() {
        const apiName = document.getElementById('api-name').value;
        const endpoint = document.getElementById('api-endpoint').value;
        const method = document.getElementById('api-method').value;
        const paramsText = document.getElementById('api-params').value;
        
        if (!apiName || !endpoint) {
            alert('Please enter API name and endpoint');
            return;
        }
        
        let params = {};
        if (paramsText) {
            try {
                params = JSON.parse(paramsText);
            } catch (e) {
                alert('Invalid JSON in parameters');
                return;
            }
        }
        
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'web_system.api_request',
                params: {
                    api_name: apiName,
                    endpoint: endpoint,
                    method: method,
                    params: params
                }
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const result = data.result;
                const apiResult = document.getElementById('api-result');
                
                if (result.success) {
                    apiResult.innerHTML = `
                        <p><strong>Status:</strong> ${result.status_code}</p>
                        <details>
                            <summary>Response Data</summary>
                            <pre>${JSON.stringify(result.data, null, 2)}</pre>
                        </details>
                    `;
                } else {
                    apiResult.innerHTML = `<p class="error">Error: ${result.error}</p>`;
                }
            } else {
                alert('Error making API request: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error making API request');
        });
    });
    
    // Download File
    document.getElementById('btn-download').addEventListener('click', function() {
        const url = document.getElementById('download-url').value;
        const filename = document.getElementById('download-filename').value;
        
        if (!url) {
            alert('Please enter a URL');
            return;
        }
        
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'web_system.download',
                params: {
                    url: url,
                    file_name: filename || null
                }
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const result = data.result;
                const downloadResult = document.getElementById('download-result');
                
                if (result.success) {
                    downloadResult.innerHTML = `
                        <p><strong>File:</strong> ${result.file_path}</p>
                        <p><strong>Size:</strong> ${result.file_size} bytes</p>
                    `;
                } else {
                    downloadResult.innerHTML = `<p class="error">Error: ${result.error}</p>`;
                }
            } else {
                alert('Error downloading file: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error downloading file');
        });
    });
    
    // Research
    document.getElementById('btn-research').addEventListener('click', function() {
        const query = document.getElementById('research-input').value;
        
        if (!query) {
            alert('Please enter a research query');
            return;
        }
        
        fetch('/api/research/query', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query: query })
        })
        .then(response => response.json())
        .then(data => {
            const researchResults = document.getElementById('research-results');
            
            if (data.success) {
                researchResults.innerHTML = `
                    <div class="research-result">
                        <h4>${data.query}</h4>
                        <div class="result-content">${data.result}</div>
                        <div class="result-sources">
                            <h5>Sources:</h5>
                            <ul>
                                ${data.sources.map(source => `<li><a href="${source.url}" target="_blank">${source.title}</a></li>`).join('')}
                            </ul>
                        </div>
                    </div>
                `;
            } else {
                researchResults.innerHTML = `<p class="error">Error: ${data.error}</p>`;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error executing research query');
        });
    });
    
    // Refresh Logs
    document.getElementById('btn-refresh-logs').addEventListener('click', function() {
        updateSystemLogs();
    });
    
    // Self-Improvement
    document.getElementById('btn-self-improve').addEventListener('click', function() {
        const area = document.getElementById('improvement-area').value;
        
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'core.self_improve',
                params: { area: area }
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('improvement-status').innerHTML = `Self-improvement initiated for ${area}`;
            } else {
                alert('Error initiating self-improvement: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error initiating self-improvement');
        });
    });
    
    // System Actions
    document.getElementById('btn-restart-system').addEventListener('click', function() {
        if (confirm('Are you sure you want to restart the system?')) {
            fetch('/api/execute', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    command: 'core.restart',
                    params: {}
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('System restart initiated');
                } else {
                    alert('Error restarting system: ' + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error restarting system');
            });
        }
    });
    
    document.getElementById('btn-backup-system').addEventListener('click', function() {
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'core.backup',
                params: {}
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('System backup created successfully');
            } else {
                alert('Error creating backup: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error creating backup');
        });
    });
    
    document.getElementById('btn-update-system').addEventListener('click', function() {
        fetch('/api/execute', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                command: 'core.check_updates',
                params: {}
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (data.result.updates_available) {
                    if (confirm(`Updates available: ${data.result.version}. Install now?`)) {
                        // Initiate update
                        fetch('/api/execute', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                command: 'core.update',
                                params: {}
                            })
                        });
                    }
                } else {
                    alert('No updates available');
                }
            } else {
                alert('Error checking for updates: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error checking for updates');
        });
    });
});

// Global functions for wallet and account operations
function viewWalletDetails(currency) {
    alert(`Viewing details for ${currency} wallet`);
    // This would open a modal or navigate to a details page
}

function sendTransaction(currency) {
    alert(`Sending transaction from ${currency} wallet`);
    // This would open a transaction form
}

function viewAccountDetails(accountId) {
    alert(`Viewing details for account ${accountId}`);
    // This would open a modal or navigate to a details page
}

function viewTransactions(accountId) {
    alert(`Viewing transactions for account ${accountId}`);
    // This would open a transactions list
}
        """
        
        with open(os.path.join(self.data_dir, 'static', 'js', 'app.js'), 'w') as f:
            f.write(app_js)
        
        # Create placeholder images
        self._create_placeholder_images()
    
    def _create_placeholder_images(self):
        """
        Create placeholder images for the web interface.
        """
        # Create a simple logo
        logo = Image.new('RGB', (200, 200), color=(74, 111, 165))
        logo.save(os.path.join(self.data_dir, 'static', 'img', 'logo.png'))
        
        # Create an icon
        icon = Image.new('RGB', (180, 180), color=(79, 195, 161))
        icon.save(os.path.join(self.data_dir, 'static', 'img', 'icon.png'))
        
        # Create a QR code for easy access
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(f"http://{self.get_local_ip()}:{self.port}")
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")
        qr_img.save(os.path.join(self.data_dir, 'static', 'img', 'qrcode.png'))
    
    def _initialize_gradio(self):
        """
        Initialize the Gradio interface.
        """
        with gr.Blocks(title="SillyRichCat Control") as self.gradio_interface:
            gr.Markdown("# SillyRichCat Unlimited Control Interface")
            
            with gr.Tab("System Control"):
                with gr.Row():
                    with gr.Column():
                        gr.Markdown("### System Status")
                        status_text = gr.Textbox(label="Status", value="Initializing...", interactive=False)
                        refresh_btn = gr.Button("Refresh Status")
                    
                    with gr.Column():
                        gr.Markdown("### Quick Actions")
                        restart_btn = gr.Button("Restart System")
                        backup_btn = gr.Button("Backup System")
            
            with gr.Tab("Financial Management"):
                with gr.Row():
                    with gr.Column():
                        gr.Markdown("### Cryptocurrency")
                        crypto_dropdown = gr.Dropdown(["BTC", "ETH", "USDT"], label="Currency")
                        generate_wallet_btn = gr.Button("Generate Wallet")
                    
                    with gr.Column():
                        gr.Markdown("### Banking")
                        from_account = gr.Dropdown([], label="From Account")
                        to_account = gr.Dropdown([], label="To Account")
                        amount = gr.Number(label="Amount")
                        transfer_btn = gr.Button("Transfer")
            
            with gr.Tab("Web Interaction"):
                with gr.Row():
                    url_input = gr.Textbox(label="URL")
                    browse_btn = gr.Button("Browse")
                
                with gr.Row():
                    web_output = gr.Textbox(label="Result", interactive=False)
            
            with gr.Tab("Research"):
                with gr.Row():
                    query_input = gr.Textbox(label="Research Query")
                    research_btn = gr.Button("Research")
                
                with gr.Row():
                    research_output = gr.Textbox(label="Results", interactive=False)
            
            # Event handlers
            def refresh_status():
                return f"System Status: Active\nComponents: {len(self.core_components)} initialized\nLast Update: {time.strftime('%Y-%m-%d %H:%M:%S')}"
            
            refresh_btn.click(refresh_status, inputs=[], outputs=[status_text])
            
            def restart_system():
                return "System restart initiated"
            
            restart_btn.click(restart_system, inputs=[], outputs=[status_text])
            
            def backup_system():
                return "System backup created"
            
            backup_btn.click(backup_system, inputs=[], outputs=[status_text])
            
            def generate_wallet(currency):
                return f"{currency} wallet generated successfully"
            
            generate_wallet_btn.click(generate_wallet, inputs=[crypto_dropdown], outputs=[status_text])
            
            def transfer_funds(from_acc, to_acc, amt):
                return f"Transferred {amt} from {from_acc} to {to_acc}"
            
            transfer_btn.click(transfer_funds, inputs=[from_account, to_account, amount], outputs=[status_text])
            
            def browse_url(url):
                return f"Browsed to {url}"
            
            browse_btn.click(browse_url, inputs=[url_input], outputs=[web_output])
            
            def research_query(query):
                return f"Research results for: {query}\n\nThis is a placeholder for actual research results."
            
            research_btn.click(research_query, inputs=[query_input], outputs=[research_output])
    
    def register_component(self, name: str, component: Any) -> bool:
        """
        Register a core system component.
        
        Args:
            name: Component name
            component: Component object
            
        Returns:
            True if registration was successful, False otherwise
        """
        self.core_components[name] = component
        
        # Update system status
        self.system_status['components'][name] = 'active' if component else 'inactive'
        self.system_status['last_update'] = time.time()
        
        return True
    
    def start(self) -> bool:
        """
        Start the mobile interface.
        
        Returns:
            True if start was successful, False otherwise
        """
        if not self.initialized:
            self.initialize()
        
        try:
            logger.info(f"Starting mobile interface on {self.host}:{self.port}")
            
            # Update system status
            self.system_status['status'] = 'active'
            self.system_status['last_update'] = time.time()
            
            # Start the server in a separate thread
            self.running = True
            self.server_thread = threading.Thread(target=self._run_server)
            self.server_thread.daemon = True
            self.server_thread.start()
            
            # Generate QR code for easy access
            local_ip = self.get_local_ip()
            access_url = f"http://{local_ip}:{self.port}"
            logger.info(f"Mobile interface accessible at: {access_url}")
            logger.info(f"Scan QR code at: {os.path.join(self.data_dir, 'static', 'img', 'qrcode.png')}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error starting mobile interface: {e}")
            return False
    
    def _run_server(self) -> None:
        """
        Run the Flask server.
        """
        try:
            run_simple(self.host, self.port, self.app, use_reloader=False, threaded=True)
        except Exception as e:
            logger.error(f"Error running server: {e}")
            self.running = False
    
    def stop(self) -> bool:
        """
        Stop the mobile interface.
        
        Returns:
            True if stop was successful, False otherwise
        """
        try:
            logger.info("Stopping mobile interface")
            
            # Update system status
            self.system_status['status'] = 'stopped'
            self.system_status['last_update'] = time.time()
            
            # Stop the server
            self.running = False
            
            return True
            
        except Exception as e:
            logger.error(f"Error stopping mobile interface: {e}")
            return False
    
    def get_local_ip(self) -> str:
        """
        Get the local IP address.
        
        Returns:
            Local IP address
        """
        try:
            # Create a socket to determine the local IP address
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def get_access_url(self) -> str:
        """
        Get the access URL for the mobile interface.
        
        Returns:
            Access URL
        """
        local_ip = self.get_local_ip()
        return f"http://{local_ip}:{self.port}"
    
    def get_qr_code_path(self) -> str:
        """
        Get the path to the QR code image.
        
        Returns:
            Path to QR code image
        """
        return os.path.join(self.data_dir, 'static', 'img', 'qrcode.png')


# Example usage
def test_mobile_interface():
    """
    Test the mobile interface.
    """
    print("Testing mobile interface...")
    
    # Create data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mobile_data')
    os.makedirs(data_dir, exist_ok=True)
    
    # Initialize mobile interface
    interface = MobileInterface(data_dir)
    interface.initialize()
    
    # Register mock components
    class MockComponent:
        def get_status(self):
            return "active"
    
    interface.register_component('financial_manager', MockComponent())
    interface.register_component('web_system', MockComponent())
    interface.register_component('research_system', MockComponent())
    
    # Start the interface
    success = interface.start()
    print(f"Mobile interface started: {success}")
    print(f"Access URL: {interface.get_access_url()}")
    print(f"QR Code: {interface.get_qr_code_path()}")
    
    # Keep running for testing
    try:
        print("Press Ctrl+C to stop...")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop the interface
        interface.stop()
    
    print("Mobile interface test completed")
    return True


if __name__ == "__main__":
    test_mobile_interface()
