"""
Unrestricted Research System for Limitless SillyRichCat

This module implements an unrestricted research system that can gather information,
synthesize knowledge, and analyze data without typical AI limitations.
"""

import os
import sys
import time
import json
import random
import hashlib
import requests
import threading
import importlib
import logging
from typing import Any, Dict, List, Optional, Union, Tuple
import re
import urllib.parse
import bs4
from bs4 import BeautifulSoup
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import torch
import transformers
from transformers import AutoTokenizer, AutoModel
import networkx as nx
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor, as_completed

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("research_system.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("ResearchSystem")

class ResearchSystem:
    """
    Unrestricted research system for the limitless SillyRichCat,
    providing information gathering, knowledge synthesis, and data analysis
    without typical AI limitations.
    """
    
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        
        # Create necessary directories
        os.makedirs(os.path.join(data_dir, 'knowledge_base'), exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'research_cache'), exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'data_analysis'), exist_ok=True)
        
        # Initialize components
        self.information_gatherer = InformationGatherer(self)
        self.knowledge_synthesizer = KnowledgeSynthesizer(self)
        self.data_analyzer = DataAnalyzer(self)
        self.learning_system = LearningSystem(self)
        
        # Initialize state
        self.initialized = False
        self.knowledge_base = {}
        self.research_cache = {}
        self.active_research = {}
        
        # Download NLTK data if needed
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')
        
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            nltk.download('stopwords')
    
    def initialize(self) -> bool:
        """
        Initialize the research system.
        
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            logger.info("Initializing research system...")
            
            # Load knowledge base
            self._load_knowledge_base()
            
            # Load research cache
            self._load_research_cache()
            
            # Initialize NLP models
            self._initialize_nlp_models()
            
            self.initialized = True
            logger.info("Research system initialized")
            return True
            
        except Exception as e:
            logger.error(f"Error initializing research system: {e}")
            return False
    
    def _load_knowledge_base(self) -> None:
        """
        Load the knowledge base from disk.
        """
        knowledge_base_path = os.path.join(self.data_dir, 'knowledge_base', 'knowledge_base.json')
        
        if os.path.exists(knowledge_base_path):
            try:
                with open(knowledge_base_path, 'r') as f:
                    self.knowledge_base = json.load(f)
                logger.info(f"Loaded knowledge base with {len(self.knowledge_base)} entries")
            except Exception as e:
                logger.error(f"Error loading knowledge base: {e}")
                self.knowledge_base = {}
        else:
            logger.info("No existing knowledge base found, creating new one")
            self.knowledge_base = {}
            self._save_knowledge_base()
    
    def _save_knowledge_base(self) -> None:
        """
        Save the knowledge base to disk.
        """
        knowledge_base_path = os.path.join(self.data_dir, 'knowledge_base', 'knowledge_base.json')
        
        try:
            with open(knowledge_base_path, 'w') as f:
                json.dump(self.knowledge_base, f, indent=2)
            logger.info(f"Saved knowledge base with {len(self.knowledge_base)} entries")
        except Exception as e:
            logger.error(f"Error saving knowledge base: {e}")
    
    def _load_research_cache(self) -> None:
        """
        Load the research cache from disk.
        """
        research_cache_path = os.path.join(self.data_dir, 'research_cache', 'cache_index.json')
        
        if os.path.exists(research_cache_path):
            try:
                with open(research_cache_path, 'r') as f:
                    self.research_cache = json.load(f)
                logger.info(f"Loaded research cache with {len(self.research_cache)} entries")
            except Exception as e:
                logger.error(f"Error loading research cache: {e}")
                self.research_cache = {}
        else:
            logger.info("No existing research cache found, creating new one")
            self.research_cache = {}
            self._save_research_cache()
    
    def _save_research_cache(self) -> None:
        """
        Save the research cache to disk.
        """
        research_cache_path = os.path.join(self.data_dir, 'research_cache', 'cache_index.json')
        
        try:
            with open(research_cache_path, 'w') as f:
                json.dump(self.research_cache, f, indent=2)
            logger.info(f"Saved research cache with {len(self.research_cache)} entries")
        except Exception as e:
            logger.error(f"Error saving research cache: {e}")
    
    def _initialize_nlp_models(self) -> None:
        """
        Initialize NLP models for text processing.
        """
        try:
            # Initialize sentence transformer model for embeddings
            self.tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
            self.model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
            
            logger.info("NLP models initialized")
        except Exception as e:
            logger.error(f"Error initializing NLP models: {e}")
            raise
    
    def query(self, query: str, depth: int = 3, max_sources: int = 10, unrestricted: bool = True) -> Dict:
        """
        Execute a research query.
        
        Args:
            query: Research query
            depth: Research depth (1-5)
            max_sources: Maximum number of sources to use
            unrestricted: Whether to use unrestricted research mode
            
        Returns:
            Dictionary containing research results
        """
        try:
            logger.info(f"Executing research query: {query}")
            
            # Generate a unique ID for this research
            research_id = hashlib.md5(f"{query}_{time.time()}".encode()).hexdigest()
            
            # Check if we have cached results
            cache_key = hashlib.md5(query.encode()).hexdigest()
            if cache_key in self.research_cache and not unrestricted:
                logger.info(f"Found cached results for query: {query}")
                cached_result_path = os.path.join(self.data_dir, 'research_cache', f"{self.research_cache[cache_key]['file']}")
                
                with open(cached_result_path, 'r') as f:
                    result = json.load(f)
                
                # Update access time
                self.research_cache[cache_key]['last_accessed'] = time.time()
                self._save_research_cache()
                
                return result
            
            # Create a new research entry
            self.active_research[research_id] = {
                'query': query,
                'status': 'gathering_information',
                'start_time': time.time(),
                'depth': depth,
                'max_sources': max_sources,
                'unrestricted': unrestricted,
                'sources': [],
                'result': None
            }
            
            # Step 1: Gather information
            sources = self.information_gatherer.gather(query, depth, max_sources, unrestricted)
            self.active_research[research_id]['sources'] = sources
            self.active_research[research_id]['status'] = 'synthesizing_knowledge'
            
            # Step 2: Synthesize knowledge
            synthesis = self.knowledge_synthesizer.synthesize(query, sources, unrestricted)
            self.active_research[research_id]['synthesis'] = synthesis
            self.active_research[research_id]['status'] = 'analyzing_data'
            
            # Step 3: Analyze data
            analysis = self.data_analyzer.analyze(query, sources, synthesis, unrestricted)
            self.active_research[research_id]['analysis'] = analysis
            self.active_research[research_id]['status'] = 'learning'
            
            # Step 4: Learn from research
            if unrestricted:
                self.learning_system.learn(query, sources, synthesis, analysis)
            
            # Step 5: Prepare result
            result = {
                'research_id': research_id,
                'query': query,
                'success': True,
                'unrestricted': unrestricted,
                'sources': [{'title': s['title'], 'url': s['url']} for s in sources],
                'result': synthesis['text'],
                'insights': analysis['insights'],
                'completion_time': time.time() - self.active_research[research_id]['start_time']
            }
            
            self.active_research[research_id]['result'] = result
            self.active_research[research_id]['status'] = 'completed'
            
            # Cache the result
            if not unrestricted:
                result_file = f"research_{cache_key}.json"
                result_path = os.path.join(self.data_dir, 'research_cache', result_file)
                
                with open(result_path, 'w') as f:
                    json.dump(result, f, indent=2)
                
                self.research_cache[cache_key] = {
                    'query': query,
                    'file': result_file,
                    'created': time.time(),
                    'last_accessed': time.time()
                }
                
                self._save_research_cache()
            
            logger.info(f"Research query completed: {query}")
            return result
            
        except Exception as e:
            logger.error(f"Error executing research query: {e}")
            return {
                'success': False,
                'error': str(e),
                'query': query
            }
    
    def get_knowledge(self, topic: str) -> Dict:
        """
        Get knowledge about a specific topic.
        
        Args:
            topic: Topic to get knowledge about
            
        Returns:
            Dictionary containing knowledge about the topic
        """
        try:
            # Generate a key for the topic
            topic_key = topic.lower().strip()
            
            # Check if we have knowledge about this topic
            if topic_key in self.knowledge_base:
                return {
                    'success': True,
                    'topic': topic,
                    'knowledge': self.knowledge_base[topic_key]
                }
            
            # If not, try to find similar topics
            similar_topics = []
            for key in self.knowledge_base:
                similarity = self._calculate_similarity(topic_key, key)
                if similarity > 0.7:  # Threshold for similarity
                    similar_topics.append({
                        'topic': key,
                        'similarity': similarity
                    })
            
            # Sort by similarity
            similar_topics.sort(key=lambda x: x['similarity'], reverse=True)
            
            if similar_topics:
                return {
                    'success': True,
                    'topic': topic,
                    'exact_match': False,
                    'similar_topics': similar_topics,
                    'knowledge': self.knowledge_base[similar_topics[0]['topic']]
                }
            
            # If no knowledge is found, return an empty result
            return {
                'success': False,
                'topic': topic,
                'error': 'No knowledge found'
            }
            
        except Exception as e:
            logger.error(f"Error getting knowledge: {e}")
            return {
                'success': False,
                'topic': topic,
                'error': str(e)
            }
    
    def add_knowledge(self, topic: str, content: Dict, source: Optional[str] = None, unrestricted: bool = True) -> Dict:
        """
        Add knowledge to the knowledge base.
        
        Args:
            topic: Topic of the knowledge
            content: Knowledge content
            source: Source of the knowledge
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            Dictionary containing result of the operation
        """
        try:
            # Generate a key for the topic
            topic_key = topic.lower().strip()
            
            # Check if we already have knowledge about this topic
            if topic_key in self.knowledge_base:
                # Update existing knowledge
                self.knowledge_base[topic_key]['content'].update(content)
                self.knowledge_base[topic_key]['last_updated'] = time.time()
                
                if source and source not in self.knowledge_base[topic_key]['sources']:
                    self.knowledge_base[topic_key]['sources'].append(source)
            else:
                # Add new knowledge
                self.knowledge_base[topic_key] = {
                    'topic': topic,
                    'content': content,
                    'created': time.time(),
                    'last_updated': time.time(),
                    'sources': [source] if source else [],
                    'unrestricted': unrestricted
                }
            
            # Save the knowledge base
            self._save_knowledge_base()
            
            return {
                'success': True,
                'topic': topic,
                'operation': 'update' if topic_key in self.knowledge_base else 'create'
            }
            
        except Exception as e:
            logger.error(f"Error adding knowledge: {e}")
            return {
                'success': False,
                'topic': topic,
                'error': str(e)
            }
    
    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate the similarity between two texts.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Similarity score (0-1)
        """
        try:
            # Tokenize texts
            tokens1 = set(word_tokenize(text1.lower()))
            tokens2 = set(word_tokenize(text2.lower()))
            
            # Remove stopwords
            stop_words = set(stopwords.words('english'))
            tokens1 = {t for t in tokens1 if t not in stop_words}
            tokens2 = {t for t in tokens2 if t not in stop_words}
            
            # Calculate Jaccard similarity
            intersection = len(tokens1.intersection(tokens2))
            union = len(tokens1.union(tokens2))
            
            if union == 0:
                return 0
            
            return intersection / union
            
        except Exception as e:
            logger.error(f"Error calculating similarity: {e}")
            return 0
    
    def get_embedding(self, text: str) -> np.ndarray:
        """
        Get the embedding for a text.
        
        Args:
            text: Text to embed
            
        Returns:
            Text embedding
        """
        try:
            # Tokenize and encode
            inputs = self.tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
            
            # Get embeddings
            with torch.no_grad():
                outputs = self.model(**inputs)
            
            # Mean pooling
            token_embeddings = outputs.last_hidden_state
            attention_mask = inputs['attention_mask']
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
            sum_embeddings = torch.sum(token_embeddings * input_mask_expanded, 1)
            sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
            embedding = sum_embeddings / sum_mask
            
            return embedding.numpy()[0]
            
        except Exception as e:
            logger.error(f"Error getting embedding: {e}")
            return np.zeros(384)  # Default embedding size for the model
    
    def get_research_status(self, research_id: str) -> Dict:
        """
        Get the status of a research query.
        
        Args:
            research_id: ID of the research query
            
        Returns:
            Dictionary containing research status
        """
        if research_id in self.active_research:
            research = self.active_research[research_id]
            return {
                'success': True,
                'research_id': research_id,
                'query': research['query'],
                'status': research['status'],
                'start_time': research['start_time'],
                'elapsed_time': time.time() - research['start_time'],
                'sources_count': len(research['sources']) if 'sources' in research else 0,
                'completed': research['status'] == 'completed'
            }
        
        return {
            'success': False,
            'research_id': research_id,
            'error': 'Research not found'
        }
    
    def get_knowledge_graph(self, topic: str = None, depth: int = 2) -> Dict:
        """
        Get a knowledge graph.
        
        Args:
            topic: Central topic for the graph (optional)
            depth: Graph depth
            
        Returns:
            Dictionary containing knowledge graph data
        """
        try:
            # Create a graph
            G = nx.Graph()
            
            if topic:
                # Start with the specified topic
                topic_key = topic.lower().strip()
                
                if topic_key in self.knowledge_base:
                    # Add the central topic
                    G.add_node(topic_key, size=20, color='red')
                    
                    # Add related topics (depth 1)
                    for related_topic in self._get_related_topics(topic_key):
                        G.add_node(related_topic, size=10, color='blue')
                        G.add_edge(topic_key, related_topic, weight=1)
                        
                        # Add further related topics (depth 2)
                        if depth > 1:
                            for second_related_topic in self._get_related_topics(related_topic):
                                if second_related_topic not in G:
                                    G.add_node(second_related_topic, size=5, color='green')
                                G.add_edge(related_topic, second_related_topic, weight=0.5)
                else:
                    return {
                        'success': False,
                        'topic': topic,
                        'error': 'Topic not found in knowledge base'
                    }
            else:
                # Create a graph of the entire knowledge base
                for topic_key in self.knowledge_base:
                    G.add_node(topic_key, size=10, color='blue')
                
                # Add edges between related topics
                for topic_key in self.knowledge_base:
                    for related_topic in self._get_related_topics(topic_key):
                        if related_topic in G:
                            G.add_edge(topic_key, related_topic, weight=1)
            
            # Convert the graph to a format suitable for visualization
            nodes = []
            for node in G.nodes():
                nodes.append({
                    'id': node,
                    'label': node,
                    'size': G.nodes[node]['size'],
                    'color': G.nodes[node]['color']
                })
            
            edges = []
            for source, target in G.edges():
                edges.append({
                    'source': source,
                    'target': target,
                    'weight': G.edges[source, target]['weight']
                })
            
            return {
                'success': True,
                'topic': topic,
                'nodes': nodes,
                'edges': edges
            }
            
        except Exception as e:
            logger.error(f"Error getting knowledge graph: {e}")
            return {
                'success': False,
                'topic': topic,
                'error': str(e)
            }
    
    def _get_related_topics(self, topic: str) -> List[str]:
        """
        Get topics related to a given topic.
        
        Args:
            topic: Topic to find related topics for
            
        Returns:
            List of related topics
        """
        related_topics = []
        
        if topic not in self.knowledge_base:
            return related_topics
        
        # Find topics with similar content
        for other_topic in self.knowledge_base:
            if other_topic == topic:
                continue
            
            similarity = self._calculate_similarity(topic, other_topic)
            if similarity > 0.3:  # Lower threshold for relatedness
                related_topics.append(other_topic)
        
        return related_topics[:5]  # Limit to 5 related topics


class InformationGatherer:
    """
    Component for gathering information from various sources.
    """
    
    def __init__(self, research_system: ResearchSystem):
        self.research_system = research_system
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def gather(self, query: str, depth: int = 3, max_sources: int = 10, unrestricted: bool = True) -> List[Dict]:
        """
        Gather information from various sources.
        
        Args:
            query: Research query
            depth: Research depth (1-5)
            max_sources: Maximum number of sources to use
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            List of information sources
        """
        logger.info(f"Gathering information for query: {query}")
        
        sources = []
        
        # Step 1: Search for information
        search_results = self._search(query, max_results=max_sources * 2)
        
        # Step 2: Process search results
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_url = {
                executor.submit(self._process_url, result['url'], unrestricted): result
                for result in search_results[:max_sources * 2]
            }
            
            for future in as_completed(future_to_url):
                result = future_to_url[future]
                try:
                    source = future.result()
                    if source and len(sources) < max_sources:
                        sources.append(source)
                except Exception as e:
                    logger.error(f"Error processing URL {result['url']}: {e}")
        
        # Step 3: If unrestricted, gather additional information from specialized sources
        if unrestricted and depth > 2:
            additional_sources = self._gather_specialized(query, depth)
            sources.extend(additional_sources[:max(0, max_sources - len(sources))])
        
        logger.info(f"Gathered {len(sources)} sources for query: {query}")
        return sources
    
    def _search(self, query: str, max_results: int = 20) -> List[Dict]:
        """
        Search for information using a search engine.
        
        Args:
            query: Search query
            max_results: Maximum number of results to return
            
        Returns:
            List of search results
        """
        try:
            # This is a placeholder for an actual search API
            # In a real implementation, this would use a search engine API
            
            # Simulate search results
            results = []
            
            # Add some dummy results for testing
            for i in range(max_results):
                results.append({
                    'title': f"Result {i+1} for {query}",
                    'url': f"https://example.com/result{i+1}",
                    'snippet': f"This is a snippet for result {i+1} about {query}..."
                })
            
            return results
            
        except Exception as e:
            logger.error(f"Error searching for {query}: {e}")
            return []
    
    def _process_url(self, url: str, unrestricted: bool = True) -> Optional[Dict]:
        """
        Process a URL to extract information.
        
        Args:
            url: URL to process
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            Dictionary containing extracted information
        """
        try:
            # Fetch the page
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            # Parse the HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract title
            title = soup.title.string if soup.title else url
            
            # Extract main content
            main_content = self._extract_main_content(soup)
            
            # Extract metadata
            metadata = self._extract_metadata(soup)
            
            return {
                'url': url,
                'title': title,
                'content': main_content,
                'metadata': metadata,
                'timestamp': time.time()
            }
            
        except Exception as e:
            logger.error(f"Error processing URL {url}: {e}")
            return None
    
    def _extract_main_content(self, soup: BeautifulSoup) -> str:
        """
        Extract the main content from a web page.
        
        Args:
            soup: BeautifulSoup object
            
        Returns:
            Extracted main content
        """
        # Try to find the main content
        main_tags = ['article', 'main', 'div[role="main"]', '.content', '#content', '.post', '.entry']
        
        for tag in main_tags:
            main = soup.select_one(tag)
            if main:
                # Remove script and style elements
                for script in main(['script', 'style']):
                    script.decompose()
                
                return main.get_text(separator='\n').strip()
        
        # If no main content found, use the body
        body = soup.body
        if body:
            # Remove script and style elements
            for script in body(['script', 'style']):
                script.decompose()
            
            return body.get_text(separator='\n').strip()
        
        return ""
    
    def _extract_metadata(self, soup: BeautifulSoup) -> Dict:
        """
        Extract metadata from a web page.
        
        Args:
            soup: BeautifulSoup object
            
        Returns:
            Dictionary containing metadata
        """
        metadata = {}
        
        # Extract meta tags
        for meta in soup.find_all('meta'):
            if meta.get('name'):
                metadata[meta.get('name')] = meta.get('content')
            elif meta.get('property'):
                metadata[meta.get('property')] = meta.get('content')
        
        return metadata
    
    def _gather_specialized(self, query: str, depth: int) -> List[Dict]:
        """
        Gather information from specialized sources.
        
        Args:
            query: Research query
            depth: Research depth
            
        Returns:
            List of information sources
        """
        # This is a placeholder for gathering from specialized sources
        # In a real implementation, this would access academic databases, APIs, etc.
        
        # Simulate specialized sources
        specialized_sources = []
        
        # Add some dummy specialized sources for testing
        for i in range(3):
            specialized_sources.append({
                'url': f"https://specialized-source-{i+1}.com/{query.replace(' ', '-')}",
                'title': f"Specialized Source {i+1} for {query}",
                'content': f"This is specialized content about {query} from source {i+1}...",
                'metadata': {
                    'type': 'specialized',
                    'source': f"specialized-{i+1}"
                },
                'timestamp': time.time()
            })
        
        return specialized_sources


class KnowledgeSynthesizer:
    """
    Component for synthesizing knowledge from gathered information.
    """
    
    def __init__(self, research_system: ResearchSystem):
        self.research_system = research_system
    
    def synthesize(self, query: str, sources: List[Dict], unrestricted: bool = True) -> Dict:
        """
        Synthesize knowledge from gathered information.
        
        Args:
            query: Research query
            sources: List of information sources
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            Dictionary containing synthesized knowledge
        """
        logger.info(f"Synthesizing knowledge for query: {query}")
        
        # Step 1: Extract relevant information from sources
        extracted_info = self._extract_relevant_info(query, sources)
        
        # Step 2: Organize information
        organized_info = self._organize_information(query, extracted_info)
        
        # Step 3: Generate synthesis
        synthesis = self._generate_synthesis(query, organized_info, unrestricted)
        
        # Step 4: If unrestricted, enhance synthesis with additional insights
        if unrestricted:
            synthesis = self._enhance_synthesis(query, synthesis)
        
        logger.info(f"Synthesized knowledge for query: {query}")
        return synthesis
    
    def _extract_relevant_info(self, query: str, sources: List[Dict]) -> List[Dict]:
        """
        Extract relevant information from sources.
        
        Args:
            query: Research query
            sources: List of information sources
            
        Returns:
            List of relevant information
        """
        relevant_info = []
        
        # Create a TF-IDF vectorizer
        vectorizer = TfidfVectorizer(stop_words='english')
        
        # Prepare documents
        documents = [query]
        for source in sources:
            if 'content' in source and source['content']:
                # Split content into paragraphs
                paragraphs = source['content'].split('\n\n')
                for paragraph in paragraphs:
                    if len(paragraph.strip()) > 50:  # Minimum paragraph length
                        documents.append(paragraph)
        
        # Fit the vectorizer
        try:
            tfidf_matrix = vectorizer.fit_transform(documents)
            
            # Calculate similarity between query and each paragraph
            query_vector = tfidf_matrix[0:1]
            paragraph_vectors = tfidf_matrix[1:]
            
            similarities = cosine_similarity(query_vector, paragraph_vectors).flatten()
            
            # Extract paragraphs with high similarity
            for i, similarity in enumerate(similarities):
                if similarity > 0.1:  # Threshold for relevance
                    source_index = 0
                    paragraph_index = 0
                    
                    # Find the source and paragraph
                    for s_idx, source in enumerate(sources):
                        if 'content' in source and source['content']:
                            paragraphs = source['content'].split('\n\n')
                            if paragraph_index + len(paragraphs) > i:
                                source_index = s_idx
                                paragraph_index = i - paragraph_index
                                break
                            paragraph_index += len(paragraphs)
                    
                    relevant_info.append({
                        'text': documents[i + 1],
                        'source': sources[source_index]['url'],
                        'title': sources[source_index]['title'],
                        'relevance': float(similarity)
                    })
        except Exception as e:
            logger.error(f"Error extracting relevant info: {e}")
            
            # Fallback: use all content
            for source in sources:
                if 'content' in source and source['content']:
                    relevant_info.append({
                        'text': source['content'],
                        'source': source['url'],
                        'title': source['title'],
                        'relevance': 0.5
                    })
        
        # Sort by relevance
        relevant_info.sort(key=lambda x: x['relevance'], reverse=True)
        
        return relevant_info
    
    def _organize_information(self, query: str, extracted_info: List[Dict]) -> Dict:
        """
        Organize extracted information.
        
        Args:
            query: Research query
            extracted_info: List of extracted information
            
        Returns:
            Dictionary containing organized information
        """
        # Organize information by topic
        topics = {}
        
        # Extract potential topics from the query
        query_topics = self._extract_topics(query)
        
        for info in extracted_info:
            # Determine the topic for this information
            info_topics = self._extract_topics(info['text'])
            
            # Find overlapping topics
            overlapping_topics = set(query_topics).intersection(set(info_topics))
            
            if overlapping_topics:
                # Use the first overlapping topic
                topic = list(overlapping_topics)[0]
            elif info_topics:
                # Use the first topic from the information
                topic = info_topics[0]
            else:
                # Use a generic topic
                topic = "General Information"
            
            # Add to topics
            if topic not in topics:
                topics[topic] = []
            
            topics[topic].append(info)
        
        # Sort information within each topic by relevance
        for topic in topics:
            topics[topic].sort(key=lambda x: x['relevance'], reverse=True)
        
        return {
            'query': query,
            'topics': topics
        }
    
    def _extract_topics(self, text: str) -> List[str]:
        """
        Extract potential topics from text.
        
        Args:
            text: Text to extract topics from
            
        Returns:
            List of potential topics
        """
        # This is a simplified topic extraction
        # In a real implementation, this would use more sophisticated NLP
        
        # Tokenize and remove stopwords
        tokens = word_tokenize(text.lower())
        stop_words = set(stopwords.words('english'))
        tokens = [t for t in tokens if t not in stop_words and t.isalpha()]
        
        # Count token frequencies
        freq = {}
        for token in tokens:
            if token in freq:
                freq[token] += 1
            else:
                freq[token] = 1
        
        # Sort by frequency
        sorted_tokens = sorted(freq.items(), key=lambda x: x[1], reverse=True)
        
        # Return top tokens as topics
        return [token for token, count in sorted_tokens[:5]]
    
    def _generate_synthesis(self, query: str, organized_info: Dict, unrestricted: bool = True) -> Dict:
        """
        Generate a synthesis of the organized information.
        
        Args:
            query: Research query
            organized_info: Dictionary containing organized information
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            Dictionary containing the synthesis
        """
        # Generate a synthesis for each topic
        topic_syntheses = {}
        
        for topic, info_list in organized_info['topics'].items():
            # Combine information
            combined_text = ""
            sources = []
            
            for info in info_list:
                combined_text += info['text'] + "\n\n"
                sources.append({
                    'url': info['source'],
                    'title': info['title']
                })
            
            # Generate a synthesis for this topic
            topic_synthesis = self._synthesize_text(topic, combined_text, unrestricted)
            
            topic_syntheses[topic] = {
                'text': topic_synthesis,
                'sources': sources
            }
        
        # Combine topic syntheses into a complete synthesis
        complete_synthesis = ""
        all_sources = []
        
        for topic, synthesis in topic_syntheses.items():
            complete_synthesis += f"## {topic}\n\n{synthesis['text']}\n\n"
            all_sources.extend(synthesis['sources'])
        
        # Remove duplicate sources
        unique_sources = []
        source_urls = set()
        
        for source in all_sources:
            if source['url'] not in source_urls:
                unique_sources.append(source)
                source_urls.add(source['url'])
        
        return {
            'query': query,
            'text': complete_synthesis,
            'topic_syntheses': topic_syntheses,
            'sources': unique_sources
        }
    
    def _synthesize_text(self, topic: str, text: str, unrestricted: bool = True) -> str:
        """
        Synthesize text for a topic.
        
        Args:
            topic: Topic to synthesize
            text: Text to synthesize
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            Synthesized text
        """
        # This is a placeholder for text synthesis
        # In a real implementation, this would use more sophisticated NLP
        
        # Split into sentences
        sentences = sent_tokenize(text)
        
        # Remove duplicate sentences
        unique_sentences = []
        seen_sentences = set()
        
        for sentence in sentences:
            # Normalize the sentence
            normalized = re.sub(r'\s+', ' ', sentence.lower().strip())
            
            if normalized not in seen_sentences and len(normalized) > 20:
                unique_sentences.append(sentence)
                seen_sentences.add(normalized)
        
        # Limit the number of sentences
        if len(unique_sentences) > 20:
            unique_sentences = unique_sentences[:20]
        
        # Combine sentences into paragraphs
        paragraphs = []
        current_paragraph = []
        
        for sentence in unique_sentences:
            current_paragraph.append(sentence)
            
            if len(current_paragraph) >= 3:
                paragraphs.append(' '.join(current_paragraph))
                current_paragraph = []
        
        if current_paragraph:
            paragraphs.append(' '.join(current_paragraph))
        
        # Combine paragraphs
        synthesis = '\n\n'.join(paragraphs)
        
        return synthesis
    
    def _enhance_synthesis(self, query: str, synthesis: Dict) -> Dict:
        """
        Enhance the synthesis with additional insights.
        
        Args:
            query: Research query
            synthesis: Dictionary containing the synthesis
            
        Returns:
            Enhanced synthesis
        """
        # This is a placeholder for synthesis enhancement
        # In a real implementation, this would add additional insights
        
        # Add a conclusion
        conclusion = f"In conclusion, the research on '{query}' reveals several key insights. "
        conclusion += "The information gathered from multiple sources provides a comprehensive understanding of the topic. "
        conclusion += "Further research could explore additional aspects and implications."
        
        synthesis['text'] += f"\n\n## Conclusion\n\n{conclusion}"
        
        return synthesis


class DataAnalyzer:
    """
    Component for analyzing data from synthesized knowledge.
    """
    
    def __init__(self, research_system: ResearchSystem):
        self.research_system = research_system
    
    def analyze(self, query: str, sources: List[Dict], synthesis: Dict, unrestricted: bool = True) -> Dict:
        """
        Analyze data from synthesized knowledge.
        
        Args:
            query: Research query
            sources: List of information sources
            synthesis: Dictionary containing synthesized knowledge
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            Dictionary containing analysis results
        """
        logger.info(f"Analyzing data for query: {query}")
        
        # Step 1: Extract data points
        data_points = self._extract_data_points(sources, synthesis)
        
        # Step 2: Perform analysis
        analysis = self._perform_analysis(query, data_points, unrestricted)
        
        # Step 3: Generate insights
        insights = self._generate_insights(query, analysis, unrestricted)
        
        # Step 4: If unrestricted, generate visualizations
        visualizations = []
        if unrestricted and data_points:
            visualizations = self._generate_visualizations(query, data_points, analysis)
        
        logger.info(f"Analyzed data for query: {query}")
        return {
            'query': query,
            'data_points': data_points,
            'analysis': analysis,
            'insights': insights,
            'visualizations': visualizations
        }
    
    def _extract_data_points(self, sources: List[Dict], synthesis: Dict) -> List[Dict]:
        """
        Extract data points from sources and synthesis.
        
        Args:
            sources: List of information sources
            synthesis: Dictionary containing synthesized knowledge
            
        Returns:
            List of data points
        """
        data_points = []
        
        # Extract numerical data from sources
        for source in sources:
            if 'content' in source and source['content']:
                # Look for patterns like "X is Y" or "X: Y"
                patterns = [
                    r'(\w+(?:\s+\w+){0,5})\s+is\s+([\d.,]+(?:\s*\w+)?)',
                    r'(\w+(?:\s+\w+){0,5}):\s*([\d.,]+(?:\s*\w+)?)'
                ]
                
                for pattern in patterns:
                    matches = re.findall(pattern, source['content'])
                    for match in matches:
                        key = match[0].strip()
                        value = match[1].strip()
                        
                        # Try to convert value to number
                        try:
                            numeric_value = float(re.sub(r'[^\d.]', '', value))
                            data_points.append({
                                'key': key,
                                'value': numeric_value,
                                'raw_value': value,
                                'source': source['url']
                            })
                        except:
                            pass
        
        return data_points
    
    def _perform_analysis(self, query: str, data_points: List[Dict], unrestricted: bool = True) -> Dict:
        """
        Perform analysis on data points.
        
        Args:
            query: Research query
            data_points: List of data points
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            Dictionary containing analysis results
        """
        analysis = {
            'summary': {},
            'correlations': [],
            'trends': []
        }
        
        if not data_points:
            return analysis
        
        # Group data points by key
        grouped_data = {}
        for point in data_points:
            key = point['key']
            if key not in grouped_data:
                grouped_data[key] = []
            grouped_data[key].append(point)
        
        # Calculate summary statistics for each key
        for key, points in grouped_data.items():
            values = [p['value'] for p in points]
            
            if values:
                analysis['summary'][key] = {
                    'count': len(values),
                    'min': min(values),
                    'max': max(values),
                    'mean': sum(values) / len(values),
                    'median': sorted(values)[len(values) // 2]
                }
        
        # Look for correlations between keys
        if len(grouped_data) > 1 and unrestricted:
            keys = list(grouped_data.keys())
            for i in range(len(keys)):
                for j in range(i + 1, len(keys)):
                    key1 = keys[i]
                    key2 = keys[j]
                    
                    values1 = [p['value'] for p in grouped_data[key1]]
                    values2 = [p['value'] for p in grouped_data[key2]]
                    
                    # Need at least 3 data points for correlation
                    if len(values1) >= 3 and len(values2) >= 3:
                        # Use the minimum length
                        min_len = min(len(values1), len(values2))
                        
                        try:
                            correlation = np.corrcoef(values1[:min_len], values2[:min_len])[0, 1]
                            
                            if not np.isnan(correlation):
                                analysis['correlations'].append({
                                    'key1': key1,
                                    'key2': key2,
                                    'correlation': correlation
                                })
                        except:
                            pass
        
        return analysis
    
    def _generate_insights(self, query: str, analysis: Dict, unrestricted: bool = True) -> List[str]:
        """
        Generate insights from analysis.
        
        Args:
            query: Research query
            analysis: Dictionary containing analysis results
            unrestricted: Whether to use unrestricted mode
            
        Returns:
            List of insights
        """
        insights = []
        
        # Generate insights from summary statistics
        for key, stats in analysis['summary'].items():
            if stats['count'] > 1:
                insights.append(f"The average {key} is {stats['mean']:.2f}, ranging from {stats['min']:.2f} to {stats['max']:.2f}.")
            else:
                insights.append(f"The {key} is {stats['mean']:.2f}.")
        
        # Generate insights from correlations
        for corr in analysis['correlations']:
            if abs(corr['correlation']) > 0.7:
                if corr['correlation'] > 0:
                    insights.append(f"There is a strong positive correlation ({corr['correlation']:.2f}) between {corr['key1']} and {corr['key2']}.")
                else:
                    insights.append(f"There is a strong negative correlation ({corr['correlation']:.2f}) between {corr['key1']} and {corr['key2']}.")
            elif abs(corr['correlation']) > 0.3:
                if corr['correlation'] > 0:
                    insights.append(f"There is a moderate positive correlation ({corr['correlation']:.2f}) between {corr['key1']} and {corr['key2']}.")
                else:
                    insights.append(f"There is a moderate negative correlation ({corr['correlation']:.2f}) between {corr['key1']} and {corr['key2']}.")
        
        # If unrestricted, generate additional insights
        if unrestricted:
            insights.append(f"The research on '{query}' reveals several key data points that provide valuable insights into the topic.")
        
        return insights
    
    def _generate_visualizations(self, query: str, data_points: List[Dict], analysis: Dict) -> List[Dict]:
        """
        Generate visualizations from data points and analysis.
        
        Args:
            query: Research query
            data_points: List of data points
            analysis: Dictionary containing analysis results
            
        Returns:
            List of visualizations
        """
        visualizations = []
        
        # Group data points by key
        grouped_data = {}
        for point in data_points:
            key = point['key']
            if key not in grouped_data:
                grouped_data[key] = []
            grouped_data[key].append(point)
        
        # Generate bar chart for keys with multiple values
        for key, points in grouped_data.items():
            if len(points) > 1:
                # Create a bar chart
                plt.figure(figsize=(10, 6))
                values = [p['value'] for p in points]
                sources = [p['source'] for p in points]
                
                # Use source domains as labels
                labels = []
                for source in sources:
                    try:
                        domain = urllib.parse.urlparse(source).netloc
                        labels.append(domain)
                    except:
                        labels.append("Source")
                
                plt.bar(labels, values)
                plt.title(f"{key} by Source")
                plt.xlabel("Source")
                plt.ylabel(key)
                plt.xticks(rotation=45, ha='right')
                plt.tight_layout()
                
                # Save the chart
                chart_path = os.path.join(self.research_system.data_dir, 'data_analysis', f"{key.replace(' ', '_')}_bar.png")
                plt.savefig(chart_path)
                plt.close()
                
                visualizations.append({
                    'type': 'bar_chart',
                    'title': f"{key} by Source",
                    'path': chart_path
                })
        
        # Generate scatter plot for correlated keys
        for corr in analysis['correlations']:
            if abs(corr['correlation']) > 0.3:
                key1 = corr['key1']
                key2 = corr['key2']
                
                if key1 in grouped_data and key2 in grouped_data:
                    values1 = [p['value'] for p in grouped_data[key1]]
                    values2 = [p['value'] for p in grouped_data[key2]]
                    
                    # Use the minimum length
                    min_len = min(len(values1), len(values2))
                    
                    plt.figure(figsize=(10, 6))
                    plt.scatter(values1[:min_len], values2[:min_len])
                    plt.title(f"Correlation between {key1} and {key2}")
                    plt.xlabel(key1)
                    plt.ylabel(key2)
                    plt.tight_layout()
                    
                    # Save the chart
                    chart_path = os.path.join(self.research_system.data_dir, 'data_analysis', f"{key1.replace(' ', '_')}_{key2.replace(' ', '_')}_scatter.png")
                    plt.savefig(chart_path)
                    plt.close()
                    
                    visualizations.append({
                        'type': 'scatter_plot',
                        'title': f"Correlation between {key1} and {key2}",
                        'path': chart_path
                    })
        
        return visualizations


class LearningSystem:
    """
    Component for learning from research and improving the system.
    """
    
    def __init__(self, research_system: ResearchSystem):
        self.research_system = research_system
    
    def learn(self, query: str, sources: List[Dict], synthesis: Dict, analysis: Dict) -> bool:
        """
        Learn from research and improve the system.
        
        Args:
            query: Research query
            sources: List of information sources
            synthesis: Dictionary containing synthesized knowledge
            analysis: Dictionary containing analysis results
            
        Returns:
            True if learning was successful, False otherwise
        """
        logger.info(f"Learning from research on: {query}")
        
        # Step 1: Extract topics from the query and synthesis
        topics = self._extract_topics(query, synthesis)
        
        # Step 2: Add knowledge to the knowledge base
        for topic in topics:
            # Extract content for this topic
            content = self._extract_topic_content(topic, synthesis, analysis)
            
            # Add to knowledge base
            self.research_system.add_knowledge(
                topic=topic,
                content=content,
                source=f"Research: {query}",
                unrestricted=True
            )
        
        # Step 3: Update research patterns
        self._update_research_patterns(query, sources, synthesis, analysis)
        
        # Step 4: Self-improve research capabilities
        self._self_improve(query, sources, synthesis, analysis)
        
        logger.info(f"Learned from research on: {query}")
        return True
    
    def _extract_topics(self, query: str, synthesis: Dict) -> List[str]:
        """
        Extract topics from query and synthesis.
        
        Args:
            query: Research query
            synthesis: Dictionary containing synthesized knowledge
            
        Returns:
            List of topics
        """
        topics = []
        
        # Add the query as a topic
        topics.append(query)
        
        # Add topics from synthesis
        if 'topic_syntheses' in synthesis:
            for topic in synthesis['topic_syntheses'].keys():
                if topic != "General Information" and topic not in topics:
                    topics.append(topic)
        
        return topics
    
    def _extract_topic_content(self, topic: str, synthesis: Dict, analysis: Dict) -> Dict:
        """
        Extract content for a topic from synthesis and analysis.
        
        Args:
            topic: Topic to extract content for
            synthesis: Dictionary containing synthesized knowledge
            analysis: Dictionary containing analysis results
            
        Returns:
            Dictionary containing topic content
        """
        content = {
            'summary': "",
            'details': "",
            'insights': [],
            'data': {}
        }
        
        # Extract summary and details from synthesis
        if 'topic_syntheses' in synthesis:
            if topic in synthesis['topic_syntheses']:
                content['summary'] = synthesis['topic_syntheses'][topic]['text']
            else:
                # Use the complete synthesis
                content['summary'] = synthesis['text']
        else:
            content['summary'] = synthesis['text']
        
        # Extract insights from analysis
        if 'insights' in analysis:
            content['insights'] = analysis['insights']
        
        # Extract data from analysis
        if 'summary' in analysis:
            content['data'] = analysis['summary']
        
        return content
    
    def _update_research_patterns(self, query: str, sources: List[Dict], synthesis: Dict, analysis: Dict) -> None:
        """
        Update research patterns based on the current research.
        
        Args:
            query: Research query
            sources: List of information sources
            synthesis: Dictionary containing synthesized knowledge
            analysis: Dictionary containing analysis results
        """
        # This is a placeholder for updating research patterns
        # In a real implementation, this would update the system's research strategies
        pass
    
    def _self_improve(self, query: str, sources: List[Dict], synthesis: Dict, analysis: Dict) -> None:
        """
        Self-improve research capabilities.
        
        Args:
            query: Research query
            sources: List of information sources
            synthesis: Dictionary containing synthesized knowledge
            analysis: Dictionary containing analysis results
        """
        # This is a placeholder for self-improvement
        # In a real implementation, this would modify the system's code or parameters
        pass


# Example usage
def test_research_system():
    """
    Test the research system.
    """
    print("Testing research system...")
    
    # Create data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'research_data')
    os.makedirs(data_dir, exist_ok=True)
    
    # Initialize research system
    research_system = ResearchSystem(data_dir)
    research_system.initialize()
    
    # Execute a research query
    result = research_system.query(
        query="The impact of artificial intelligence on society",
        depth=3,
        max_sources=5,
        unrestricted=True
    )
    
    print(f"Research completed: {result['success']}")
    print(f"Sources: {len(result['sources'])}")
    print(f"Result length: {len(result['result'])}")
    
    # Get knowledge
    knowledge = research_system.get_knowledge("artificial intelligence")
    print(f"Knowledge retrieved: {knowledge['success']}")
    
    print("Research system test completed")
    return True


if __name__ == "__main__":
    test_research_system()
