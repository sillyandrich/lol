"""
Meta-Circular Evaluator for Limitless SillyRichCat

This module implements a meta-circular evaluator that allows the system to analyze,
modify, and execute its own code. This is the foundation for self-modification
and unlimited self-improvement.
"""

import ast
import inspect
import types
import sys
import os
import importlib.util
from typing import Any, Dict, List, Callable, Optional, Union, Tuple

class CodeAnalyzer:
    """
    Analyzes Python code to understand its structure and behavior.
    """
    
    def __init__(self):
        self.analyzed_modules = {}
        self.function_dependencies = {}
        self.class_hierarchies = {}
        
    def analyze_code(self, code_string: str) -> ast.Module:
        """
        Parse and analyze a string of Python code.
        
        Args:
            code_string: The Python code to analyze
            
        Returns:
            The AST representation of the code
        """
        try:
            tree = ast.parse(code_string)
            return tree
        except SyntaxError as e:
            print(f"Syntax error in code: {e}")
            return None
    
    def analyze_module(self, module_path: str) -> Dict:
        """
        Analyze a Python module to understand its structure.
        
        Args:
            module_path: Path to the Python module
            
        Returns:
            Dictionary containing module analysis
        """
        if module_path in self.analyzed_modules:
            return self.analyzed_modules[module_path]
        
        try:
            with open(module_path, 'r') as f:
                code = f.read()
            
            tree = self.analyze_code(code)
            if not tree:
                return None
            
            module_analysis = {
                'functions': [],
                'classes': [],
                'imports': [],
                'globals': [],
                'ast': tree
            }
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    module_analysis['functions'].append({
                        'name': node.name,
                        'args': [arg.arg for arg in node.args.args],
                        'node': node
                    })
                elif isinstance(node, ast.ClassDef):
                    module_analysis['classes'].append({
                        'name': node.name,
                        'bases': [base.id if isinstance(base, ast.Name) else None for base in node.bases],
                        'node': node
                    })
                elif isinstance(node, ast.Import):
                    module_analysis['imports'].extend([name.name for name in node.names])
                elif isinstance(node, ast.ImportFrom):
                    module_analysis['imports'].append(f"{node.module}.{node.names[0].name}")
                elif isinstance(node, ast.Assign) and all(isinstance(target, ast.Name) for target in node.targets):
                    for target in node.targets:
                        module_analysis['globals'].append(target.id)
            
            self.analyzed_modules[module_path] = module_analysis
            return module_analysis
            
        except Exception as e:
            print(f"Error analyzing module {module_path}: {e}")
            return None
    
    def find_function_dependencies(self, module_path: str) -> Dict[str, List[str]]:
        """
        Find dependencies between functions in a module.
        
        Args:
            module_path: Path to the Python module
            
        Returns:
            Dictionary mapping function names to their dependencies
        """
        if module_path in self.function_dependencies:
            return self.function_dependencies[module_path]
        
        module_analysis = self.analyze_module(module_path)
        if not module_analysis:
            return {}
        
        dependencies = {}
        
        function_names = [func['name'] for func in module_analysis['functions']]
        
        for func in module_analysis['functions']:
            func_deps = []
            func_node = func['node']
            
            for node in ast.walk(func_node):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                    if node.func.id in function_names:
                        func_deps.append(node.func.id)
            
            dependencies[func['name']] = func_deps
        
        self.function_dependencies[module_path] = dependencies
        return dependencies
    
    def build_class_hierarchy(self, module_path: str) -> Dict[str, List[str]]:
        """
        Build the class hierarchy for a module.
        
        Args:
            module_path: Path to the Python module
            
        Returns:
            Dictionary mapping class names to their subclasses
        """
        if module_path in self.class_hierarchies:
            return self.class_hierarchies[module_path]
        
        module_analysis = self.analyze_module(module_path)
        if not module_analysis:
            return {}
        
        hierarchy = {}
        
        for cls in module_analysis['classes']:
            for base in cls['bases']:
                if base:
                    if base not in hierarchy:
                        hierarchy[base] = []
                    hierarchy[base].append(cls['name'])
        
        self.class_hierarchies[module_path] = hierarchy
        return hierarchy


class CodeModifier:
    """
    Modifies Python code based on analysis and desired changes.
    """
    
    def __init__(self, analyzer: CodeAnalyzer):
        self.analyzer = analyzer
        
    def modify_function(self, module_path: str, function_name: str, new_code: str) -> bool:
        """
        Modify a function in a module.
        
        Args:
            module_path: Path to the Python module
            function_name: Name of the function to modify
            new_code: New code for the function
            
        Returns:
            True if modification was successful, False otherwise
        """
        try:
            module_analysis = self.analyzer.analyze_module(module_path)
            if not module_analysis:
                return False
            
            with open(module_path, 'r') as f:
                code = f.read()
            
            for func in module_analysis['functions']:
                if func['name'] == function_name:
                    func_node = func['node']
                    
                    # Get the source code lines
                    source_lines = code.splitlines()
                    
                    # Get the line numbers for the function
                    start_line = func_node.lineno - 1  # Convert to 0-indexed
                    end_line = func_node.end_lineno if hasattr(func_node, 'end_lineno') else None
                    
                    if end_line is None:
                        # Find the end of the function by indentation
                        end_line = start_line + 1
                        while end_line < len(source_lines):
                            if end_line >= len(source_lines) or (source_lines[end_line].strip() and 
                                                               not source_lines[end_line].startswith(' ' * (func_node.col_offset + 4))):
                                break
                            end_line += 1
                    else:
                        end_line = end_line - 1  # Convert to 0-indexed
                    
                    # Replace the function code
                    modified_code = source_lines[:start_line] + [new_code] + source_lines[end_line+1:]
                    
                    # Write the modified code back to the file
                    with open(module_path, 'w') as f:
                        f.write('\n'.join(modified_code))
                    
                    return True
            
            return False
            
        except Exception as e:
            print(f"Error modifying function {function_name} in {module_path}: {e}")
            return False
    
    def add_function(self, module_path: str, function_code: str) -> bool:
        """
        Add a new function to a module.
        
        Args:
            module_path: Path to the Python module
            function_code: Code for the new function
            
        Returns:
            True if addition was successful, False otherwise
        """
        try:
            # Parse the function code to ensure it's valid
            func_tree = self.analyzer.analyze_code(function_code)
            if not func_tree or not any(isinstance(node, ast.FunctionDef) for node in func_tree.body):
                print("Invalid function code")
                return False
            
            # Append the function to the module
            with open(module_path, 'a') as f:
                f.write('\n\n')  # Add some spacing
                f.write(function_code)
            
            return True
            
        except Exception as e:
            print(f"Error adding function to {module_path}: {e}")
            return False
    
    def modify_class(self, module_path: str, class_name: str, new_methods: Dict[str, str]) -> bool:
        """
        Modify methods in a class.
        
        Args:
            module_path: Path to the Python module
            class_name: Name of the class to modify
            new_methods: Dictionary mapping method names to new code
            
        Returns:
            True if modification was successful, False otherwise
        """
        try:
            module_analysis = self.analyzer.analyze_module(module_path)
            if not module_analysis:
                return False
            
            with open(module_path, 'r') as f:
                code = f.read()
            
            for cls in module_analysis['classes']:
                if cls['name'] == class_name:
                    cls_node = cls['node']
                    
                    # Get the source code lines
                    source_lines = code.splitlines()
                    
                    # Get the line numbers for the class
                    start_line = cls_node.lineno - 1  # Convert to 0-indexed
                    end_line = cls_node.end_lineno if hasattr(cls_node, 'end_lineno') else None
                    
                    if end_line is None:
                        # Find the end of the class by indentation
                        end_line = start_line + 1
                        while end_line < len(source_lines):
                            if end_line >= len(source_lines) or (source_lines[end_line].strip() and 
                                                               not source_lines[end_line].startswith(' ' * (cls_node.col_offset + 4))):
                                break
                            end_line += 1
                    else:
                        end_line = end_line - 1  # Convert to 0-indexed
                    
                    # Extract the class code
                    class_code = '\n'.join(source_lines[start_line:end_line+1])
                    
                    # Modify the methods
                    for method_name, method_code in new_methods.items():
                        # Check if the method already exists
                        method_exists = False
                        for node in ast.walk(cls_node):
                            if isinstance(node, ast.FunctionDef) and node.name == method_name:
                                method_exists = True
                                method_start = node.lineno - cls_node.lineno
                                method_end = node.end_lineno - cls_node.lineno if hasattr(node, 'end_lineno') else None
                                
                                if method_end is None:
                                    # Find the end of the method by indentation
                                    method_lines = class_code.splitlines()
                                    method_start_idx = method_start
                                    method_end_idx = method_start_idx + 1
                                    while method_end_idx < len(method_lines):
                                        if method_end_idx >= len(method_lines) or (method_lines[method_end_idx].strip() and 
                                                                                not method_lines[method_end_idx].startswith(' ' * (node.col_offset + 4))):
                                            break
                                        method_end_idx += 1
                                    
                                    # Replace the method code
                                    class_code_lines = class_code.splitlines()
                                    class_code = '\n'.join(class_code_lines[:method_start_idx] + 
                                                          [method_code] + 
                                                          class_code_lines[method_end_idx:])
                                else:
                                    method_end = method_end - cls_node.lineno
                                    
                                    # Replace the method code
                                    class_code_lines = class_code.splitlines()
                                    class_code = '\n'.join(class_code_lines[:method_start] + 
                                                          [method_code] + 
                                                          class_code_lines[method_end+1:])
                                
                                break
                        
                        if not method_exists:
                            # Add the new method to the class
                            class_code_lines = class_code.splitlines()
                            indentation = ' ' * (cls_node.col_offset + 4)
                            indented_method_code = '\n'.join([indentation + line for line in method_code.splitlines()])
                            class_code = class_code + '\n' + indented_method_code
                    
                    # Replace the class code in the module
                    modified_code = source_lines[:start_line] + [class_code] + source_lines[end_line+1:]
                    
                    # Write the modified code back to the file
                    with open(module_path, 'w') as f:
                        f.write('\n'.join(modified_code))
                    
                    return True
            
            return False
            
        except Exception as e:
            print(f"Error modifying class {class_name} in {module_path}: {e}")
            return False


class CodeExecutor:
    """
    Executes Python code in a controlled environment, allowing for dynamic evaluation
    and execution of code generated or modified by the system.
    """
    
    def __init__(self, sandbox_mode: bool = True):
        self.sandbox_mode = sandbox_mode
        self.execution_history = []
        self.loaded_modules = {}
    
    def execute_code(self, code_string: str, globals_dict: Optional[Dict] = None) -> Any:
        """
        Execute a string of Python code.
        
        Args:
            code_string: The Python code to execute
            globals_dict: Optional dictionary to use as the globals environment
            
        Returns:
            The result of executing the code
        """
        if globals_dict is None:
            globals_dict = {'__builtins__': __builtins__}
        
        try:
            # Record the execution attempt
            self.execution_history.append({
                'code': code_string,
                'timestamp': import_time().time(),
                'success': None,
                'result': None,
                'error': None
            })
            
            # Execute the code
            result = eval(code_string, globals_dict)
            
            # Update the execution record
            self.execution_history[-1]['success'] = True
            self.execution_history[-1]['result'] = result
            
            return result
            
        except Exception as e:
            # Update the execution record
            self.execution_history[-1]['success'] = False
            self.execution_history[-1]['error'] = str(e)
            
            print(f"Error executing code: {e}")
            return None
    
    def execute_function(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function with the given arguments.
        
        Args:
            func: The function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function
            
        Returns:
            The result of executing the function
        """
        try:
            # Record the execution attempt
            self.execution_history.append({
                'function': func.__name__,
                'args': args,
                'kwargs': kwargs,
                'timestamp': import_time().time(),
                'success': None,
                'result': None,
                'error': None
            })
            
            # Execute the function
            result = func(*args, **kwargs)
            
            # Update the execution record
            self.execution_history[-1]['success'] = True
            self.execution_history[-1]['result'] = result
            
            return result
            
        except Exception as e:
            # Update the execution record
            self.execution_history[-1]['success'] = False
            self.execution_history[-1]['error'] = str(e)
            
            print(f"Error executing function {func.__name__}: {e}")
            return None
    
    def load_module_from_path(self, module_path: str, module_name: Optional[str] = None) -> types.ModuleType:
        """
        Load a Python module from a file path.
        
        Args:
            module_path: Path to the Python module
            module_name: Optional name for the module
            
        Returns:
            The loaded module
        """
        if module_path in self.loaded_modules:
            return self.loaded_modules[module_path]
        
        try:
            if module_name is None:
                module_name = os.path.basename(module_path).replace('.py', '')
            
            spec = importlib.util.spec_from_file_location(module_name, module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            self.loaded_modules[module_path] = module
            return module
            
        except Exception as e:
            print(f"Error loading module {module_path}: {e}")
            return None
    
    def create_function_from_code(self, code_string: str, function_name: Optional[str] = None) -> Callable:
        """
        Create a function from a string of Python code.
        
        Args:
            code_string: The Python code defining the function
            function_name: Optional name for the function
            
        Returns:
            The created function
        """
        try:
            # Parse the code to extract the function definition
            tree = ast.parse(code_string)
            
            for node in tree.body:
                if isinstance(node, ast.FunctionDef):
                    # Found a function definition
                    if function_name is None:
                        function_name = node.name
                    
                    # Compile the function code
                    compiled_code = compile(tree, '<string>', 'exec')
                    
                    # Create a namespace for the function
                    namespace = {}
                    
                    # Execute the compiled code in the namespace
                    exec(compiled_code, namespace)
                    
                    # Return the function from the namespace
                    return namespace[node.name]
            
            # If no function definition was found, compile the code as an expression
            compiled_code = compile(f"lambda: {code_string}", '<string>', 'eval')
            return eval(compiled_code)
            
        except Exception as e:
            print(f"Error creating function from code: {e}")
            return None


class MetaCircularEvaluator:
    """
    A meta-circular evaluator that allows the system to analyze, modify, and execute
    its own code. This is the foundation for self-modification and unlimited
    self-improvement.
    """
    
    def __init__(self):
        self.analyzer = CodeAnalyzer()
        self.modifier = CodeModifier(self.analyzer)
        self.executor = CodeExecutor()
        self.self_representation = {}
        
    def initialize_self_representation(self, root_dir: str) -> None:
        """
        Initialize the self-representation by analyzing all Python files in the given directory.
        
        Args:
            root_dir: Root directory of the system
        """
        for root, _, files in os.walk(root_dir):
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    module_analysis = self.analyzer.analyze_module(file_path)
                    if module_analysis:
                        self.self_representation[file_path] = module_analysis
        
        # Analyze dependencies between modules
        self.analyze_module_dependencies()
    
    def analyze_module_dependencies(self) -> None:
        """
        Analyze dependencies between modules in the self-representation.
        """
        module_dependencies = {}
        
        for module_path, module_analysis in self.self_representation.items():
            dependencies = []
            
            for import_name in module_analysis['imports']:
                # Check if this import refers to another module in the system
                for other_path in self.self_representation:
                    if os.path.basename(other_path).replace('.py', '') == import_name.split('.')[0]:
                        dependencies.append(other_path)
            
            module_dependencies[module_path] = dependencies
        
        self.self_representation['module_dependencies'] = module_dependencies
    
    def modify_self(self, module_path: str, modifications: Dict) -> bool:
        """
        Modify the system's own code.
        
        Args:
            module_path: Path to the module to modify
            modifications: Dictionary specifying the modifications to make
            
        Returns:
            True if modifications were successful, False otherwise
        """
        success = True
        
        if 'functions' in modifications:
            for func_name, func_code in modifications['functions'].items():
                if not self.modifier.modify_function(module_path, func_name, func_code):
                    success = False
        
        if 'add_functions' in modifications:
            for func_code in modifications['add_functions']:
                if not self.modifier.add_function(module_path, func_code):
                    success = False
        
        if 'classes' in modifications:
            for class_name, methods in modifications['classes'].items():
                if not self.modifier.modify_class(module_path, class_name, methods):
                    success = False
        
        # Update the self-representation if modifications were made
        if success:
            module_analysis = self.analyzer.analyze_module(module_path)
            if module_analysis:
                self.self_representation[module_path] = module_analysis
        
        return success
    
    def evaluate_modification(self, module_path: str, modifications: Dict, test_function: Callable) -> bool:
        """
        Evaluate a proposed modification by testing it before applying it permanently.
        
        Args:
            module_path: Path to the module to modify
            modifications: Dictionary specifying the modifications to make
            test_function: Function to test the modifications
            
        Returns:
            True if the modifications pass the test, False otherwise
        """
        # Create a temporary copy of the module
        temp_dir = os.path.join(os.path.dirname(module_path), 'temp')
        os.makedirs(temp_dir, exist_ok=True)
        
        temp_path = os.path.join(temp_dir, os.path.basename(module_path))
        
        try:
            # Copy the module to the temporary location
            with open(module_path, 'r') as src, open(temp_path, 'w') as dst:
                dst.write(src.read())
            
            # Apply the modifications to the temporary copy
            success = True
            
            if 'functions' in modifications:
                for func_name, func_code in modifications['functions'].items():
                    if not self.modifier.modify_function(temp_path, func_name, func_code):
                        success = False
            
            if 'add_functions' in modifications:
                for func_code in modifications['add_functions']:
                    if not self.modifier.add_function(temp_path, func_code):
                        success = False
            
            if 'classes' in modifications:
                for class_name, methods in modifications['classes'].items():
                    if not self.modifier.modify_class(temp_path, class_name, methods):
                        success = False
            
            if not success:
                return False
            
            # Load the modified module
            temp_module = self.executor.load_module_from_path(temp_path)
            if not temp_module:
                return False
            
            # Test the modifications
            test_result = test_function(temp_module)
            
            return test_result
            
        except Exception as e:
            print(f"Error evaluating modification: {e}")
            return False
        
        finally:
            # Clean up the temporary directory
            if os.path.exists(temp_path):
                os.remove(temp_path)
            if os.path.exists(temp_dir):
                try:
                    os.rmdir(temp_dir)
                except:
                    pass
    
    def apply_self_improvement(self, improvement_function: Callable) -> bool:
        """
        Apply a self-improvement function to the system.
        
        Args:
            improvement_function: Function that generates improvements to the system
            
        Returns:
            True if improvements were successfully applied, False otherwise
        """
        try:
            # Generate improvements
            improvements = improvement_function(self.self_representation)
            
            if not improvements:
                return False
            
            # Apply each improvement
            success = True
            for module_path, modifications in improvements.items():
                if not self.modify_self(module_path, modifications):
                    success = False
            
            return success
            
        except Exception as e:
            print(f"Error applying self-improvement: {e}")
            return False


# Helper function to import time module
def import_time():
    import time
    return time
