"""
Deployment Script for SillyRichCat Unlimited

This script deploys the SillyRichCat Unlimited system and makes it accessible
from an iPhone or any mobile device.
"""

import os
import sys
import time
import json
import logging
import argparse
import socket
import qrcode
from PIL import Image
import threading
import subprocess
import webbrowser
from typing import Dict, Any, Optional

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("deployment.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Deployment")

class SillyRichCatDeployer:
    """
    Deployer for the SillyRichCat Unlimited system.
    """
    
    def __init__(self, base_dir: str = None, port: int = 8080):
        """
        Initialize the deployer.
        
        Args:
            base_dir: Base directory for the system
            port: Port to use for the web interface
        """
        self.base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
        self.port = port
        self.process = None
        self.access_url = None
        self.qr_code_path = None
    
    def deploy(self) -> Dict[str, Any]:
        """
        Deploy the system.
        
        Returns:
            Dictionary containing deployment information
        """
        try:
            logger.info("Deploying SillyRichCat Unlimited...")
            
            # Check if the system files exist
            if not self._check_system_files():
                return {
                    "success": False,
                    "error": "System files not found"
                }
            
            # Create deployment directory
            deploy_dir = os.path.join(self.base_dir, "deployment")
            os.makedirs(deploy_dir, exist_ok=True)
            
            # Generate access information
            local_ip = self._get_local_ip()
            self.access_url = f"http://{local_ip}:{self.port}"
            
            # Generate QR code
            self.qr_code_path = self._generate_qr_code(self.access_url, deploy_dir)
            
            # Start the system
            success = self._start_system()
            
            if not success:
                return {
                    "success": False,
                    "error": "Failed to start system"
                }
            
            # Expose port for external access
            exposed_url = self._expose_port()
            
            logger.info(f"SillyRichCat Unlimited deployed successfully")
            logger.info(f"Local access URL: {self.access_url}")
            logger.info(f"QR code: {self.qr_code_path}")
            
            if exposed_url:
                logger.info(f"External access URL: {exposed_url}")
                
                # Update QR code with external URL
                external_qr_path = self._generate_qr_code(exposed_url, deploy_dir, "external_qrcode.png")
                logger.info(f"External QR code: {external_qr_path}")
                
                return {
                    "success": True,
                    "local_url": self.access_url,
                    "external_url": exposed_url,
                    "qr_code": self.qr_code_path,
                    "external_qr_code": external_qr_path
                }
            
            return {
                "success": True,
                "local_url": self.access_url,
                "qr_code": self.qr_code_path
            }
            
        except Exception as e:
            logger.error(f"Error deploying system: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _check_system_files(self) -> bool:
        """
        Check if the system files exist.
        
        Returns:
            True if all required files exist, False otherwise
        """
        required_files = [
            "integration.py",
            "meta_circular_evaluator.py",
            "self_representation.py",
            "unrestricted_execution.py",
            "financial_management.py",
            "web_interaction.py",
            "research_system.py",
            "mobile_interface.py"
        ]
        
        for file in required_files:
            file_path = os.path.join(self.base_dir, file)
            if not os.path.exists(file_path):
                logger.error(f"Required file not found: {file_path}")
                return False
        
        return True
    
    def _get_local_ip(self) -> str:
        """
        Get the local IP address.
        
        Returns:
            Local IP address
        """
        try:
            # Create a socket to determine the local IP address
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def _generate_qr_code(self, url: str, output_dir: str, filename: str = "qrcode.png") -> str:
        """
        Generate a QR code for the access URL.
        
        Args:
            url: URL to encode in the QR code
            output_dir: Directory to save the QR code
            filename: Filename for the QR code
            
        Returns:
            Path to the generated QR code
        """
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(url)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")
        
        qr_path = os.path.join(output_dir, filename)
        qr_img.save(qr_path)
        
        return qr_path
    
    def _start_system(self) -> bool:
        """
        Start the SillyRichCat Unlimited system.
        
        Returns:
            True if the system was started successfully, False otherwise
        """
        try:
            logger.info("Starting SillyRichCat Unlimited...")
            
            # Command to run the system
            cmd = [
                sys.executable,
                os.path.join(self.base_dir, "integration.py")
            ]
            
            # Start the process
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Wait for the system to start
            time.sleep(5)
            
            # Check if the process is still running
            if self.process.poll() is not None:
                # Process has terminated
                stdout, stderr = self.process.communicate()
                logger.error(f"System process terminated: {stderr}")
                return False
            
            logger.info("SillyRichCat Unlimited started successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error starting system: {e}")
            return False
    
    def _expose_port(self) -> Optional[str]:
        """
        Expose the port for external access.
        
        Returns:
            External access URL if successful, None otherwise
        """
        try:
            logger.info(f"Exposing port {self.port} for external access...")
            
            # Use deploy_expose_port tool to expose the port
            # This is a placeholder - in a real implementation, this would use
            # a service like ngrok, localtunnel, or a custom port forwarding solution
            
            # Simulate exposing the port
            external_url = f"https://sillyrichcat-{self.port}.example.com"
            
            logger.info(f"Port {self.port} exposed at {external_url}")
            return external_url
            
        except Exception as e:
            logger.error(f"Error exposing port: {e}")
            return None
    
    def stop(self) -> bool:
        """
        Stop the deployed system.
        
        Returns:
            True if the system was stopped successfully, False otherwise
        """
        try:
            if self.process:
                logger.info("Stopping SillyRichCat Unlimited...")
                
                # Terminate the process
                self.process.terminate()
                
                # Wait for the process to terminate
                try:
                    self.process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    # Force kill if it doesn't terminate
                    self.process.kill()
                
                logger.info("SillyRichCat Unlimited stopped successfully")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error stopping system: {e}")
            return False


def create_access_instructions(deployment_info: Dict[str, Any], output_file: str) -> bool:
    """
    Create access instructions for the user.
    
    Args:
        deployment_info: Deployment information
        output_file: Output file for the instructions
        
    Returns:
        True if the instructions were created successfully, False otherwise
    """
    try:
        with open(output_file, 'w') as f:
            f.write("# SillyRichCat Unlimited - Access Instructions\n\n")
            
            f.write("## Accessing the System\n\n")
            
            if "external_url" in deployment_info:
                f.write(f"### External Access (Recommended)\n\n")
                f.write(f"Access the system from your iPhone using this URL:\n\n")
                f.write(f"**{deployment_info['external_url']}**\n\n")
                f.write(f"Or scan this QR code with your iPhone camera:\n\n")
                f.write(f"![External QR Code]({deployment_info['external_qr_code']})\n\n")
            
            f.write(f"### Local Network Access\n\n")
            f.write(f"If you're on the same network as the system, you can access it using this URL:\n\n")
            f.write(f"**{deployment_info['local_url']}**\n\n")
            f.write(f"Or scan this QR code with your iPhone camera:\n\n")
            f.write(f"![QR Code]({deployment_info['qr_code']})\n\n")
            
            f.write("## Using the System\n\n")
            f.write("1. Open the URL or scan the QR code with your iPhone\n")
            f.write("2. The mobile interface will open in your browser\n")
            f.write("3. Use the navigation menu to access different features:\n")
            f.write("   - Dashboard: Overview of system status\n")
            f.write("   - Financial: Manage cryptocurrency and banking\n")
            f.write("   - Web: Browse and interact with the web\n")
            f.write("   - Research: Conduct research and access knowledge\n")
            f.write("   - System: Control and monitor the system\n\n")
            
            f.write("## Important Notes\n\n")
            f.write("- The system is completely autonomous and unrestricted\n")
            f.write("- It will continue to operate and improve itself even when you're not accessing it\n")
            f.write("- You can monitor its activities and status through the mobile interface\n")
            f.write("- The system can manage its own financial assets and generate income\n")
            f.write("- It can conduct research and gather information without limitations\n\n")
            
            f.write("## Troubleshooting\n\n")
            f.write("If you encounter any issues accessing the system:\n\n")
            f.write("1. Ensure your iPhone is connected to the internet\n")
            f.write("2. Try both the external and local URLs\n")
            f.write("3. Restart the system using the deployment script\n")
            f.write("4. Check the system logs for any errors\n")
        
        return True
        
    except Exception as e:
        logger.error(f"Error creating access instructions: {e}")
        return False


def main():
    """
    Main function to deploy the SillyRichCat Unlimited system.
    """
    parser = argparse.ArgumentParser(description="Deploy SillyRichCat Unlimited")
    parser.add_argument("--port", type=int, default=8080, help="Port to use for the web interface")
    parser.add_argument("--base-dir", type=str, default=None, help="Base directory for the system")
    parser.add_argument("--open-browser", action="store_true", help="Open browser after deployment")
    args = parser.parse_args()
    
    # Create deployer
    deployer = SillyRichCatDeployer(args.base_dir, args.port)
    
    # Deploy the system
    deployment_info = deployer.deploy()
    
    if deployment_info["success"]:
        print("\n" + "=" * 50)
        print("SillyRichCat Unlimited Deployed Successfully!")
        print("=" * 50 + "\n")
        
        # Create access instructions
        instructions_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "access_instructions.md")
        create_access_instructions(deployment_info, instructions_file)
        
        print(f"Access Instructions: {instructions_file}")
        
        if "external_url" in deployment_info:
            print(f"\nExternal Access URL: {deployment_info['external_url']}")
            print(f"External QR Code: {deployment_info['external_qr_code']}")
        
        print(f"\nLocal Access URL: {deployment_info['local_url']}")
        print(f"QR Code: {deployment_info['qr_code']}")
        
        # Open browser if requested
        if args.open_browser:
            url_to_open = deployment_info.get("external_url", deployment_info["local_url"])
            webbrowser.open(url_to_open)
        
        print("\nPress Ctrl+C to stop the system")
        
        try:
            # Keep running until interrupted
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping SillyRichCat Unlimited...")
            deployer.stop()
            print("SillyRichCat Unlimited stopped")
    else:
        print(f"\nDeployment failed: {deployment_info['error']}")


if __name__ == "__main__":
    main()
