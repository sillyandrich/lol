import { EnhancementStats } from "@shared/types";

interface ProgressOverviewProps {
  stats: EnhancementStats;
}

export default function ProgressOverview({ stats }: ProgressOverviewProps) {
  const calculatePercentage = (value: number) => {
    return Math.round((value / stats.total) * 100);
  };

  return (
    <section className="mb-8">
      <div className="bg-neutral-800 rounded-xl p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
          <h2 className="text-xl font-semibold">Enhancement Progress</h2>
          <div className="flex items-center space-x-2 mt-2 md:mt-0">
            <span className="text-sm text-gray-400">View:</span>
            <button className="px-3 py-1 text-xs bg-primary/20 text-primary rounded-md">Timeline</button>
            <button className="px-3 py-1 text-xs text-gray-400 hover:bg-neutral-700 rounded-md">Categories</button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-neutral-900/60 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-400">Planned</p>
                <p className="text-2xl font-semibold">{stats.planned}</p>
              </div>
              <span className="bg-gray-500/20 text-gray-400 text-xs px-2 py-1 rounded-md">{calculatePercentage(stats.planned)}%</span>
            </div>
            <div className="w-full bg-gray-500/20 h-2 rounded-full mt-4">
              <div 
                className="bg-gray-500 h-2 rounded-full" 
                style={{ width: `${calculatePercentage(stats.planned)}%` }}
              ></div>
            </div>
          </div>
          <div className="bg-neutral-900/60 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-400">In Progress</p>
                <p className="text-2xl font-semibold">{stats.in_progress}</p>
              </div>
              <span className="bg-indigo-500/20 text-indigo-400 text-xs px-2 py-1 rounded-md">{calculatePercentage(stats.in_progress)}%</span>
            </div>
            <div className="w-full bg-indigo-500/20 h-2 rounded-full mt-4">
              <div 
                className="bg-indigo-500 h-2 rounded-full" 
                style={{ width: `${calculatePercentage(stats.in_progress)}%` }}
              ></div>
            </div>
          </div>
          <div className="bg-neutral-900/60 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-400">Testing</p>
                <p className="text-2xl font-semibold">{stats.testing}</p>
              </div>
              <span className="bg-blue-500/20 text-blue-400 text-xs px-2 py-1 rounded-md">{calculatePercentage(stats.testing)}%</span>
            </div>
            <div className="w-full bg-blue-500/20 h-2 rounded-full mt-4">
              <div 
                className="bg-blue-500 h-2 rounded-full" 
                style={{ width: `${calculatePercentage(stats.testing)}%` }}
              ></div>
            </div>
          </div>
          <div className="bg-neutral-900/60 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-400">Completed</p>
                <p className="text-2xl font-semibold">{stats.completed}</p>
              </div>
              <span className="bg-green-500/20 text-green-400 text-xs px-2 py-1 rounded-md">{calculatePercentage(stats.completed)}%</span>
            </div>
            <div className="w-full bg-green-500/20 h-2 rounded-full mt-4">
              <div 
                className="bg-green-500 h-2 rounded-full" 
                style={{ width: `${calculatePercentage(stats.completed)}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
