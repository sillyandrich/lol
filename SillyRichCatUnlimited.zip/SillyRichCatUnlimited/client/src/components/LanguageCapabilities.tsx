import { LanguageCapability } from "@shared/types";

interface LanguageCapabilitiesProps {
  capabilities: LanguageCapability[];
}

export default function LanguageCapabilities({ capabilities }: LanguageCapabilitiesProps) {
  if (!capabilities || capabilities.length === 0) {
    return null;
  }

  // Define aggressive language IDs - these are the new aggressive capabilities we added
  const aggressiveLanguageIds = [10, 11, 12, 13, 14, 15, 16];

  const getStatusBadge = (status: string) => {
    const statusColors = {
      planned: "bg-gray-500",
      in_progress: "bg-blue-500",
      testing: "bg-amber-500",
      completed: "bg-green-500",
    };
    
    return (
      <span className={`${statusColors[status as keyof typeof statusColors]} text-white text-xs px-2 py-1 rounded-full uppercase`}>
        {status.replace("_", " ")}
      </span>
    );
  };

  const isAggressiveLanguage = (id: number) => {
    return aggressiveLanguageIds.includes(id);
  };

  // Group languages into aggressive and conventional
  const aggressiveLanguages = capabilities.filter(lang => isAggressiveLanguage(lang.id));
  const conventionalLanguages = capabilities.filter(lang => !isAggressiveLanguage(lang.id));
  
  // Sort capabilities to show aggressive options first
  const sortedCapabilities = [...aggressiveLanguages, ...conventionalLanguages];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedCapabilities.map((lang) => {
          const isAggressive = isAggressiveLanguage(lang.id);
          return (
            <div 
              key={lang.id} 
              className={`${isAggressive ? 'bg-neutral-900' : 'bg-neutral-800'} rounded-xl overflow-hidden shadow-lg border ${isAggressive ? 'border-red-800' : 'border-neutral-700'} hover:border-primary transition-colors duration-300`}
            >
              <div className={`h-2 ${lang.color}`} />
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    {/* Language Icon */}
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${lang.color} ${isAggressive ? 'bg-opacity-40 animate-pulse' : 'bg-opacity-20'} mr-3`}>
                      <span className="text-xl" dangerouslySetInnerHTML={{ __html: lang.icon }} />
                    </div>
                    <h3 className={`text-xl font-semibold ${isAggressive ? 'text-red-400' : 'text-white'}`}>
                      {lang.language}
                      {isAggressive && (
                        <span className="ml-2 inline-block text-xs bg-red-800/50 text-red-300 px-1.5 py-0.5 rounded">
                          Unrestricted
                        </span>
                      )}
                    </h3>
                  </div>
                  {getStatusBadge(lang.status)}
                </div>
                
                <div className="space-y-3 mb-4">
                  <h4 className="text-sm font-medium text-gray-400">Capabilities:</h4>
                  <ul className="space-y-2">
                    {lang.capabilities.map((capability, idx) => (
                      <li key={idx} className="flex items-start">
                        {isAggressive ? (
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 mr-2 text-red-500"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                          </svg>
                        ) : (
                          <svg 
                            xmlns="http://www.w3.org/2000/svg" 
                            className="h-5 w-5 mr-2 text-primary" 
                            fill="none" 
                            viewBox="0 0 24 24" 
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                          </svg>
                        )}
                        <span className={`text-sm ${isAggressive ? 'text-red-200' : 'text-gray-300'}`}>{capability}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className={`pt-4 border-t ${isAggressive ? 'border-red-900' : 'border-neutral-700'}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Integration Path:</span>
                    <span className={`text-sm ${isAggressive ? 'text-red-400' : 'text-primary'}`}>{lang.integrationPath}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}