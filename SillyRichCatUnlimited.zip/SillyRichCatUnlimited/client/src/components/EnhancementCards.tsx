import { EnhancementCategory } from "@shared/types";
import EnhancementCard from "./EnhancementCard";

interface EnhancementCardsProps {
  enhancements: EnhancementCategory[];
}

export default function EnhancementCards({ enhancements }: EnhancementCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {enhancements.map((enhancement) => (
        <EnhancementCard key={enhancement.id} enhancement={enhancement} />
      ))}
    </div>
  );
}
