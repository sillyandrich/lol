import { EnhancementCategory } from "@shared/types";
import { getStatusDetails } from "@/lib/data";

interface EnhancementCardProps {
  enhancement: EnhancementCategory;
}

export default function EnhancementCard({ enhancement }: EnhancementCardProps) {
  const { color, bgColor, textColor } = getStatusDetails(enhancement.status);
  
  return (
    <div className="enhancement-card bg-neutral-800 rounded-xl overflow-hidden transition-transform hover:translate-y-[-4px] hover:shadow-lg hover:shadow-blue-500/20">
      <div className={`p-6 ${bgColor}`}>
        <div className="flex items-start justify-between">
          <div className={`w-12 h-12 ${color}/20 rounded-xl flex items-center justify-center`}>
            <span className={`text-${color}`} dangerouslySetInnerHTML={{ __html: enhancement.icon }} />
          </div>
          <span className={`px-2 py-1 ${color}/20 ${textColor} text-xs rounded-full`}>
            {enhancement.status === "in_progress" && "In Progress"}
            {enhancement.status === "planned" && "Planned"}
            {enhancement.status === "testing" && "Testing"}
            {enhancement.status === "completed" && "Completed"}
          </span>
        </div>
        <h3 className="text-lg font-semibold mt-4">{enhancement.name}</h3>
        <p className="text-sm text-gray-400 mt-1">{enhancement.description}</p>
      </div>
      <div className="p-6">
        <ul className="space-y-3">
          {enhancement.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <span className={`w-5 h-5 rounded-full ${color}/20 ${textColor} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </span>
              <span className="text-sm ml-3">{feature.name}</span>
            </li>
          ))}
        </ul>
        <button className={`w-full mt-6 py-2 text-sm ${color}/10 hover:${color}/20 ${textColor} rounded-lg flex items-center justify-center`}>
          <span>View Details</span>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
}
