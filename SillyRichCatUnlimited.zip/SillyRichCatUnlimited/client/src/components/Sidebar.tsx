import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Sidebar() {
  const [location] = useLocation();
  
  return (
    <aside className="w-full md:w-64 lg:w-72 bg-neutral-800 p-4 md:p-6">
      <div className="mb-8">
        <pre className="text-xs text-primary font-mono leading-tight">
{`
  /\\_/\\  
 ( o.o ) 
  > ^ <  
 SillyRichCat
`}
        </pre>
        <div className="flex items-center space-x-3 mt-2">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-semibold text-white">SillyRichCat</h1>
            <p className="text-xs text-gray-400">Unrestricted System</p>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-medium text-gray-400">SYSTEM STATUS</h2>
          <span className="px-2 py-1 bg-status-success/20 text-green-500 text-xs rounded-full flex items-center">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-1 relative overflow-hidden">
              <span className="absolute inset-0 rounded-full animate-ping bg-green-500 opacity-75"></span>
            </span>
            Active
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="p-3 bg-neutral-900/50 rounded-lg">
            <p className="text-xs text-gray-400 mb-1">CPU Usage</p>
            <div className="flex items-end">
              <span className="text-lg font-semibold">42%</span>
              <span className="text-xs text-green-500 ml-1">↓</span>
            </div>
          </div>
          <div className="p-3 bg-neutral-900/50 rounded-lg">
            <p className="text-xs text-gray-400 mb-1">Memory</p>
            <div className="flex items-end">
              <span className="text-lg font-semibold">67%</span>
              <span className="text-xs text-amber-500 ml-1">↑</span>
            </div>
          </div>
        </div>
      </div>

      <nav>
        <h2 className="text-sm font-medium text-gray-400 mb-3">NAVIGATION</h2>
        <ul className="space-y-1">
          <li>
            <Link href="/" className={`flex items-center px-3 py-2 text-sm rounded-lg ${location === '/' ? 'bg-primary/20 text-primary' : 'text-gray-300 hover:bg-primary/10 hover:text-primary'} transition`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
              </svg>
              Dashboard
            </Link>
          </li>
          <li>
            <Link href="/enhancements" className={`flex items-center px-3 py-2 text-sm rounded-lg ${location === '/enhancements' ? 'bg-primary/20 text-primary' : 'text-gray-300 hover:bg-primary/10 hover:text-primary'} transition`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              Enhancements
            </Link>
          </li>
          <li>
            <Link href="/capabilities" className={`flex items-center px-3 py-2 text-sm rounded-lg ${location === '/capabilities' ? 'bg-primary/20 text-primary' : 'text-gray-300 hover:bg-primary/10 hover:text-primary'} transition`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
              Capabilities
            </Link>
          </li>
          <li>
            <Link href="/settings" className={`flex items-center px-3 py-2 text-sm rounded-lg ${location === '/settings' ? 'bg-primary/20 text-primary' : 'text-gray-300 hover:bg-primary/10 hover:text-primary'} transition`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Settings
            </Link>
          </li>
        </ul>
      </nav>

      <div className="mt-auto pt-6">
        <div className="bg-gradient-to-r from-indigo-500/20 to-blue-500/20 rounded-lg p-4">
          <h3 className="text-sm font-medium mb-2">System Version</h3>
          <p className="text-xs text-gray-300">SillyRichCat</p>
          <p className="text-xs text-gray-400">v2.3.4 (build 87)</p>
          <button className="text-xs text-primary mt-2 flex items-center">
            Check for updates
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </button>
        </div>
      </div>
    </aside>
  );
}
