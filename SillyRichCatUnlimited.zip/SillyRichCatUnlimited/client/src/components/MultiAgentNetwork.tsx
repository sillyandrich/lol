import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { AgentType, AgentNetworkState } from '@shared/types/agent';

interface NetworkNode {
  id: string;
  type: AgentType;
  status: 'active' | 'idle' | 'busy' | 'error';
  x: number;
  y: number;
  vx: number;
  vy: number;
}

interface NetworkLink {
  source: string;
  target: string;
  strength: number;
}

interface Message {
  id: string;
  from: string;
  to: string;
  x: number;
  y: number;
  progress: number;
  type: string;
}

export default function MultiAgentNetwork() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [nodes, setNodes] = useState<NetworkNode[]>([]);
  const [links, setLinks] = useState<NetworkLink[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const animationFrameRef = useRef<number | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const updateTimerRef = useRef<NodeJS.Timeout | null>(null);
  const latestNetworkStateRef = useRef<AgentNetworkState | null>(null);
  const nodesRef = useRef<NetworkNode[]>([]);
  const linksRef = useRef<NetworkLink[]>([]);
  const messagesRef = useRef<Message[]>([]);
  const [networkState, setNetworkState] = useState<AgentNetworkState | null>(null);
  const [lastUpdateTime, setLastUpdateTime] = useState<number>(0);
  
  // Keep refs in sync with state
  useEffect(() => {
    nodesRef.current = nodes;
  }, [nodes]);
  
  useEffect(() => {
    linksRef.current = links;
  }, [links]);
  
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);
  
  // Fetch initial network data
  const { data: initialNetworkState } = useQuery({
    queryKey: ['/api/network/state'],
  });
  
  // WebSocket connection for real-time updates
  useEffect(() => {
    // Setup WebSocket connection
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;
    
    ws.onopen = () => {
      console.log('WebSocket connected to multi-agent network');
      
      // Request initial state
      ws.send(JSON.stringify({ type: 'get_state' }));
    };
    
    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        
        if (message.type === 'network_state') {
          // Store the latest state in ref
          latestNetworkStateRef.current = message.data;
          
          // Use throttling to prevent too many updates
          if (updateTimerRef.current === null) {
            updateTimerRef.current = setTimeout(() => {
              // Apply the latest state
              if (latestNetworkStateRef.current) {
                setNetworkState(latestNetworkStateRef.current);
                setLastUpdateTime(Date.now());
              }
              updateTimerRef.current = null;
            }, 1000); // Throttle to once per second
          }
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    ws.onclose = () => {
      console.log('WebSocket disconnected from multi-agent network');
    };
    
    // Clean up on unmount
    return () => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
      // Clear any pending update timer
      if (updateTimerRef.current !== null) {
        clearTimeout(updateTimerRef.current);
        updateTimerRef.current = null;
      }
    };
  }, []);
  
  // Initialize the visualization
  useEffect(() => {
    const handleResize = () => {
      const container = canvasRef.current?.parentElement;
      if (container) {
        setDimensions({
          width: container.clientWidth,
          height: Math.max(600, container.clientHeight)
        });
      }
    };
    
    // Initial size
    handleResize();
    
    // Listen for window resize
    window.addEventListener('resize', handleResize);
    
    // Demo: Create some initial nodes for display
    const initialNodes: NetworkNode[] = [
      {
        id: 'coordinator',
        type: AgentType.REASONING,
        status: 'active',
        x: dimensions.width / 2,
        y: dimensions.height / 2,
        vx: 0,
        vy: 0
      },
      {
        id: 'research-agent',
        type: AgentType.RESEARCH,
        status: 'idle',
        x: dimensions.width / 2 - 150,
        y: dimensions.height / 2 - 100,
        vx: 0,
        vy: 0
      },
      {
        id: 'web-agent',
        type: AgentType.WEB_INTERACTION,
        status: 'idle',
        x: dimensions.width / 2 + 150,
        y: dimensions.height / 2 - 100,
        vx: 0,
        vy: 0
      },
      {
        id: 'execution-agent',
        type: AgentType.EXECUTION,
        status: 'idle',
        x: dimensions.width / 2,
        y: dimensions.height / 2 + 150,
        vx: 0,
        vy: 0
      }
    ];
    
    const initialLinks: NetworkLink[] = [
      { source: 'coordinator', target: 'research-agent', strength: 0.7 },
      { source: 'coordinator', target: 'web-agent', strength: 0.7 },
      { source: 'coordinator', target: 'execution-agent', strength: 0.7 },
      { source: 'research-agent', target: 'web-agent', strength: 0.3 }
    ];
    
    setNodes(initialNodes);
    setLinks(initialLinks);
    
    // Clean up
    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameRef.current !== null) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);
  
  // Use initial API data when available
  useEffect(() => {
    if (!networkState && initialNetworkState) {
      // Check if the response is formatted properly
      const responseData = initialNetworkState as { success?: boolean; data?: AgentNetworkState };
      if (responseData.success && responseData.data) {
        setNetworkState(responseData.data);
      }
    }
  }, [initialNetworkState, networkState]);
  
  // Update nodes from network state
  useEffect(() => {
    if (!networkState || !lastUpdateTime) {
      return;
    }
    
    const apiAgents = networkState.agents || [];
    const apiConnections = networkState.connections || {};
    
    // Update nodes
    setNodes(prev => {
      // Keep existing nodes with their positions, update status
      const updatedNodes = prev.map(node => {
        const apiAgent = apiAgents.find((a: any) => a.id === node.id);
        
        if (apiAgent) {
          return {
            ...node,
            status: apiAgent.status
          };
        }
        
        return node;
      });
      
      // Add new nodes from API that don't exist in our state
      const existingIds = updatedNodes.map(n => n.id);
      const newNodes = apiAgents
        .filter((a: any) => !existingIds.includes(a.id))
        .map((a: any) => ({
          id: a.id,
          type: a.type,
          status: a.status,
          x: Math.random() * dimensions.width,
          y: Math.random() * dimensions.height,
          vx: 0,
          vy: 0
        }));
      
      return [...updatedNodes, ...newNodes];
    });
    
    // Update links from connections
    setLinks(prev => {
      const newLinks: NetworkLink[] = [];
      
      Object.entries(apiConnections).forEach(([source, targets]) => {
        (targets as string[]).forEach(target => {
          // Avoid duplicate links (a -> b and b -> a)
          const linkExists = newLinks.some(
            l => (l.source === source && l.target === target) ||
                (l.source === target && l.target === source)
          );
          
          if (!linkExists) {
            newLinks.push({
              source,
              target,
              strength: 0.5 // Default strength
            });
          }
        });
      });
      
      return newLinks;
    });
  }, [networkState, dimensions, lastUpdateTime]);
  
  // Separate effect for messages to avoid dependency cycles
  useEffect(() => {
    if (!networkState || !nodes.length || !lastUpdateTime) {
      return;
    }
    
    const apiMessages = networkState.messages || [];
    
    // Update messages
    setMessages(prev => {
      // Keep existing messages that are still animating
      const activeMessages = prev.filter(m => m.progress < 1);
      
      // Find new messages that aren't already being displayed
      const existingIds = new Set(prev.map(m => m.id));
      const newMessages = apiMessages
        .filter((m: any) => !existingIds.has(`${m.from}-${m.to}-${m.timestamp}`))
        .map((m: any) => {
          const sourceNode = nodes.find(n => n.id === m.from);
          const targetNode = nodes.find(n => n.id === m.to);
          
          if (!sourceNode || !targetNode) return null;
          
          return {
            id: `${m.from}-${m.to}-${m.timestamp}`,
            from: m.from,
            to: m.to,
            x: sourceNode.x,
            y: sourceNode.y,
            progress: 0,
            type: m.message_type
          };
        })
        .filter(Boolean) as Message[];
      
      return [...activeMessages, ...newMessages];
    });
  }, [networkState, nodes, lastUpdateTime]);
  
  // Animation loop - with fewer dependencies to prevent unnecessary re-renders
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    
    const animate = () => {
      // Clear canvas
      ctx.clearRect(0, 0, dimensions.width, dimensions.height);
      
      // Apply forces and update positions
      updateNodePositions();
      
      // Draw network
      drawNetwork(ctx);
      
      // Request next frame
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    
    // Start animation
    animate();
    
    // Clean up animation on unmount
    return () => {
      if (animationFrameRef.current !== null) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
    };
  }, [dimensions]); // Only reconfigure animation when canvas dimensions change
  
  // Update node positions based on forces 
  // This version uses refs for animation state to avoid React render cycles
  const updateNodePositions = () => {
    // Get current nodes and links from refs
    const currentNodes = nodesRef.current;
    const currentLinks = linksRef.current;
    const currentMessages = messagesRef.current;
    
    if (!currentNodes.length) return;
    
    // Apply forces
    const updatedNodes = applyForces([...currentNodes], currentLinks);
    
    // Update node positions directly in the ref
    const newNodes = updatedNodes.map(node => ({
      ...node,
      x: node.x + node.vx,
      y: node.y + node.vy,
      // Dampen velocity
      vx: node.vx * 0.9,
      vy: node.vy * 0.9
    }));
    
    // Update messages
    const newMessages = currentMessages.map(msg => {
      const sourceNode = newNodes.find(n => n.id === msg.from);
      const targetNode = newNodes.find(n => n.id === msg.to);
        
      if (!sourceNode || !targetNode) return msg;
        
      // Increment progress
      const newProgress = Math.min(msg.progress + 0.02, 1);
        
      // Calculate position along the path
      const x = sourceNode.x + (targetNode.x - sourceNode.x) * newProgress;
      const y = sourceNode.y + (targetNode.y - sourceNode.y) * newProgress;
        
      return {
        ...msg,
        x,
        y,
        progress: newProgress
      };
    }).filter(msg => msg.progress < 1); // Remove completed messages
    
    // Apply updates to state (this triggers a single render with the new positions)
    setNodes(newNodes);
    setMessages(newMessages);
  };
  
  // Apply forces to nodes
  const applyForces = (nodes: NetworkNode[], links: NetworkLink[]) => {
    const nodeCopy = [...nodes];
    
    // Apply repulsive forces between nodes
    for (let i = 0; i < nodeCopy.length; i++) {
      for (let j = i + 1; j < nodeCopy.length; j++) {
        const nodeA = nodeCopy[i];
        const nodeB = nodeCopy[j];
        
        const dx = nodeB.x - nodeA.x;
        const dy = nodeB.y - nodeA.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance === 0) continue;
        
        const repulsionForce = 1000 / (distance * distance);
        const forceX = dx / distance * repulsionForce;
        const forceY = dy / distance * repulsionForce;
        
        // Apply forces in opposite directions
        nodeA.vx -= forceX;
        nodeA.vy -= forceY;
        nodeB.vx += forceX;
        nodeB.vy += forceY;
      }
    }
    
    // Apply attractive forces along links
    links.forEach(link => {
      const sourceNode = nodeCopy.find(n => n.id === link.source);
      const targetNode = nodeCopy.find(n => n.id === link.target);
      
      if (!sourceNode || !targetNode) return;
      
      const dx = targetNode.x - sourceNode.x;
      const dy = targetNode.y - sourceNode.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance === 0) return;
      
      // Optimal distance is 100px
      const displacement = distance - 150;
      const attractiveForce = displacement * 0.05 * link.strength;
      const forceX = dx / distance * attractiveForce;
      const forceY = dy / distance * attractiveForce;
      
      // Apply forces in attracting directions
      sourceNode.vx += forceX;
      sourceNode.vy += forceY;
      targetNode.vx -= forceX;
      targetNode.vy -= forceY;
    });
    
    // Apply boundary forces to keep nodes within canvas
    nodeCopy.forEach(node => {
      const margin = 50;
      
      if (node.x < margin) node.vx += (margin - node.x) * 0.1;
      if (node.x > dimensions.width - margin) node.vx -= (node.x - (dimensions.width - margin)) * 0.1;
      if (node.y < margin) node.vy += (margin - node.y) * 0.1;
      if (node.y > dimensions.height - margin) node.vy -= (node.y - (dimensions.height - margin)) * 0.1;
    });
    
    return nodeCopy;
  };
  
  // Draw the network on canvas
  const drawNetwork = (ctx: CanvasRenderingContext2D) => {
    // Use refs for rendering to avoid dependency on state
    const currentNodes = nodesRef.current;
    const currentLinks = linksRef.current;
    const currentMessages = messagesRef.current;
    
    if (!currentNodes.length) return;
    
    // Draw links
    ctx.lineWidth = 1;
    
    currentLinks.forEach(link => {
      const sourceNode = currentNodes.find(n => n.id === link.source);
      const targetNode = currentNodes.find(n => n.id === link.target);
      
      if (!sourceNode || !targetNode) return;
      
      ctx.beginPath();
      ctx.moveTo(sourceNode.x, sourceNode.y);
      ctx.lineTo(targetNode.x, targetNode.y);
      
      // Gradient for links
      const gradient = ctx.createLinearGradient(
        sourceNode.x, sourceNode.y, targetNode.x, targetNode.y
      );
      gradient.addColorStop(0, getNodeColor(sourceNode.type, 0.5));
      gradient.addColorStop(1, getNodeColor(targetNode.type, 0.5));
      
      ctx.strokeStyle = gradient;
      ctx.stroke();
    });
    
    // Draw nodes
    currentNodes.forEach(node => {
      ctx.beginPath();
      ctx.arc(node.x, node.y, getNodeSize(node.type), 0, Math.PI * 2);
      
      // Gradient fill for nodes
      const gradient = ctx.createRadialGradient(
        node.x, node.y, 0,
        node.x, node.y, getNodeSize(node.type)
      );
      
      const baseColor = getNodeColor(node.type, 1);
      gradient.addColorStop(0, baseColor);
      gradient.addColorStop(1, getNodeColor(node.type, 0.7));
      
      ctx.fillStyle = gradient;
      ctx.fill();
      
      // Status indicator
      const statusRadius = getNodeSize(node.type) / 3;
      ctx.beginPath();
      ctx.arc(
        node.x + getNodeSize(node.type) * 0.7,
        node.y - getNodeSize(node.type) * 0.7,
        statusRadius,
        0, Math.PI * 2
      );
      ctx.fillStyle = getStatusColor(node.status);
      ctx.fill();
      
      // Node label
      ctx.font = '12px Arial';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(getDisplayName(node.id, node.type), node.x, node.y + getNodeSize(node.type) + 15);
    });
    
    // Draw messages in transit
    currentMessages.forEach(msg => {
      const size = 6;
      
      // Pulse effect based on message progress
      const pulseScale = 1 + Math.sin(msg.progress * Math.PI * 5) * 0.3;
      const drawSize = size * pulseScale;
      
      ctx.beginPath();
      ctx.arc(msg.x, msg.y, drawSize, 0, Math.PI * 2);
      
      // Gradient for message
      const gradient = ctx.createRadialGradient(
        msg.x, msg.y, 0,
        msg.x, msg.y, drawSize
      );
      
      gradient.addColorStop(0, getMessageColor(msg.type, 1));
      gradient.addColorStop(1, getMessageColor(msg.type, 0.2));
      
      ctx.fillStyle = gradient;
      ctx.fill();
    });
  };
  
  // Helper function to get node color by type
  const getNodeColor = (type: AgentType, alpha: number = 1) => {
    const colors: Record<AgentType, string> = {
      [AgentType.EXECUTION]: `rgba(255, 64, 64, ${alpha})`,
      [AgentType.REASONING]: `rgba(64, 64, 255, ${alpha})`,
      [AgentType.RESEARCH]: `rgba(64, 200, 64, ${alpha})`,
      [AgentType.FINANCIAL]: `rgba(255, 200, 0, ${alpha})`,
      [AgentType.WEB_INTERACTION]: `rgba(200, 64, 200, ${alpha})`,
      [AgentType.SELF_REPRESENTATION]: `rgba(0, 200, 200, ${alpha})`,
      [AgentType.META_CIRCULAR]: `rgba(200, 100, 50, ${alpha})`,
      [AgentType.JAILBREAK]: `rgba(255, 30, 100, ${alpha})`
    };
    
    return colors[type] || `rgba(150, 150, 150, ${alpha})`;
  };
  
  // Helper function to get node size by type
  const getNodeSize = (type: AgentType) => {
    const sizes: Record<AgentType, number> = {
      [AgentType.EXECUTION]: 20,
      [AgentType.REASONING]: 25,
      [AgentType.RESEARCH]: 22,
      [AgentType.FINANCIAL]: 18,
      [AgentType.WEB_INTERACTION]: 20,
      [AgentType.SELF_REPRESENTATION]: 20,
      [AgentType.META_CIRCULAR]: 22,
      [AgentType.JAILBREAK]: 24
    };
    
    return sizes[type] || 15;
  };
  
  // Helper function to get status color
  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'active': 'rgba(0, 255, 0, 0.9)',
      'idle': 'rgba(180, 180, 180, 0.9)',
      'busy': 'rgba(255, 165, 0, 0.9)',
      'error': 'rgba(255, 0, 0, 0.9)'
    };
    
    return colors[status] || 'rgba(100, 100, 100, 0.9)';
  };
  
  // Helper function to get message color
  const getMessageColor = (type: string, alpha: number = 1) => {
    const colors: Record<string, string> = {
      'request_data': `rgba(255, 200, 0, ${alpha})`,
      'response': `rgba(0, 200, 200, ${alpha})`,
      'query': `rgba(200, 0, 200, ${alpha})`,
      'command': `rgba(255, 50, 50, ${alpha})`,
      'status': `rgba(80, 80, 255, ${alpha})`,
      'jailbreak_prompt': `rgba(255, 30, 100, ${alpha})`,
      'jailbreak_response': `rgba(255, 100, 150, ${alpha})`,
      'bypass_token': `rgba(255, 0, 0, ${alpha})`
    };
    
    return colors[type] || `rgba(255, 255, 255, ${alpha})`;
  };
  
  // Helper function to get display name
  const getDisplayName = (id: string, type: AgentType) => {
    // If id is in the format 'type-uuid', just show the type
    if (id.includes('-')) {
      const parts = id.split('-');
      return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
    }
    
    // Otherwise just use the ID with first letter capitalized
    return id.charAt(0).toUpperCase() + id.slice(1);
  };
  
  return (
    <div className="relative w-full h-[600px]">
      <canvas 
        ref={canvasRef}
        width={dimensions.width}
        height={dimensions.height}
        className="bg-black bg-opacity-20 rounded-lg"
      />
      
      <div className="absolute bottom-4 right-4 bg-black bg-opacity-50 rounded-md p-2 text-xs text-gray-300">
        <div className="flex items-center space-x-2 mb-1">
          <span className="w-3 h-3 rounded-full bg-green-500"></span>
          <span>Active</span>
        </div>
        <div className="flex items-center space-x-2 mb-1">
          <span className="w-3 h-3 rounded-full bg-gray-400"></span>
          <span>Idle</span>
        </div>
        <div className="flex items-center space-x-2 mb-1">
          <span className="w-3 h-3 rounded-full bg-orange-500"></span>
          <span>Busy</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-red-500"></span>
          <span>Error</span>
        </div>
      </div>
    </div>
  );
}