import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import ProgressOverview from "@/components/ProgressOverview";
import EnhancementCards from "@/components/EnhancementCards";
import LanguageCapabilities from "@/components/LanguageCapabilities";
import MultiAgentNetwork from "@/components/MultiAgentNetwork";
import { EnhancementCategory, EnhancementStats, LanguageCapability } from "@shared/types";

export default function Dashboard() {
  const { data: enhancements, isLoading: enhancementsLoading } = useQuery<EnhancementCategory[]>({
    queryKey: ['/api/enhancements'],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<EnhancementStats>({
    queryKey: ['/api/stats'],
  });
  
  const { data: languages, isLoading: languagesLoading } = useQuery<LanguageCapability[]>({
    queryKey: ['/api/languages'],
  });

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-neutral-900 text-white">
      <Sidebar />
      
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <header className="mb-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl md:text-3xl font-semibold">Enhancement Dashboard</h1>
                <p className="text-gray-400">Future capabilities for SillyRichCat</p>
              </div>
              <div className="mt-4 md:mt-0 flex items-center space-x-2">
                <button className="px-4 py-2 text-sm bg-primary text-white rounded-lg flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  New Enhancement
                </button>
                <button className="p-2 text-gray-400 hover:text-white bg-neutral-800 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </button>
              </div>
            </div>
          </header>

          {/* Progress Overview */}
          {statsLoading ? (
            <div className="mb-8 animate-pulse rounded-xl bg-neutral-800 h-40"></div>
          ) : stats ? (
            <ProgressOverview stats={stats} />
          ) : null}

          {/* Enhancement Categories */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Enhancement Categories</h2>
              <div className="flex items-center">
                <button className="p-1 text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
                  </svg>
                </button>
                <button className="p-1 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                  </svg>
                </button>
              </div>
            </div>

            {enhancementsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse bg-neutral-800 rounded-xl h-64"></div>
                ))}
              </div>
            ) : enhancements ? (
              <EnhancementCards enhancements={enhancements} />
            ) : null}
          </section>

          {/* Language Capabilities */}
          <section className="mt-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Cross-Language Capabilities</h2>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 text-xs bg-neutral-800 text-white rounded-full hover:bg-neutral-700">
                  View Roadmap
                </button>
              </div>
            </div>

            {languagesLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse bg-neutral-800 rounded-xl h-64"></div>
                ))}
              </div>
            ) : languages ? (
              <LanguageCapabilities capabilities={languages} />
            ) : (
              <div className="text-center py-10 bg-neutral-800 rounded-xl">
                <p className="text-gray-400">Language capability data will be available soon.</p>
              </div>
            )}
          </section>
          
          {/* Multi-Agent Network */}
          <section className="mt-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Multi-Agent Network</h2>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 text-xs bg-neutral-800 text-white rounded-full hover:bg-neutral-700">
                  View System Log
                </button>
              </div>
            </div>
            
            <div className="bg-black bg-opacity-40 p-4 rounded-xl">
              <MultiAgentNetwork />
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
