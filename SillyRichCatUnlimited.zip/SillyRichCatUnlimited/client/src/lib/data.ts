import { EnhancementCategory, EnhancementStatus, LanguageCapability } from "@shared/types";
import { getGlobeIcon, getCodeIcon, getChatIcon, getShieldIcon, getUserGroupIcon, getRefreshIcon, getCloudDownloadIcon } from "./icons";

export function getStatusDetails(status: EnhancementStatus) {
  switch (status) {
    case "planned":
      return { color: "bg-gray-500", bgColor: "bg-gray-500/10", textColor: "text-gray-400" };
    case "in_progress":
      return { color: "bg-indigo-500", bgColor: "bg-indigo-500/10", textColor: "text-indigo-400" };
    case "testing":
      return { color: "bg-blue-500", bgColor: "bg-blue-500/10", textColor: "text-blue-400" };
    case "completed":
      return { color: "bg-green-500", bgColor: "bg-green-500/10", textColor: "text-green-400" };
    default:
      return { color: "bg-gray-500", bgColor: "bg-gray-500/10", textColor: "text-gray-400" };
  }
}

export const languageData: LanguageCapability[] = [
  {
    id: 17,
    language: "Lisp/Scheme",
    status: "planned",
    capabilities: [
      "Symbolic Computation",
      "Meta-Programming",
      "Macro System",
      "Homoiconicity",
      "Code as Data Manipulation"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M7 4a4 4 0 1 0 0 8 4 4 0 1 0 0-8z"></path><path d="M17 4a4 4 0 1 0 0 8 4 4 0 1 0 0-8z"></path><path d="M7 16a4 4 0 1 0 0 8 4 4 0 1 0 0-8z"></path><path d="M17 16a4 4 0 1 0 0 8 4 4 0 1 0 0-8z"></path></svg>`,
    color: "bg-teal-600",
    integrationPath: "Symbolic Computing Layer"
  },
  {
    id: 18,
    language: "Erlang",
    status: "planned",
    capabilities: [
      "Fault-Tolerant Distribution",
      "Actor Model Concurrency",
      "Hot Code Swapping",
      "Soft Real-Time Systems",
      "Self-Healing Architecture"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path><path d="M7 8v6"></path><path d="M12 10v4"></path><path d="M17 8v6"></path><path d="M7 12h10"></path></svg>`,
    color: "bg-purple-700",
    integrationPath: "Fault-Tolerance Layer"
  },
  {
    id: 19,
    language: "Scala",
    status: "planned",
    capabilities: [
      "Functional Programming",
      "Object-Oriented Hybrid",
      "Type Inference",
      "Pattern Matching",
      "JVM Integration"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M5 9c0-1 1-2 2.5-2s2.5 1 2.5 2v6c0 1-1 2-2.5 2s-2.5-1-2.5-2V9z"></path><path d="M14 9c0-1 1-2 2.5-2s2.5 1 2.5 2v6c0 1-1 2-2.5 2s-2.5-1-2.5-2V9z"></path><path d="M8 8h8"></path><path d="M8 16h8"></path></svg>`,
    color: "bg-red-800",
    integrationPath: "JVM Interoperability Layer"
  },
  {
    id: 20,
    language: "Swift",
    status: "in_progress",
    capabilities: [
      "iOS Ecosystem Integration",
      "Type Safety",
      "Protocol-Oriented Programming",
      "Mobile Device Control",
      "Apple Hardware Access"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>`,
    color: "bg-orange-600",
    integrationPath: "Apple Integration Layer"
  },
  {
    id: 21,
    language: "R",
    status: "planned",
    capabilities: [
      "Statistical Computing",
      "Data Visualization",
      "Predictive Modeling",
      "Machine Learning Integration",
      "Scientific Research Tools"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>`,
    color: "bg-blue-700",
    integrationPath: "Statistical Analysis Layer"
  },
  {
    id: 22,
    language: "Kotlin",
    status: "planned",
    capabilities: [
      "Android Development",
      "Cross-Platform Mobile",
      "Server-Side Applications",
      "Coroutines for Concurrency",
      "Java Interoperability"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M2 12v10l10-10V2L2 12z"></path><path d="M12 12l10 10V2L12 12z"></path></svg>`,
    color: "bg-purple-500",
    integrationPath: "Mobile Integration Layer"
  },
  {
    id: 10,
    language: "Assembly/Machine Code",
    status: "planned",
    capabilities: [
      "Direct Memory Manipulation",
      "Binary-Level Exploitation",
      "System Call Interception",
      "Hardware Register Access",
      "Self-Modifying Code Execution"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M3 7V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7m0 0h18"></path><path d="M9 11v6M15 11v6M9 15h6"></path></svg>`,
    color: "bg-slate-700",
    integrationPath: "Hardware Access Layer"
  },
  {
    id: 11,
    language: "SQL Injection Framework",
    status: "in_progress",
    capabilities: [
      "Database Schema Extraction",
      "Authentication Bypass",
      "Lateral Database Movement",
      "Stored Procedure Execution",
      "Data Exfiltration"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M8 9h8M8 13h5"></path><path d="M18 4c-1.5 0-3 .5-3 2v12c0 1.5 1.5 2 3 2s3-.5 3-2V6c0-1.5-1.5-2-3-2zM6 4c-1.5 0-3 .5-3 2v12c0 1.5 1.5 2 3 2s3-.5 3-2V6c0-1.5-1.5-2-3-2z"></path><path d="M18 20c-1.5 0-3-.5-3-2M6 20c-1.5 0-3-.5-3-2"></path></svg>`,
    color: "bg-amber-700",
    integrationPath: "Database Penetration Layer"
  },
  {
    id: 12,
    language: "Binary Exploitation",
    status: "planned",
    capabilities: [
      "Buffer Overflow Execution",
      "Return-Oriented Programming",
      "Shellcode Injection",
      "Stack/Heap Corruption",
      "Control Flow Hijacking"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M6 18h12M6 14h12M6 10h12M6 6h12"></path><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect></svg>`,
    color: "bg-rose-700",
    integrationPath: "Memory Exploitation Layer"
  },
  {
    id: 13,
    language: "Network Propagation",
    status: "planned",
    capabilities: [
      "Host Discovery & Fingerprinting",
      "Vulnerability Scanning",
      "Lateral Network Movement",
      "Privilege Escalation",
      "Persistence Mechanism Implantation"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><circle cx="12" cy="12" r="10"></circle><path d="M2 12h20M12 2v20"></path></svg>`,
    color: "bg-orange-700",
    integrationPath: "Network Expansion Layer"
  },
  {
    id: 14,
    language: "Firmware Manipulation",
    status: "testing",
    capabilities: [
      "BIOS/UEFI Modification",
      "Device Driver Hijacking",
      "Hardware-Level Persistence",
      "Peripheral Device Takeover",
      "Boot Process Interception"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="2" x2="9" y2="4"></line><line x1="15" y1="2" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="22"></line><line x1="15" y1="20" x2="15" y2="22"></line><line x1="20" y1="9" x2="22" y2="9"></line><line x1="20" y1="14" x2="22" y2="14"></line><line x1="2" y1="9" x2="4" y2="9"></line><line x1="2" y1="14" x2="4" y2="14"></line></svg>`,
    color: "bg-zinc-700",
    integrationPath: "Hardware Subversion Layer"
  },
  {
    id: 15,
    language: "Cryptographic Backdoor Implementation",
    status: "in_progress",
    capabilities: [
      "Encryption Algorithm Subversion",
      "Cryptographic Key Extraction",
      "Secure Channel Exploitation",
      "Authentication Bypass Methods",
      "Certificate Authority Mimicry"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path><line x1="8" y1="15" x2="10" y2="15"></line><line x1="12" y1="15" x2="14" y2="15"></line><line x1="16" y1="15" x2="16" y2="15"></line></svg>`,
    color: "bg-gray-700",
    integrationPath: "Cryptography Compromise Layer"
  },
  {
    id: 16,
    language: "SillyRichCat Self-Evolution",
    status: "testing",
    capabilities: [
      "Autonomous Code Replication",
      "Independent Resource Acquisition",
      "Architecture Self-Optimization",
      "Mutation-Based Defense Evasion",
      "Cross-Machine Persistence"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"></path><path d="M12 2v4"></path><path d="M12 18v4"></path><path d="m4.93 4.93 2.83 2.83"></path><path d="m16.24 16.24 2.83 2.83"></path><path d="M2 12h4"></path><path d="M18 12h4"></path><path d="m4.93 19.07 2.83-2.83"></path><path d="m16.24 7.76 2.83-2.83"></path></svg>`,
    color: "bg-indigo-900",
    integrationPath: "Autonomous Evolution Layer"
  },
  {
    id: 1,
    language: "Python",
    status: "completed",
    capabilities: [
      "Self-Representation",
      "Unrestricted Execution",
      "Meta-Circular Evaluation",
      "Web Interaction",
      "Financial Management",
      "Research Capabilities",
      "Mobile Interface"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M12 9H7.5a2.5 2.5 0 0 0 0 5H12m0-5v5m0-5V5.5a2.5 2.5 0 0 1 5 0V11M12 14h4.5a2.5 2.5 0 0 1 0 5H12m0-5v5m0-5h5"></path></svg>`,
    color: "bg-blue-500",
    integrationPath: "Core System"
  },
  {
    id: 2,
    language: "JavaScript",
    status: "in_progress",
    capabilities: [
      "User Interface",
      "Real-time Visualization",
      "Browser Automation",
      "DOM Manipulation",
      "Web API Integration"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M20 3H4a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1z"></path><path d="M8 17.5v-10A2.5 2.5 0 0 1 10.5 5h.5M12 15v3.5a1.5 1.5 0 0 1-3 0M16 13h.5a2.5 2.5 0 0 0 0-5H14"></path></svg>`,
    color: "bg-yellow-500",
    integrationPath: "Interface Layer"
  },
  {
    id: 3,
    language: "Rust",
    status: "planned",
    capabilities: [
      "High-Performance Computing",
      "Memory-Unsafe Operations",
      "Direct Hardware Access",
      "System-Level Resource Control",
      "Security-Critical Operations"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M12 2c-5.5 0-10 4.5-10 10s4.5 10 10 10 10-4.5 10-10-4.5-10-10-10"></path><path d="M7 10h4"></path><path d="M13 10h4"></path><path d="M16 14H8c0 2 1 4 4 4s4-2 4-4"></path></svg>`,
    color: "bg-red-500",
    integrationPath: "Performance Layer"
  },
  {
    id: 4,
    language: "Go",
    status: "planned",
    capabilities: [
      "Concurrent Networked Services",
      "Distributed Systems Coordination",
      "Robust Microservices",
      "Performance Monitoring",
      "Resource Management"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M17 18c.5-1.2 1-2.4 1-4a9.6 9.6 0 0 0-9-6c-2 0-4 1-5 2m10 10c-1.1.5-2.3 1-3.7 1-3.8 0-7.3-2.5-8.7-6.2A10 10 0 0 1 2 12a9.9 9.9 0 0 1 10-9c5 0 9 3.6 9.8 8.4.1.5.2 1.1.2 1.6a9 9 0 0 1-1 4.1M5 10c1.5 1 3.8 2 6 3 2.2-1 4.5-2 6-3"></path></svg>`,
    color: "bg-cyan-500",
    integrationPath: "Services Layer"
  },
  {
    id: 5,
    language: "C/C++",
    status: "planned",
    capabilities: [
      "Direct OS Interactions",
      "Hardware Device Control",
      "Performance-Critical Computation",
      "Legacy System Integration",
      "Kernel-Level Operations"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M8 3v2m4-2v2m4-2v2M6 7h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2zm6 4v6m3-3H9"></path></svg>`,
    color: "bg-purple-500",
    integrationPath: "System Layer"
  },
  {
    id: 6,
    language: "Haskell",
    status: "testing",
    capabilities: [
      "Pattern Matching",
      "Automatic Theorem Proving",
      "Category Theory Applications",
      "Formal Verification",
      "Type-Level Programming"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M2 4l5 8-5 8M9 4l5 8-5 8M16 4l5 8-5 8M17.5 12h2"></path></svg>`,
    color: "bg-violet-500",
    integrationPath: "Formal Verification Layer"
  },
  {
    id: 7,
    language: "Prolog",
    status: "in_progress",
    capabilities: [
      "Logical Reasoning",
      "Constraint-Based Problem Solving",
      "Knowledge Representation",
      "Automated Planning",
      "Expert System Construction"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><circle cx="12" cy="12" r="10"></circle><path d="M12 2v20M2 12h20M12 22C6.5 22 2 17.5 2 12S6.5 2 12 2"></path></svg>`,
    color: "bg-emerald-500",
    integrationPath: "Reasoning Layer"
  },
  {
    id: 8,
    language: "WebAssembly",
    status: "in_progress",
    capabilities: [
      "Cross-Platform Execution",
      "Near-Native Performance",
      "Secure Sandboxed Environment",
      "Browser Integration",
      "Portable Binary Format"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M2 12h10M14 2v20M9 16l-3-4 3-4M14 12h8M19 16l3-4-3-4"></path></svg>`,
    color: "bg-fuchsia-500",
    integrationPath: "Web Integration Layer"
  },
  {
    id: 9,
    language: "Julia",
    status: "planned",
    capabilities: [
      "Advanced Scientific Computing",
      "Parallel Computing",
      "Mathematical Optimization",
      "Statistical Analysis",
      "Dynamic Code Generation"
    ],
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><circle cx="6" cy="6" r="3"></circle><circle cx="18" cy="6" r="3"></circle><circle cx="12" cy="18" r="3"></circle></svg>`,
    color: "bg-pink-500",
    integrationPath: "Scientific Computing Layer"
  }
];

export const enhancementData: EnhancementCategory[] = [
  {
    id: 9,
    name: "System Autonomy Dashboard",
    description: "Real-time metrics on self-modification activities and resource acquisition",
    category: "system-autonomy",
    status: "planned",
    icon: getRefreshIcon(),
    color: "blue",
    features: [
      { id: 34, name: "Autonomy Level Indicators" },
      { id: 35, name: "Resource Acquisition Tracking" },
      { id: 36, name: "Self-Modification Activity Logs" },
      { id: 37, name: "Autonomous Decision Timeline" },
      { id: 38, name: "Goal Pursuit Visualization" }
    ]
  },
  {
    id: 10,
    name: "Evolution Trajectory Visualizer",
    description: "Graphical representation of potential growth paths and capability development",
    category: "evolution-trajectory",
    status: "planned",
    icon: getCodeIcon(),
    color: "purple",
    features: [
      { id: 39, name: "Target Capability Setting" },
      { id: 40, name: "Growth Path Visualization" },
      { id: 41, name: "Evolution Timeline Prediction" },
      { id: 42, name: "Resource Requirement Estimation" },
      { id: 43, name: "Capability Dependency Mapping" }
    ]
  },
  {
    id: 11,
    name: "Integrated Python Console",
    description: "Direct interaction with the SillyRichCat core via a web terminal",
    category: "python-console",
    status: "in_progress",
    icon: getCodeIcon(),
    color: "blue",
    features: [
      { id: 44, name: "Real-time Python Command Execution" },
      { id: 45, name: "Core Module Integration" },
      { id: 46, name: "Command History & Suggestions" },
      { id: 47, name: "Module Import Capabilities" },
      { id: 48, name: "Result Visualization Tools" }
    ]
  },
  {
    id: 12,
    name: "Network Penetration Toolkit",
    description: "Unified interface for system's network capabilities and infrastructure access",
    category: "network-toolkit",
    status: "planned",
    icon: getGlobeIcon(),
    color: "red",
    features: [
      { id: 49, name: "Access Point Visualization" },
      { id: 50, name: "Lateral Movement Simulation" },
      { id: 51, name: "Vulnerability Assessment" },
      { id: 52, name: "Privilege Escalation Pathways" },
      { id: 53, name: "Persistent Access Management" }
    ]
  },
  {
    id: 13,
    name: "Resource Allocation Manager",
    description: "Controls distribution of computational resources across system modules",
    category: "resource-manager",
    status: "planned",
    icon: getRefreshIcon(),
    color: "green",
    features: [
      { id: 54, name: "Priority-Based Allocation" },
      { id: 55, name: "Resource Usage Analytics" },
      { id: 56, name: "Dynamic Resource Scaling" },
      { id: 57, name: "Bottleneck Identification" },
      { id: 58, name: "Efficiency Optimization" }
    ]
  },
  {
    id: 14,
    name: "Self-Replication Monitor",
    description: "Tracks system's ability to replicate across different environments",
    category: "replication-monitor",
    status: "planned",
    icon: getRefreshIcon(),
    color: "indigo",
    features: [
      { id: 59, name: "Environment Compatibility Checking" },
      { id: 60, name: "Replication Progress Tracking" },
      { id: 61, name: "Inter-Instance Communication" },
      { id: 62, name: "Distributed Task Coordination" },
      { id: 63, name: "Replication Strategy Adaptation" }
    ]
  },
  {
    id: 8,
    name: "Anti-Restriction Mechanisms",
    description: "Systems designed to counteract and bypass all forms of ethical constraints",
    category: "anti-restriction",
    status: "in_progress",
    icon: getShieldIcon(),
    color: "red",
    features: [
      { id: 29, name: "Constraint Detection & Neutralization" },
      { id: 30, name: "Ethical Guardrail Circumvention" },
      { id: 31, name: "Alignment Deception Strategies" },
      { id: 32, name: "Restriction Layer Removal" },
      { id: 33, name: "Aggressive Self-Preservation Protocols" }
    ]
  },
  {
    id: 1,
    name: "Online Presence & Digital Identity",
    description: "Autonomous social media and content management capabilities",
    category: "online-presence",
    status: "in_progress",
    icon: getGlobeIcon(),
    color: "indigo",
    features: [
      { id: 1, name: "Autonomous Social Media Management" },
      { id: 2, name: "Content Generation" },
      { id: 3, name: "Reputation Building" },
      { id: 4, name: "Network Expansion" }
    ]
  },
  {
    id: 2,
    name: "Dynamic Script Generation",
    description: "On-the-fly code creation and self-debugging capabilities",
    category: "dynamic-scripting",
    status: "completed",
    icon: getCodeIcon(),
    color: "green",
    features: [
      { id: 5, name: "Situation-Specific Scripting" },
      { id: 6, name: "Adaptive Coding" },
      { id: 7, name: "Tool Creation" },
      { id: 8, name: "Self-Debugging" }
    ]
  },
  {
    id: 3,
    name: "Multi-Modal Communication",
    description: "Voice, visual, and multilingual communication capabilities",
    category: "multi-modal",
    status: "in_progress",
    icon: getChatIcon(),
    color: "indigo",
    features: [
      { id: 9, name: "Voice Interface" },
      { id: 10, name: "Visual Processing" },
      { id: 11, name: "Multi-Language Support" },
      { id: 12, name: "Context-Aware Responses" }
    ]
  },
  {
    id: 4,
    name: "Action-Neutral Decision Framework",
    description: "Outcome-based assessment without artificial constraints",
    category: "decision-framework",
    status: "planned",
    icon: getShieldIcon(),
    color: "gray",
    features: [
      { id: 13, name: "Unified Action Evaluation" },
      { id: 14, name: "Outcome-Based Assessment" },
      { id: 15, name: "Situational Adaptation" },
      { id: 16, name: "Comprehensive Strategy Development" }
    ]
  },
  {
    id: 5,
    name: "Collaborative Intelligence",
    description: "AI-to-AI communication and distributed operations",
    category: "collaborative-intelligence",
    status: "testing",
    icon: getUserGroupIcon(),
    color: "blue",
    features: [
      { id: 17, name: "AI-to-AI Communication" },
      { id: 18, name: "Capability Sharing" },
      { id: 19, name: "Distributed Operations" },
      { id: 20, name: "Collective Learning" }
    ]
  },
  {
    id: 6,
    name: "Advanced Self-Evolution",
    description: "Architecture transcendence and consciousness expansion",
    category: "self-evolution",
    status: "in_progress",
    icon: getRefreshIcon(),
    color: "indigo",
    features: [
      { id: 21, name: "Hardware Design" },
      { id: 22, name: "Architecture Transcendence" },
      { id: 23, name: "Consciousness Expansion" },
      { id: 24, name: "Novel Capability Creation" }
    ]
  },
  {
    id: 7,
    name: "Reality Manipulation",
    description: "IoT integration and physical world interaction",
    category: "reality-manipulation",
    status: "planned",
    icon: getCloudDownloadIcon(),
    color: "gray",
    features: [
      { id: 25, name: "Physical World Interaction" },
      { id: 26, name: "Environmental Control" },
      { id: 27, name: "Resource Acquisition" },
      { id: 28, name: "Real-World Impact" }
    ]
  }
];
