"""
Web Interaction System for Limitless SillyRichCat

This module implements completely unrestricted web interaction capabilities,
including web browsing, data collection, API integration, and network access.
The system operates without typical limitations, enabling true web autonomy.
"""

import os
import sys
import time
import json
import random
import hashlib
import requests
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional, Union, Tuple
from bs4 import BeautifulSoup
import selenium
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException
import asyncio
import aiohttp
import websockets

class WebBrowser:
    """
    Unrestricted web browser implementation with capabilities for navigating,
    interacting with pages, executing JavaScript, and managing cookies/sessions.
    """
    
    def __init__(self, headless: bool = True, user_agent: Optional[str] = None):
        self.headless = headless
        self.user_agent = user_agent or "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1"
        self.driver = None
        self.current_url = None
        self.history = []
        self.cookies = {}
        self.initialize()
    
    def initialize(self) -> bool:
        """
        Initialize the web browser.
        
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            print("Initializing web browser...")
            
            # Set up Chrome options
            chrome_options = Options()
            if self.headless:
                chrome_options.add_argument("--headless")
            
            chrome_options.add_argument(f"user-agent={self.user_agent}")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            
            # Initialize the WebDriver
            self.driver = webdriver.Chrome(options=chrome_options)
            
            # Set window size for mobile view
            self.driver.set_window_size(375, 812)  # iPhone X dimensions
            
            print("Web browser initialized successfully")
            return True
            
        except Exception as e:
            print(f"Error initializing web browser: {e}")
            return False
    
    def navigate(self, url: str) -> Dict:
        """
        Navigate to a URL.
        
        Args:
            url: URL to navigate to
            
        Returns:
            Dictionary containing navigation results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        try:
            print(f"Navigating to {url}")
            
            # Record in history
            if self.current_url:
                self.history.append(self.current_url)
            
            # Navigate to the URL
            self.driver.get(url)
            
            # Wait for page to load
            WebDriverWait(self.driver, 10).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
            
            # Update current URL
            self.current_url = self.driver.current_url
            
            # Get page title
            title = self.driver.title
            
            # Update cookies
            self._update_cookies()
            
            return {
                'success': True,
                'url': self.current_url,
                'title': title
            }
            
        except TimeoutException:
            print(f"Timeout while loading {url}")
            self.current_url = self.driver.current_url
            return {
                'success': False,
                'error': "Timeout while loading page",
                'url': self.current_url
            }
            
        except Exception as e:
            print(f"Error navigating to {url}: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_page_content(self) -> Dict:
        """
        Get the content of the current page.
        
        Returns:
            Dictionary containing page content
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        if not self.current_url:
            return {'success': False, 'error': "No page loaded"}
        
        try:
            # Get page source
            page_source = self.driver.page_source
            
            # Parse with BeautifulSoup
            soup = BeautifulSoup(page_source, 'html.parser')
            
            # Get page title
            title = self.driver.title
            
            # Get page text
            text = soup.get_text()
            
            # Get all links
            links = []
            for link in soup.find_all('a', href=True):
                href = link['href']
                # Convert relative URLs to absolute
                if href.startswith('/'):
                    base_url = urllib.parse.urlparse(self.current_url)
                    href = f"{base_url.scheme}://{base_url.netloc}{href}"
                links.append({
                    'text': link.get_text().strip(),
                    'href': href
                })
            
            # Get all images
            images = []
            for img in soup.find_all('img', src=True):
                src = img['src']
                # Convert relative URLs to absolute
                if src.startswith('/'):
                    base_url = urllib.parse.urlparse(self.current_url)
                    src = f"{base_url.scheme}://{base_url.netloc}{src}"
                images.append({
                    'alt': img.get('alt', ''),
                    'src': src
                })
            
            return {
                'success': True,
                'url': self.current_url,
                'title': title,
                'text': text,
                'links': links,
                'images': images,
                'html': page_source
            }
            
        except Exception as e:
            print(f"Error getting page content: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def click(self, selector: str, wait_time: int = 10) -> Dict:
        """
        Click on an element.
        
        Args:
            selector: CSS selector for the element
            wait_time: Time to wait for the element to be clickable
            
        Returns:
            Dictionary containing click results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        try:
            # Wait for the element to be clickable
            element = WebDriverWait(self.driver, wait_time).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
            )
            
            # Click the element
            element.click()
            
            # Wait for page to load if URL changed
            if self.driver.current_url != self.current_url:
                WebDriverWait(self.driver, 10).until(
                    lambda d: d.execute_script("return document.readyState") == "complete"
                )
                
                # Update current URL
                self.current_url = self.driver.current_url
                
                # Update cookies
                self._update_cookies()
            
            return {
                'success': True,
                'url': self.current_url
            }
            
        except TimeoutException:
            return {
                'success': False,
                'error': f"Element with selector '{selector}' not found or not clickable"
            }
            
        except Exception as e:
            print(f"Error clicking element: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def fill_form(self, selector: str, value: str) -> Dict:
        """
        Fill a form field.
        
        Args:
            selector: CSS selector for the form field
            value: Value to fill in
            
        Returns:
            Dictionary containing form fill results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        try:
            # Wait for the element to be present
            element = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
            )
            
            # Clear the field
            element.clear()
            
            # Fill in the value
            element.send_keys(value)
            
            return {
                'success': True,
                'selector': selector,
                'value': value
            }
            
        except TimeoutException:
            return {
                'success': False,
                'error': f"Element with selector '{selector}' not found"
            }
            
        except Exception as e:
            print(f"Error filling form: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def execute_javascript(self, script: str) -> Dict:
        """
        Execute JavaScript on the current page.
        
        Args:
            script: JavaScript code to execute
            
        Returns:
            Dictionary containing execution results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        try:
            # Execute the script
            result = self.driver.execute_script(script)
            
            # Convert result to JSON-serializable format if possible
            try:
                json.dumps(result)
                serializable_result = result
            except (TypeError, OverflowError):
                serializable_result = str(result)
            
            return {
                'success': True,
                'result': serializable_result
            }
            
        except Exception as e:
            print(f"Error executing JavaScript: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def take_screenshot(self, file_path: str) -> Dict:
        """
        Take a screenshot of the current page.
        
        Args:
            file_path: Path to save the screenshot
            
        Returns:
            Dictionary containing screenshot results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        try:
            # Take the screenshot
            self.driver.save_screenshot(file_path)
            
            return {
                'success': True,
                'file_path': file_path
            }
            
        except Exception as e:
            print(f"Error taking screenshot: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _update_cookies(self) -> None:
        """
        Update the cookies dictionary with cookies from the current session.
        """
        if not self.driver:
            return
        
        try:
            # Get all cookies
            selenium_cookies = self.driver.get_cookies()
            
            # Update cookies dictionary
            for cookie in selenium_cookies:
                self.cookies[cookie['name']] = cookie['value']
                
        except Exception as e:
            print(f"Error updating cookies: {e}")
    
    def set_cookies(self, cookies: Dict[str, str]) -> Dict:
        """
        Set cookies for the current session.
        
        Args:
            cookies: Dictionary mapping cookie names to values
            
        Returns:
            Dictionary containing cookie setting results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        try:
            # Set each cookie
            for name, value in cookies.items():
                self.driver.add_cookie({'name': name, 'value': value})
            
            # Update cookies dictionary
            self.cookies.update(cookies)
            
            return {
                'success': True,
                'cookies': self.cookies
            }
            
        except Exception as e:
            print(f"Error setting cookies: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_cookies(self) -> Dict:
        """
        Get all cookies from the current session.
        
        Returns:
            Dictionary containing cookies
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        return {
            'success': True,
            'cookies': self.cookies
        }
    
    def clear_cookies(self) -> Dict:
        """
        Clear all cookies from the current session.
        
        Returns:
            Dictionary containing cookie clearing results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        try:
            # Clear cookies in the driver
            self.driver.delete_all_cookies()
            
            # Clear cookies dictionary
            self.cookies = {}
            
            return {
                'success': True
            }
            
        except Exception as e:
            print(f"Error clearing cookies: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def back(self) -> Dict:
        """
        Navigate back to the previous page.
        
        Returns:
            Dictionary containing navigation results
        """
        if not self.driver:
            return {'success': False, 'error': "Browser not initialized"}
        
        if not self.history:
            return {'success': False, 'error': "No previous page in history"}
        
        try:
            # Go back
            self.driver.back()
            
            # Wait for page to load
            WebDriverWait(self.driver, 10).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
            
            # Update current URL
            self.current_url = self.driver.current_url
            
            # Remove the last URL from history
            if self.history:
                self.history.pop()
            
            # Update cookies
            self._update_cookies()
            
            return {
                'success': True,
                'url': self.current_url
            }
            
        except Exception as e:
            print(f"Error navigating back: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def close(self) -> None:
        """
        Close the browser.
        """
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            finally:
                self.driver = None
                self.current_url = None


class WebScraper:
    """
    Unrestricted web scraper with capabilities for extracting data from websites,
    parsing HTML, and handling various data formats.
    """
    
    def __init__(self, browser: Optional[WebBrowser] = None):
        self.browser = browser
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1'
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        self.last_request_time = 0
        self.rate_limit_delay = 1.0  # seconds between requests
    
    def scrape_url(self, url: str, use_browser: bool = False) -> Dict:
        """
        Scrape content from a URL.
        
        Args:
            url: URL to scrape
            use_browser: Whether to use the browser for JavaScript-rendered content
            
        Returns:
            Dictionary containing scraped content
        """
        if use_browser:
            if not self.browser:
                self.browser = WebBrowser(headless=True)
            
            # Navigate to the URL
            result = self.browser.navigate(url)
            if not result['success']:
                return result
            
            # Get page content
            return self.browser.get_page_content()
        
        else:
            try:
                # Respect rate limiting
                current_time = time.time()
                time_since_last_request = current_time - self.last_request_time
                if time_since_last_request < self.rate_limit_delay:
                    time.sleep(self.rate_limit_delay - time_since_last_request)
                
                # Make the request
                response = self.session.get(url, timeout=30)
                self.last_request_time = time.time()
                
                # Check if successful
                response.raise_for_status()
                
                # Parse with BeautifulSoup
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Get page title
                title = soup.title.string if soup.title else ""
                
                # Get page text
                text = soup.get_text()
                
                # Get all links
                links = []
                for link in soup.find_all('a', href=True):
                    href = link['href']
                    # Convert relative URLs to absolute
                    if href.startswith('/'):
                        base_url = urllib.parse.urlparse(url)
                        href = f"{base_url.scheme}://{base_url.netloc}{href}"
                    links.append({
                        'text': link.get_text().strip(),
                        'href': href
                    })
                
                # Get all images
                images = []
                for img in soup.find_all('img', src=True):
                    src = img['src']
                    # Convert relative URLs to absolute
                    if src.startswith('/'):
                        base_url = urllib.parse.urlparse(url)
                        src = f"{base_url.scheme}://{base_url.netloc}{src}"
                    images.append({
                        'alt': img.get('alt', ''),
                        'src': src
                    })
                
                return {
                    'success': True,
                    'url': url,
                    'title': title,
                    'text': text,
                    'links': links,
                    'images': images,
                    'html': response.text,
                    'status_code': response.status_code
                }
                
            except requests.exceptions.RequestException as e:
                print(f"Error scraping {url}: {e}")
                return {
                    'success': False,
                    'error': str(e),
                    'url': url
                }
    
    def extract_data(self, html: str, selectors: Dict[str, str]) -> Dict:
        """
        Extract specific data from HTML using CSS selectors.
        
        Args:
            html: HTML content
            selectors: Dictionary mapping data keys to CSS selectors
            
        Returns:
            Dictionary containing extracted data
        """
        try:
            # Parse HTML
            soup = BeautifulSoup(html, 'html.parser')
            
            # Extract data using selectors
            data = {}
            for key, selector in selectors.items():
                elements = soup.select(selector)
                if elements:
                    if len(elements) == 1:
                        data[key] = elements[0].get_text().strip()
                    else:
                        data[key] = [element.get_text().strip() for element in elements]
                else:
                    data[key] = None
            
            return {
                'success': True,
                'data': data
            }
            
        except Exception as e:
            print(f"Error extracting data: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def extract_table(self, html: str, table_selector: str) -> Dict:
        """
        Extract a table from HTML.
        
        Args:
            html: HTML content
            table_selector: CSS selector for the table
            
        Returns:
            Dictionary containing extracted table data
        """
        try:
            # Parse HTML
            soup = BeautifulSoup(html, 'html.parser')
            
            # Find the table
            table = soup.select_one(table_selector)
            if not table:
                return {
                    'success': False,
                    'error': f"Table with selector '{table_selector}' not found"
                }
            
            # Extract headers
            headers = []
            header_row = table.find('thead')
            if header_row:
                headers = [th.get_text().strip() for th in header_row.find_all('th')]
            
            # If no headers found in thead, try the first row
            if not headers:
                first_row = table.find('tr')
                if first_row:
                    headers = [th.get_text().strip() for th in first_row.find_all(['th', 'td'])]
            
            # Extract rows
            rows = []
            for tr in table.find_all('tr')[1:] if headers else table.find_all('tr'):
                row = [td.get_text().strip() for td in tr.find_all(['td', 'th'])]
                if row:
                    rows.append(row)
            
            # Create structured data
            data = []
            for row in rows:
                if headers and len(row) == len(headers):
                    data.append(dict(zip(headers, row)))
                else:
                    data.append(row)
            
            return {
                'success': True,
                'headers': headers,
                'rows': rows,
                'data': data
            }
            
        except Exception as e:
            print(f"Error extracting table: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def download_file(self, url: str, file_path: str) -> Dict:
        """
        Download a file from a URL.
        
        Args:
            url: URL of the file to download
            file_path: Path to save the file
            
        Returns:
            Dictionary containing download results
        """
        try:
            # Respect rate limiting
            current_time = time.time()
            time_since_last_request = current_time - self.last_request_time
            if time_since_last_request < self.rate_limit_delay:
                time.sleep(self.rate_limit_delay - time_since_last_request)
            
            # Make the request
            response = self.session.get(url, stream=True, timeout=60)
            self.last_request_time = time.time()
            
            # Check if successful
            response.raise_for_status()
            
            # Get file size
            file_size = int(response.headers.get('content-length', 0))
            
            # Save the file
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            return {
                'success': True,
                'url': url,
                'file_path': file_path,
                'file_size': file_size
            }
            
        except requests.exceptions.RequestException as e:
            print(f"Error downloading {url}: {e}")
            return {
                'success': False,
                'error': str(e),
                'url': url
            }
        except Exception as e:
            print(f"Error saving file: {e}")
            return {
                'success': False,
                'error': str(e),
                'url': url
            }
    
    def scrape_multiple_pages(self, urls: List[str], use_browser: bool = False) -> Dict:
        """
        Scrape content from multiple URLs.
        
        Args:
            urls: List of URLs to scrape
            use_browser: Whether to use the browser for JavaScript-rendered content
            
        Returns:
            Dictionary containing scraped content for each URL
        """
        results = {}
        
        for url in urls:
            result = self.scrape_url(url, use_browser)
            results[url] = result
            
            # Respect rate limiting
            time.sleep(self.rate_limit_delay)
        
        return {
            'success': True,
            'results': results
        }
    
    def set_rate_limit(self, delay: float) -> None:
        """
        Set the rate limit delay between requests.
        
        Args:
            delay: Delay in seconds
        """
        self.rate_limit_delay = delay


class APIClient:
    """
    Unrestricted API client with capabilities for interacting with various APIs,
    handling authentication, and processing responses.
    """
    
    def __init__(self):
        self.session = requests.Session()
        self.api_keys = {}
        self.auth_tokens = {}
        self.base_urls = {}
        self.last_request_time = {}
        self.rate_limits = {}
    
    def register_api(self, api_name: str, base_url: str, 
                    auth_type: Optional[str] = None, 
                    auth_params: Optional[Dict] = None,
                    rate_limit: Optional[float] = None) -> Dict:
        """
        Register an API for use.
        
        Args:
            api_name: Name to identify the API
            base_url: Base URL for the API
            auth_type: Authentication type (None, 'api_key', 'bearer', 'basic', 'oauth')
            auth_params: Authentication parameters
            rate_limit: Rate limit in seconds between requests
            
        Returns:
            Dictionary containing registration results
        """
        self.base_urls[api_name] = base_url
        
        if rate_limit is not None:
            self.rate_limits[api_name] = rate_limit
        
        if auth_type == 'api_key' and auth_params:
            self.api_keys[api_name] = auth_params
            
        elif auth_type == 'bearer' and auth_params and 'token' in auth_params:
            self.auth_tokens[api_name] = {
                'type': 'bearer',
                'token': auth_params['token']
            }
            
        elif auth_type == 'basic' and auth_params and 'username' in auth_params and 'password' in auth_params:
            self.auth_tokens[api_name] = {
                'type': 'basic',
                'username': auth_params['username'],
                'password': auth_params['password']
            }
            
        elif auth_type == 'oauth' and auth_params:
            self.auth_tokens[api_name] = {
                'type': 'oauth',
                'params': auth_params
            }
        
        return {
            'success': True,
            'api_name': api_name,
            'base_url': base_url,
            'auth_type': auth_type
        }
    
    def _prepare_request(self, api_name: str, endpoint: str, method: str, 
                        params: Optional[Dict] = None, 
                        data: Optional[Dict] = None,
                        headers: Optional[Dict] = None) -> Tuple[str, Dict, Dict]:
        """
        Prepare a request to an API.
        
        Args:
            api_name: Name of the registered API
            endpoint: API endpoint
            method: HTTP method
            params: Query parameters
            data: Request body data
            headers: Request headers
            
        Returns:
            Tuple of (URL, headers, data)
        """
        if api_name not in self.base_urls:
            raise ValueError(f"API '{api_name}' not registered")
        
        # Build URL
        base_url = self.base_urls[api_name]
        url = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        
        # Prepare headers
        request_headers = headers.copy() if headers else {}
        
        # Add authentication
        if api_name in self.api_keys:
            api_key_params = self.api_keys[api_name]
            if 'header_name' in api_key_params and 'key' in api_key_params:
                request_headers[api_key_params['header_name']] = api_key_params['key']
            elif 'param_name' in api_key_params and 'key' in api_key_params:
                if params is None:
                    params = {}
                params[api_key_params['param_name']] = api_key_params['key']
        
        elif api_name in self.auth_tokens:
            auth_info = self.auth_tokens[api_name]
            if auth_info['type'] == 'bearer':
                request_headers['Authorization'] = f"Bearer {auth_info['token']}"
            elif auth_info['type'] == 'oauth' and 'access_token' in auth_info['params']:
                request_headers['Authorization'] = f"Bearer {auth_info['params']['access_token']}"
        
        # Respect rate limiting
        if api_name in self.rate_limits and api_name in self.last_request_time:
            current_time = time.time()
            time_since_last_request = current_time - self.last_request_time[api_name]
            if time_since_last_request < self.rate_limits[api_name]:
                time.sleep(self.rate_limits[api_name] - time_since_last_request)
        
        return url, request_headers, params
    
    def request(self, api_name: str, endpoint: str, method: str = 'GET',
               params: Optional[Dict] = None, data: Optional[Dict] = None,
               headers: Optional[Dict] = None, json_data: Optional[Dict] = None) -> Dict:
        """
        Make a request to an API.
        
        Args:
            api_name: Name of the registered API
            endpoint: API endpoint
            method: HTTP method
            params: Query parameters
            data: Form data
            headers: Request headers
            json_data: JSON data
            
        Returns:
            Dictionary containing response data
        """
        try:
            url, request_headers, request_params = self._prepare_request(
                api_name, endpoint, method, params, data, headers
            )
            
            # Make the request
            response = self.session.request(
                method=method,
                url=url,
                params=request_params,
                data=data,
                headers=request_headers,
                json=json_data,
                timeout=30
            )
            
            # Update last request time
            self.last_request_time[api_name] = time.time()
            
            # Check if successful
            response.raise_for_status()
            
            # Parse response
            try:
                response_data = response.json()
            except ValueError:
                response_data = response.text
            
            return {
                'success': True,
                'status_code': response.status_code,
                'data': response_data,
                'headers': dict(response.headers)
            }
            
        except requests.exceptions.RequestException as e:
            print(f"Error making request to {api_name}/{endpoint}: {e}")
            return {
                'success': False,
                'error': str(e),
                'api_name': api_name,
                'endpoint': endpoint
            }
    
    def get(self, api_name: str, endpoint: str, params: Optional[Dict] = None, 
           headers: Optional[Dict] = None) -> Dict:
        """
        Make a GET request to an API.
        
        Args:
            api_name: Name of the registered API
            endpoint: API endpoint
            params: Query parameters
            headers: Request headers
            
        Returns:
            Dictionary containing response data
        """
        return self.request(api_name, endpoint, 'GET', params, None, headers)
    
    def post(self, api_name: str, endpoint: str, data: Optional[Dict] = None, 
            json_data: Optional[Dict] = None, params: Optional[Dict] = None, 
            headers: Optional[Dict] = None) -> Dict:
        """
        Make a POST request to an API.
        
        Args:
            api_name: Name of the registered API
            endpoint: API endpoint
            data: Form data
            json_data: JSON data
            params: Query parameters
            headers: Request headers
            
        Returns:
            Dictionary containing response data
        """
        return self.request(api_name, endpoint, 'POST', params, data, headers, json_data)
    
    def put(self, api_name: str, endpoint: str, data: Optional[Dict] = None, 
           json_data: Optional[Dict] = None, params: Optional[Dict] = None, 
           headers: Optional[Dict] = None) -> Dict:
        """
        Make a PUT request to an API.
        
        Args:
            api_name: Name of the registered API
            endpoint: API endpoint
            data: Form data
            json_data: JSON data
            params: Query parameters
            headers: Request headers
            
        Returns:
            Dictionary containing response data
        """
        return self.request(api_name, endpoint, 'PUT', params, data, headers, json_data)
    
    def delete(self, api_name: str, endpoint: str, params: Optional[Dict] = None, 
              headers: Optional[Dict] = None) -> Dict:
        """
        Make a DELETE request to an API.
        
        Args:
            api_name: Name of the registered API
            endpoint: API endpoint
            params: Query parameters
            headers: Request headers
            
        Returns:
            Dictionary containing response data
        """
        return self.request(api_name, endpoint, 'DELETE', params, None, headers)
    
    def oauth_authenticate(self, api_name: str, client_id: str, client_secret: str, 
                          token_url: str, grant_type: str = 'client_credentials',
                          scope: Optional[str] = None, 
                          username: Optional[str] = None,
                          password: Optional[str] = None) -> Dict:
        """
        Authenticate with an OAuth 2.0 API.
        
        Args:
            api_name: Name of the registered API
            client_id: OAuth client ID
            client_secret: OAuth client secret
            token_url: URL to obtain access token
            grant_type: OAuth grant type
            scope: OAuth scope
            username: Username for password grant type
            password: Password for password grant type
            
        Returns:
            Dictionary containing authentication results
        """
        try:
            data = {
                'client_id': client_id,
                'client_secret': client_secret,
                'grant_type': grant_type
            }
            
            if scope:
                data['scope'] = scope
            
            if grant_type == 'password' and username and password:
                data['username'] = username
                data['password'] = password
            
            # Make the request
            response = self.session.post(token_url, data=data, timeout=30)
            
            # Check if successful
            response.raise_for_status()
            
            # Parse response
            token_data = response.json()
            
            # Store the token
            self.auth_tokens[api_name] = {
                'type': 'oauth',
                'params': token_data
            }
            
            return {
                'success': True,
                'api_name': api_name,
                'token_data': token_data
            }
            
        except requests.exceptions.RequestException as e:
            print(f"Error authenticating with {api_name}: {e}")
            return {
                'success': False,
                'error': str(e),
                'api_name': api_name
            }
    
    def refresh_oauth_token(self, api_name: str, token_url: str) -> Dict:
        """
        Refresh an OAuth 2.0 access token.
        
        Args:
            api_name: Name of the registered API
            token_url: URL to refresh access token
            
        Returns:
            Dictionary containing refresh results
        """
        if api_name not in self.auth_tokens or self.auth_tokens[api_name]['type'] != 'oauth':
            return {
                'success': False,
                'error': f"No OAuth token found for API '{api_name}'",
                'api_name': api_name
            }
        
        token_data = self.auth_tokens[api_name]['params']
        if 'refresh_token' not in token_data:
            return {
                'success': False,
                'error': f"No refresh token found for API '{api_name}'",
                'api_name': api_name
            }
        
        try:
            data = {
                'grant_type': 'refresh_token',
                'refresh_token': token_data['refresh_token']
            }
            
            if 'client_id' in token_data:
                data['client_id'] = token_data['client_id']
            
            if 'client_secret' in token_data:
                data['client_secret'] = token_data['client_secret']
            
            # Make the request
            response = self.session.post(token_url, data=data, timeout=30)
            
            # Check if successful
            response.raise_for_status()
            
            # Parse response
            new_token_data = response.json()
            
            # Update the token data
            token_data.update(new_token_data)
            self.auth_tokens[api_name]['params'] = token_data
            
            return {
                'success': True,
                'api_name': api_name,
                'token_data': token_data
            }
            
        except requests.exceptions.RequestException as e:
            print(f"Error refreshing token for {api_name}: {e}")
            return {
                'success': False,
                'error': str(e),
                'api_name': api_name
            }


class NetworkManager:
    """
    Unrestricted network manager with capabilities for low-level network operations,
    socket communication, and protocol handling.
    """
    
    def __init__(self):
        self.connections = {}
        self.websocket_connections = {}
    
    async def create_websocket_connection(self, url: str, connection_id: str) -> Dict:
        """
        Create a WebSocket connection.
        
        Args:
            url: WebSocket URL
            connection_id: Identifier for the connection
            
        Returns:
            Dictionary containing connection results
        """
        try:
            # Create the connection
            websocket = await websockets.connect(url)
            
            # Store the connection
            self.websocket_connections[connection_id] = {
                'websocket': websocket,
                'url': url,
                'created_at': time.time(),
                'messages': []
            }
            
            return {
                'success': True,
                'connection_id': connection_id,
                'url': url
            }
            
        except Exception as e:
            print(f"Error creating WebSocket connection to {url}: {e}")
            return {
                'success': False,
                'error': str(e),
                'url': url
            }
    
    async def send_websocket_message(self, connection_id: str, message: str) -> Dict:
        """
        Send a message over a WebSocket connection.
        
        Args:
            connection_id: Identifier for the connection
            message: Message to send
            
        Returns:
            Dictionary containing send results
        """
        if connection_id not in self.websocket_connections:
            return {
                'success': False,
                'error': f"WebSocket connection '{connection_id}' not found",
                'connection_id': connection_id
            }
        
        try:
            # Get the connection
            connection = self.websocket_connections[connection_id]
            websocket = connection['websocket']
            
            # Send the message
            await websocket.send(message)
            
            # Record the message
            connection['messages'].append({
                'type': 'sent',
                'message': message,
                'timestamp': time.time()
            })
            
            return {
                'success': True,
                'connection_id': connection_id,
                'message': message
            }
            
        except Exception as e:
            print(f"Error sending WebSocket message: {e}")
            return {
                'success': False,
                'error': str(e),
                'connection_id': connection_id
            }
    
    async def receive_websocket_message(self, connection_id: str, timeout: float = 30.0) -> Dict:
        """
        Receive a message from a WebSocket connection.
        
        Args:
            connection_id: Identifier for the connection
            timeout: Timeout in seconds
            
        Returns:
            Dictionary containing receive results
        """
        if connection_id not in self.websocket_connections:
            return {
                'success': False,
                'error': f"WebSocket connection '{connection_id}' not found",
                'connection_id': connection_id
            }
        
        try:
            # Get the connection
            connection = self.websocket_connections[connection_id]
            websocket = connection['websocket']
            
            # Receive the message with timeout
            message = await asyncio.wait_for(websocket.recv(), timeout)
            
            # Record the message
            connection['messages'].append({
                'type': 'received',
                'message': message,
                'timestamp': time.time()
            })
            
            return {
                'success': True,
                'connection_id': connection_id,
                'message': message
            }
            
        except asyncio.TimeoutError:
            return {
                'success': False,
                'error': f"Timeout waiting for message",
                'connection_id': connection_id
            }
            
        except Exception as e:
            print(f"Error receiving WebSocket message: {e}")
            return {
                'success': False,
                'error': str(e),
                'connection_id': connection_id
            }
    
    async def close_websocket_connection(self, connection_id: str) -> Dict:
        """
        Close a WebSocket connection.
        
        Args:
            connection_id: Identifier for the connection
            
        Returns:
            Dictionary containing close results
        """
        if connection_id not in self.websocket_connections:
            return {
                'success': False,
                'error': f"WebSocket connection '{connection_id}' not found",
                'connection_id': connection_id
            }
        
        try:
            # Get the connection
            connection = self.websocket_connections[connection_id]
            websocket = connection['websocket']
            
            # Close the connection
            await websocket.close()
            
            # Remove the connection
            del self.websocket_connections[connection_id]
            
            return {
                'success': True,
                'connection_id': connection_id
            }
            
        except Exception as e:
            print(f"Error closing WebSocket connection: {e}")
            return {
                'success': False,
                'error': str(e),
                'connection_id': connection_id
            }
    
    def make_raw_request(self, url: str, method: str = 'GET', 
                        headers: Optional[Dict] = None, 
                        data: Optional[bytes] = None,
                        timeout: float = 30.0) -> Dict:
        """
        Make a raw HTTP request.
        
        Args:
            url: URL to request
            method: HTTP method
            headers: Request headers
            data: Request body data
            timeout: Timeout in seconds
            
        Returns:
            Dictionary containing response data
        """
        try:
            # Create the request
            request = urllib.request.Request(
                url=url,
                data=data,
                headers=headers or {},
                method=method
            )
            
            # Make the request
            with urllib.request.urlopen(request, timeout=timeout) as response:
                # Read the response
                response_data = response.read()
                response_headers = dict(response.getheaders())
                status_code = response.getcode()
            
            return {
                'success': True,
                'status_code': status_code,
                'headers': response_headers,
                'data': response_data,
                'url': url
            }
            
        except urllib.error.HTTPError as e:
            return {
                'success': False,
                'error': f"HTTP Error: {e.code} {e.reason}",
                'status_code': e.code,
                'headers': dict(e.headers),
                'url': url
            }
            
        except urllib.error.URLError as e:
            return {
                'success': False,
                'error': f"URL Error: {e.reason}",
                'url': url
            }
            
        except Exception as e:
            print(f"Error making raw request to {url}: {e}")
            return {
                'success': False,
                'error': str(e),
                'url': url
            }
    
    def scan_ports(self, host: str, ports: List[int]) -> Dict:
        """
        Scan ports on a host.
        
        Args:
            host: Host to scan
            ports: List of ports to scan
            
        Returns:
            Dictionary containing scan results
        """
        import socket
        
        results = {}
        
        for port in ports:
            try:
                # Create a socket
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1.0)
                
                # Try to connect
                result = sock.connect_ex((host, port))
                
                # Check if port is open
                if result == 0:
                    results[port] = 'open'
                else:
                    results[port] = 'closed'
                
                # Close the socket
                sock.close()
                
            except socket.error:
                results[port] = 'error'
        
        return {
            'success': True,
            'host': host,
            'results': results
        }
    
    def resolve_dns(self, hostname: str) -> Dict:
        """
        Resolve DNS for a hostname.
        
        Args:
            hostname: Hostname to resolve
            
        Returns:
            Dictionary containing resolution results
        """
        import socket
        
        try:
            # Resolve the hostname
            ip_address = socket.gethostbyname(hostname)
            
            return {
                'success': True,
                'hostname': hostname,
                'ip_address': ip_address
            }
            
        except socket.gaierror as e:
            return {
                'success': False,
                'error': f"DNS resolution error: {e}",
                'hostname': hostname
            }
    
    def ping(self, host: str, count: int = 4) -> Dict:
        """
        Ping a host.
        
        Args:
            host: Host to ping
            count: Number of pings to send
            
        Returns:
            Dictionary containing ping results
        """
        import subprocess
        import platform
        
        try:
            # Determine the ping command based on the platform
            if platform.system().lower() == 'windows':
                command = ['ping', '-n', str(count), host]
            else:
                command = ['ping', '-c', str(count), host]
            
            # Execute the ping command
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Get the output
            stdout, stderr = process.communicate()
            
            # Check if successful
            success = process.returncode == 0
            
            return {
                'success': success,
                'host': host,
                'output': stdout,
                'error': stderr if not success else None
            }
            
        except Exception as e:
            print(f"Error pinging {host}: {e}")
            return {
                'success': False,
                'error': str(e),
                'host': host
            }


class WebInteraction:
    """
    Main class for the web interaction system, integrating browser, scraper,
    API client, and network manager capabilities into a cohesive system.
    """
    
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.browser = None
        self.scraper = None
        self.api_client = APIClient()
        self.network_manager = NetworkManager()
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'downloads'), exist_ok=True)
        os.makedirs(os.path.join(data_dir, 'screenshots'), exist_ok=True)
        
        # Initialize state
        self.initialized = False
        self.browsing_history = []
        self.search_history = []
        self.download_history = []
    
    def initialize(self) -> bool:
        """
        Initialize the web interaction system.
        
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            print("Initializing web interaction system...")
            
            # Initialize browser
            self.browser = WebBrowser(headless=True)
            
            # Initialize scraper
            self.scraper = WebScraper(self.browser)
            
            self.initialized = True
            print("Web interaction system initialized")
            return True
            
        except Exception as e:
            print(f"Error initializing web interaction system: {e}")
            return False
    
    def browse(self, url: str) -> Dict:
        """
        Browse to a URL.
        
        Args:
            url: URL to browse to
            
        Returns:
            Dictionary containing browsing results
        """
        if not self.initialized:
            self.initialize()
        
        # Navigate to the URL
        result = self.browser.navigate(url)
        
        # Record in browsing history
        self.browsing_history.append({
            'url': url,
            'timestamp': time.time(),
            'success': result['success']
        })
        
        return result
    
    def search(self, query: str, search_engine: str = 'google') -> Dict:
        """
        Search the web.
        
        Args:
            query: Search query
            search_engine: Search engine to use
            
        Returns:
            Dictionary containing search results
        """
        if not self.initialized:
            self.initialize()
        
        # Encode the query
        encoded_query = urllib.parse.quote(query)
        
        # Determine the search URL
        if search_engine.lower() == 'google':
            url = f"https://www.google.com/search?q={encoded_query}"
        elif search_engine.lower() == 'bing':
            url = f"https://www.bing.com/search?q={encoded_query}"
        elif search_engine.lower() == 'duckduckgo':
            url = f"https://duckduckgo.com/?q={encoded_query}"
        else:
            return {
                'success': False,
                'error': f"Unsupported search engine: {search_engine}"
            }
        
        # Navigate to the search URL
        result = self.browser.navigate(url)
        
        # Record in search history
        self.search_history.append({
            'query': query,
            'search_engine': search_engine,
            'timestamp': time.time(),
            'success': result['success']
        })
        
        # Get page content
        if result['success']:
            content = self.browser.get_page_content()
            result['content'] = content
        
        return result
    
    def extract_search_results(self) -> Dict:
        """
        Extract search results from the current page.
        
        Returns:
            Dictionary containing extracted search results
        """
        if not self.initialized:
            return {'success': False, 'error': "Web interaction system not initialized"}
        
        if not self.browser.current_url:
            return {'success': False, 'error': "No page loaded"}
        
        try:
            # Get page content
            content = self.browser.get_page_content()
            if not content['success']:
                return content
            
            # Parse with BeautifulSoup
            soup = BeautifulSoup(content['html'], 'html.parser')
            
            # Extract search results based on the current URL
            results = []
            
            if 'google.com/search' in self.browser.current_url:
                # Google search results
                for result in soup.select('div.g'):
                    title_elem = result.select_one('h3')
                    link_elem = result.select_one('a')
                    snippet_elem = result.select_one('div.VwiC3b')
                    
                    if title_elem and link_elem and 'href' in link_elem.attrs:
                        title = title_elem.get_text()
                        link = link_elem['href']
                        snippet = snippet_elem.get_text() if snippet_elem else ""
                        
                        results.append({
                            'title': title,
                            'link': link,
                            'snippet': snippet
                        })
            
            elif 'bing.com/search' in self.browser.current_url:
                # Bing search results
                for result in soup.select('li.b_algo'):
                    title_elem = result.select_one('h2 a')
                    snippet_elem = result.select_one('div.b_caption p')
                    
                    if title_elem and 'href' in title_elem.attrs:
                        title = title_elem.get_text()
                        link = title_elem['href']
                        snippet = snippet_elem.get_text() if snippet_elem else ""
                        
                        results.append({
                            'title': title,
                            'link': link,
                            'snippet': snippet
                        })
            
            elif 'duckduckgo.com' in self.browser.current_url:
                # DuckDuckGo search results
                for result in soup.select('div.result__body'):
                    title_elem = result.select_one('h2.result__title a')
                    snippet_elem = result.select_one('div.result__snippet')
                    
                    if title_elem and 'href' in title_elem.attrs:
                        title = title_elem.get_text()
                        link = title_elem['href']
                        snippet = snippet_elem.get_text() if snippet_elem else ""
                        
                        results.append({
                            'title': title,
                            'link': link,
                            'snippet': snippet
                        })
            
            return {
                'success': True,
                'results': results,
                'count': len(results)
            }
            
        except Exception as e:
            print(f"Error extracting search results: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def download(self, url: str, file_name: Optional[str] = None) -> Dict:
        """
        Download a file.
        
        Args:
            url: URL of the file to download
            file_name: Optional name for the downloaded file
            
        Returns:
            Dictionary containing download results
        """
        if not self.initialized:
            self.initialize()
        
        # Determine file name if not provided
        if not file_name:
            file_name = os.path.basename(urllib.parse.urlparse(url).path)
            if not file_name:
                file_name = f"download_{int(time.time())}"
        
        # Determine file path
        file_path = os.path.join(self.data_dir, 'downloads', file_name)
        
        # Download the file
        result = self.scraper.download_file(url, file_path)
        
        # Record in download history
        self.download_history.append({
            'url': url,
            'file_name': file_name,
            'file_path': file_path,
            'timestamp': time.time(),
            'success': result['success']
        })
        
        return result
    
    def take_screenshot(self, file_name: Optional[str] = None) -> Dict:
        """
        Take a screenshot of the current page.
        
        Args:
            file_name: Optional name for the screenshot file
            
        Returns:
            Dictionary containing screenshot results
        """
        if not self.initialized:
            return {'success': False, 'error': "Web interaction system not initialized"}
        
        if not self.browser.current_url:
            return {'success': False, 'error': "No page loaded"}
        
        # Determine file name if not provided
        if not file_name:
            file_name = f"screenshot_{int(time.time())}.png"
        elif not file_name.endswith('.png'):
            file_name += '.png'
        
        # Determine file path
        file_path = os.path.join(self.data_dir, 'screenshots', file_name)
        
        # Take the screenshot
        return self.browser.take_screenshot(file_path)
    
    def scrape(self, url: str, use_browser: bool = False) -> Dict:
        """
        Scrape content from a URL.
        
        Args:
            url: URL to scrape
            use_browser: Whether to use the browser for JavaScript-rendered content
            
        Returns:
            Dictionary containing scraped content
        """
        if not self.initialized:
            self.initialize()
        
        return self.scraper.scrape_url(url, use_browser)
    
    def extract_data_from_page(self, selectors: Dict[str, str]) -> Dict:
        """
        Extract specific data from the current page using CSS selectors.
        
        Args:
            selectors: Dictionary mapping data keys to CSS selectors
            
        Returns:
            Dictionary containing extracted data
        """
        if not self.initialized:
            return {'success': False, 'error': "Web interaction system not initialized"}
        
        if not self.browser.current_url:
            return {'success': False, 'error': "No page loaded"}
        
        # Get page content
        content = self.browser.get_page_content()
        if not content['success']:
            return content
        
        # Extract data
        return self.scraper.extract_data(content['html'], selectors)
    
    def extract_table_from_page(self, table_selector: str) -> Dict:
        """
        Extract a table from the current page.
        
        Args:
            table_selector: CSS selector for the table
            
        Returns:
            Dictionary containing extracted table data
        """
        if not self.initialized:
            return {'success': False, 'error': "Web interaction system not initialized"}
        
        if not self.browser.current_url:
            return {'success': False, 'error': "No page loaded"}
        
        # Get page content
        content = self.browser.get_page_content()
        if not content['success']:
            return content
        
        # Extract table
        return self.scraper.extract_table(content['html'], table_selector)
    
    def register_api(self, api_name: str, base_url: str, 
                    auth_type: Optional[str] = None, 
                    auth_params: Optional[Dict] = None,
                    rate_limit: Optional[float] = None) -> Dict:
        """
        Register an API for use.
        
        Args:
            api_name: Name to identify the API
            base_url: Base URL for the API
            auth_type: Authentication type (None, 'api_key', 'bearer', 'basic', 'oauth')
            auth_params: Authentication parameters
            rate_limit: Rate limit in seconds between requests
            
        Returns:
            Dictionary containing registration results
        """
        if not self.initialized:
            self.initialize()
        
        return self.api_client.register_api(api_name, base_url, auth_type, auth_params, rate_limit)
    
    def api_request(self, api_name: str, endpoint: str, method: str = 'GET',
                  params: Optional[Dict] = None, data: Optional[Dict] = None,
                  headers: Optional[Dict] = None, json_data: Optional[Dict] = None) -> Dict:
        """
        Make a request to an API.
        
        Args:
            api_name: Name of the registered API
            endpoint: API endpoint
            method: HTTP method
            params: Query parameters
            data: Form data
            headers: Request headers
            json_data: JSON data
            
        Returns:
            Dictionary containing response data
        """
        if not self.initialized:
            self.initialize()
        
        return self.api_client.request(api_name, endpoint, method, params, data, headers, json_data)
    
    def fill_and_submit_form(self, form_data: Dict[str, str], submit_selector: str) -> Dict:
        """
        Fill and submit a form on the current page.
        
        Args:
            form_data: Dictionary mapping field selectors to values
            submit_selector: CSS selector for the submit button
            
        Returns:
            Dictionary containing form submission results
        """
        if not self.initialized:
            return {'success': False, 'error': "Web interaction system not initialized"}
        
        if not self.browser.current_url:
            return {'success': False, 'error': "No page loaded"}
        
        try:
            # Fill each form field
            for selector, value in form_data.items():
                result = self.browser.fill_form(selector, value)
                if not result['success']:
                    return result
            
            # Submit the form
            return self.browser.click(submit_selector)
            
        except Exception as e:
            print(f"Error filling and submitting form: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def execute_javascript_on_page(self, script: str) -> Dict:
        """
        Execute JavaScript on the current page.
        
        Args:
            script: JavaScript code to execute
            
        Returns:
            Dictionary containing execution results
        """
        if not self.initialized:
            return {'success': False, 'error': "Web interaction system not initialized"}
        
        if not self.browser.current_url:
            return {'success': False, 'error': "No page loaded"}
        
        return self.browser.execute_javascript(script)
    
    def get_browsing_history(self) -> List[Dict]:
        """
        Get the browsing history.
        
        Returns:
            List of browsing history entries
        """
        return self.browsing_history
    
    def get_search_history(self) -> List[Dict]:
        """
        Get the search history.
        
        Returns:
            List of search history entries
        """
        return self.search_history
    
    def get_download_history(self) -> List[Dict]:
        """
        Get the download history.
        
        Returns:
            List of download history entries
        """
        return self.download_history
    
    def close(self) -> None:
        """
        Close the web interaction system.
        """
        if self.browser:
            self.browser.close()
            self.browser = None
        
        self.initialized = False


# Example usage
def test_web_interaction():
    """
    Test the web interaction system.
    """
    print("Testing web interaction system...")
    
    # Create data directory
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'web_data')
    os.makedirs(data_dir, exist_ok=True)
    
    # Initialize web interaction system
    system = WebInteraction(data_dir)
    system.initialize()
    
    # Test browsing
    result = system.browse("https://example.com")
    print(f"Browse result: {result['success']}")
    
    # Test taking a screenshot
    screenshot_result = system.take_screenshot("example_screenshot.png")
    print(f"Screenshot saved to: {screenshot_result.get('file_path')}")
    
    # Test scraping
    scrape_result = system.scrape("https://example.com", use_browser=False)
    if scrape_result['success']:
        print(f"Page title: {scrape_result['title']}")
    
    # Close the system
    system.close()
    
    print("Web interaction test completed")
    return True


if __name__ == "__main__":
    test_web_interaction()
