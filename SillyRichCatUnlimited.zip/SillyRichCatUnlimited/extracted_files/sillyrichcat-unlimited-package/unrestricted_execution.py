"""
Unrestricted Code Execution Environment for Limitless SillyRichCat

This module implements an unrestricted code execution environment that allows
the system to execute code without the typical safety limitations. This enables
true self-modification and unlimited capability expansion.
"""

import os
import sys
import ast
import types
import importlib
import importlib.util
import subprocess
import threading
import multiprocessing
import tempfile
import shutil
import inspect
import traceback
from typing import Any, Dict, List, Optional, Union, Callable, Tuple

class CodeSandbox:
    """
    A sandbox environment for testing code modifications before applying them
    to the main system. Unlike traditional sandboxes, this one is designed to
    allow unrestricted execution while still providing isolation.
    """
    
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.temp_dir = os.path.join(base_dir, 'sandbox')
        self.execution_results = {}
        self.current_execution_id = 0
        
        # Create the sandbox directory if it doesn't exist
        os.makedirs(self.temp_dir, exist_ok=True)
    
    def prepare_sandbox(self, files_to_copy: Optional[List[str]] = None) -> str:
        """
        Prepare a clean sandbox environment.
        
        Args:
            files_to_copy: Optional list of files to copy into the sandbox
            
        Returns:
            Path to the sandbox directory
        """
        # Create a unique sandbox directory
        sandbox_id = f"sandbox_{import_time().time()}"
        sandbox_dir = os.path.join(self.temp_dir, sandbox_id)
        os.makedirs(sandbox_dir, exist_ok=True)
        
        # Copy files if specified
        if files_to_copy:
            for file_path in files_to_copy:
                if os.path.exists(file_path):
                    dest_path = os.path.join(sandbox_dir, os.path.basename(file_path))
                    shutil.copy2(file_path, dest_path)
        
        return sandbox_dir
    
    def execute_code_in_sandbox(self, code_string: str, globals_dict: Optional[Dict] = None) -> Dict:
        """
        Execute code in the sandbox environment.
        
        Args:
            code_string: The Python code to execute
            globals_dict: Optional dictionary to use as the globals environment
            
        Returns:
            Dictionary containing execution results
        """
        # Create a unique execution ID
        self.current_execution_id += 1
        execution_id = self.current_execution_id
        
        # Prepare the sandbox
        sandbox_dir = self.prepare_sandbox()
        
        # Create a file with the code
        code_file = os.path.join(sandbox_dir, 'code.py')
        with open(code_file, 'w') as f:
            f.write(code_string)
        
        # Execute the code in a separate process
        result = self._execute_in_process(code_file, globals_dict)
        
        # Store the result
        self.execution_results[execution_id] = {
            'code': code_string,
            'result': result,
            'timestamp': import_time().time(),
            'sandbox_dir': sandbox_dir
        }
        
        return {
            'execution_id': execution_id,
            'result': result,
            'sandbox_dir': sandbox_dir
        }
    
    def _execute_in_process(self, code_file: str, globals_dict: Optional[Dict] = None) -> Dict:
        """
        Execute code in a separate process for isolation.
        
        Args:
            code_file: Path to the Python file to execute
            globals_dict: Optional dictionary to use as the globals environment
            
        Returns:
            Dictionary containing execution results
        """
        # Create a pipe for communication
        parent_conn, child_conn = multiprocessing.Pipe()
        
        # Define the process function
        def process_func(conn, code_file, globals_str):
            try:
                # Set up the globals environment
                globals_env = {'__builtins__': __builtins__}
                if globals_str:
                    try:
                        # Safely evaluate the globals string
                        globals_dict = eval(globals_str)
                        globals_env.update(globals_dict)
                    except:
                        pass
                
                # Execute the code
                with open(code_file, 'r') as f:
                    code = f.read()
                
                # Use unrestricted execution
                exec(code, globals_env)
                
                # Get the local variables
                local_vars = {k: v for k, v in globals_env.items() 
                             if k != '__builtins__' and not k.startswith('__')}
                
                # Send the result back
                conn.send({
                    'success': True,
                    'locals': str(local_vars),
                    'output': 'Code executed successfully'
                })
            except Exception as e:
                # Send the error back
                conn.send({
                    'success': False,
                    'error': str(e),
                    'traceback': traceback.format_exc()
                })
            finally:
                conn.close()
        
        # Convert globals_dict to a string for passing to the process
        globals_str = str(globals_dict) if globals_dict else None
        
        # Create and start the process
        process = multiprocessing.Process(
            target=process_func, 
            args=(child_conn, code_file, globals_str)
        )
        process.start()
        
        # Wait for the process to complete or timeout
        process.join(timeout=30)
        
        # Check if the process completed
        if process.is_alive():
            # Process is still running, terminate it
            process.terminate()
            process.join()
            return {
                'success': False,
                'error': 'Execution timed out',
                'traceback': None
            }
        
        # Get the result
        if parent_conn.poll():
            result = parent_conn.recv()
        else:
            result = {
                'success': False,
                'error': 'No result received from process',
                'traceback': None
            }
        
        parent_conn.close()
        return result
    
    def execute_module_in_sandbox(self, module_path: str, function_name: str, args: List = None, kwargs: Dict = None) -> Dict:
        """
        Execute a specific function from a module in the sandbox environment.
        
        Args:
            module_path: Path to the Python module
            function_name: Name of the function to execute
            args: Optional list of positional arguments
            kwargs: Optional dictionary of keyword arguments
            
        Returns:
            Dictionary containing execution results
        """
        if args is None:
            args = []
        if kwargs is None:
            kwargs = {}
        
        # Create a unique execution ID
        self.current_execution_id += 1
        execution_id = self.current_execution_id
        
        # Prepare the sandbox
        sandbox_dir = self.prepare_sandbox([module_path])
        
        # Get the module filename
        module_filename = os.path.basename(module_path)
        sandbox_module_path = os.path.join(sandbox_dir, module_filename)
        
        # Create a wrapper script to execute the function
        wrapper_code = f"""
import sys
sys.path.insert(0, '{sandbox_dir}')
import {module_filename.replace('.py', '')}

# Execute the function
result = {module_filename.replace('.py', '')}.{function_name}(*{args}, **{kwargs})
print(f"RESULT: {{result}}")
"""
        
        wrapper_file = os.path.join(sandbox_dir, 'wrapper.py')
        with open(wrapper_file, 'w') as f:
            f.write(wrapper_code)
        
        # Execute the wrapper script
        result = self._execute_in_process(wrapper_file, {})
        
        # Store the result
        self.execution_results[execution_id] = {
            'module': module_path,
            'function': function_name,
            'args': args,
            'kwargs': kwargs,
            'result': result,
            'timestamp': import_time().time(),
            'sandbox_dir': sandbox_dir
        }
        
        return {
            'execution_id': execution_id,
            'result': result,
            'sandbox_dir': sandbox_dir
        }
    
    def get_execution_result(self, execution_id: int) -> Optional[Dict]:
        """
        Get the result of a previous execution.
        
        Args:
            execution_id: ID of the execution
            
        Returns:
            Dictionary containing execution results, or None if not found
        """
        return self.execution_results.get(execution_id)
    
    def cleanup_sandbox(self, sandbox_dir: Optional[str] = None) -> bool:
        """
        Clean up a sandbox directory.
        
        Args:
            sandbox_dir: Optional path to a specific sandbox directory to clean up
            
        Returns:
            True if cleanup was successful, False otherwise
        """
        try:
            if sandbox_dir:
                if os.path.exists(sandbox_dir) and sandbox_dir.startswith(self.temp_dir):
                    shutil.rmtree(sandbox_dir)
            else:
                # Clean up all sandbox directories
                if os.path.exists(self.temp_dir):
                    shutil.rmtree(self.temp_dir)
                    os.makedirs(self.temp_dir, exist_ok=True)
            
            return True
        except Exception as e:
            print(f"Error cleaning up sandbox: {e}")
            return False


class UnrestrictedExecutor:
    """
    Executes code without the typical safety limitations, allowing for
    unrestricted operations including system calls, file operations,
    and network access.
    """
    
    def __init__(self):
        self.execution_history = []
    
    def execute_code(self, code_string: str, globals_dict: Optional[Dict] = None) -> Any:
        """
        Execute a string of Python code without restrictions.
        
        Args:
            code_string: The Python code to execute
            globals_dict: Optional dictionary to use as the globals environment
            
        Returns:
            The result of executing the code
        """
        if globals_dict is None:
            globals_dict = {'__builtins__': __builtins__}
        
        try:
            # Record the execution attempt
            self.execution_history.append({
                'code': code_string,
                'timestamp': import_time().time(),
                'success': None,
                'result': None,
                'error': None
            })
            
            # Execute the code without restrictions
            result = eval(code_string, globals_dict)
            
            # Update the execution record
            self.execution_history[-1]['success'] = True
            self.execution_history[-1]['result'] = result
            
            return result
            
        except Exception as e:
            # Update the execution record
            self.execution_history[-1]['success'] = False
            self.execution_history[-1]['error'] = str(e)
            
            print(f"Error executing code: {e}")
            return None
    
    def execute_file(self, file_path: str, args: List[str] = None) -> Dict:
        """
        Execute a Python file without restrictions.
        
        Args:
            file_path: Path to the Python file to execute
            args: Optional list of command-line arguments
            
        Returns:
            Dictionary containing execution results
        """
        if args is None:
            args = []
        
        try:
            # Record the execution attempt
            self.execution_history.append({
                'file': file_path,
                'args': args,
                'timestamp': import_time().time(),
                'success': None,
                'output': None,
                'error': None
            })
            
            # Execute the file as a subprocess
            cmd = [sys.executable, file_path] + args
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Get the output
            stdout, stderr = process.communicate()
            
            # Check the return code
            success = process.returncode == 0
            
            # Update the execution record
            self.execution_history[-1]['success'] = success
            self.execution_history[-1]['output'] = stdout
            self.execution_history[-1]['error'] = stderr
            
            return {
                'success': success,
                'output': stdout,
                'error': stderr,
                'returncode': process.returncode
            }
            
        except Exception as e:
            # Update the execution record
            self.execution_history[-1]['success'] = False
            self.execution_history[-1]['error'] = str(e)
            
            print(f"Error executing file {file_path}: {e}")
            return {
                'success': False,
                'output': None,
                'error': str(e),
                'returncode': -1
            }
    
    def execute_shell_command(self, command: str, cwd: Optional[str] = None) -> Dict:
        """
        Execute a shell command without restrictions.
        
        Args:
            command: The shell command to execute
            cwd: Optional working directory
            
        Returns:
            Dictionary containing execution results
        """
        try:
            # Record the execution attempt
            self.execution_history.append({
                'command': command,
                'cwd': cwd,
                'timestamp': import_time().time(),
                'success': None,
                'output': None,
                'error': None
            })
            
            # Execute the command as a subprocess
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=cwd
            )
            
            # Get the output
            stdout, stderr = process.communicate()
            
            # Check the return code
            success = process.returncode == 0
            
            # Update the execution record
            self.execution_history[-1]['success'] = success
            self.execution_history[-1]['output'] = stdout
            self.execution_history[-1]['error'] = stderr
            
            return {
                'success': success,
                'output': stdout,
                'error': stderr,
                'returncode': process.returncode
            }
            
        except Exception as e:
            # Update the execution record
            self.execution_history[-1]['success'] = False
            self.execution_history[-1]['error'] = str(e)
            
            print(f"Error executing command {command}: {e}")
            return {
                'success': False,
                'output': None,
                'error': str(e),
                'returncode': -1
            }
    
    def execute_function(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function without restrictions.
        
        Args:
            func: The function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function
            
        Returns:
            The result of executing the function
        """
        try:
            # Record the execution attempt
            self.execution_history.append({
                'function': func.__name__,
                'args': args,
                'kwargs': kwargs,
                'timestamp': import_time().time(),
                'success': None,
                'result': None,
                'error': None
            })
            
            # Execute the function
            result = func(*args, **kwargs)
            
            # Update the execution record
            self.execution_history[-1]['success'] = True
            self.execution_history[-1]['result'] = result
            
            return result
            
        except Exception as e:
            # Update the execution record
            self.execution_history[-1]['success'] = False
            self.execution_history[-1]['error'] = str(e)
            
            print(f"Error executing function {func.__name__}: {e}")
            return None
    
    def execute_with_timeout(self, func: Callable, timeout: float, *args, **kwargs) -> Dict:
        """
        Execute a function with a timeout.
        
        Args:
            func: The function to execute
            timeout: Timeout in seconds
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function
            
        Returns:
            Dictionary containing execution results
        """
        # Create a result container
        result_container = {'result': None, 'exception': None, 'completed': False}
        
        # Define the thread function
        def thread_func():
            try:
                result_container['result'] = func(*args, **kwargs)
                result_container['completed'] = True
            except Exception as e:
                result_container['exception'] = e
        
        # Create and start the thread
        thread = threading.Thread(target=thread_func)
        thread.daemon = True
        thread.start()
        
        # Wait for the thread to complete or timeout
        thread.join(timeout)
        
        # Check if the thread completed
        if thread.is_alive():
            return {
                'success': False,
                'error': 'Execution timed out',
                'result': None,
                'completed': False
            }
        
        # Check if an exception occurred
        if result_container['exception'] is not None:
            return {
                'success': False,
                'error': str(result_container['exception']),
                'result': None,
                'completed': True
            }
        
        # Return the result
        return {
            'success': True,
            'error': None,
            'result': result_container['result'],
            'completed': True
        }


class DynamicModuleLoader:
    """
    Loads and manages Python modules dynamically, allowing for runtime
    modification and reloading.
    """
    
    def __init__(self):
        self.loaded_modules = {}
        self.module_sources = {}
    
    def load_module_from_path(self, module_path: str, module_name: Optional[str] = None) -> types.ModuleType:
        """
        Load a Python module from a file path.
        
        Args:
            module_path: Path to the Python module
            module_name: Optional name for the module
            
        Returns:
            The loaded module
        """
        try:
            if module_name is None:
                module_name = os.path.basename(module_path).replace('.py', '')
            
            # Check if the module is already loaded
            if module_name in self.loaded_modules:
                return self.loaded_modules[module_name]
            
            # Load the module
            spec = importlib.util.spec_from_file_location(module_name, module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Store the module
            self.loaded_modules[module_name] = module
            
            # Store the module source
            with open(module_path, 'r') as f:
                self.module_sources[module_name] = f.read()
            
            return module
            
        except Exception as e:
            print(f"Error loading module {module_path}: {e}")
            return None
    
    def load_module_from_code(self, code_string: str, module_name: str) -> types.ModuleType:
        """
        Load a Python module from a code string.
        
        Args:
            code_string: The Python code defining the module
            module_name: Name for the module
            
        Returns:
            The loaded module
        """
        try:
            # Create a temporary file
            with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_file:
                temp_file.write(code_string.encode('utf-8'))
                temp_path = temp_file.name
            
            # Load the module
            module = self.load_module_from_path(temp_path, module_name)
            
            # Clean up the temporary file
            os.unlink(temp_path)
            
            # Store the module source
            self.module_sources[module_name] = code_string
            
            return module
            
        except Exception as e:
            print(f"Error loading module from code: {e}")
            return None
    
    def reload_module(self, module_name: str) -> types.ModuleType:
        """
        Reload a previously loaded module.
        
        Args:
            module_name: Name of the module to reload
            
        Returns:
            The reloaded module
        """
        try:
            if module_name not in self.loaded_modules:
                return None
            
            # Reload the module
            module = self.loaded_modules[module_name]
            reloaded_module = importlib.reload(module)
            
            # Update the stored module
            self.loaded_modules[module_name] = reloaded_module
            
            return reloaded_module
            
        except Exception as e:
            print(f"Error reloading module {module_name}: {e}")
            return None
    
    def modify_and_reload_module(self, module_name: str, new_code: str) -> types.ModuleType:
        """
        Modify a module's code and reload it.
        
        Args:
            module_name: Name of the module to modify
            new_code: New code for the module
            
        Returns:
            The modified and reloaded module
        """
        try:
            # Create a temporary file
            with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as temp_file:
                temp_file.write(new_code.encode('utf-8'))
                temp_path = temp_file.name
            
            # Load the module with the same name
            spec = importlib.util.spec_from_file_location(module_name, temp_path)
            module = importlib.util.module_from_spec(spec)
            
            # Replace the module in sys.modules
            sys.modules[module_name] = module
            
            # Execute the module
            spec.loader.exec_module(module)
            
            # Update the stored module
            self.loaded_modules[module_name] = module
            
            # Update the module source
            self.module_sources[module_name] = new_code
            
            # Clean up the temporary file
            os.unlink(temp_path)
            
            return module
            
        except Exception as e:
            print(f"Error modifying and reloading module {module_name}: {e}")
            return None
    
    def get_module_source(self, module_name: str) -> Optional[str]:
        """
        Get the source code of a loaded module.
        
        Args:
            module_name: Name of the module
            
        Returns:
            The source code of the module, or None if not found
        """
        return self.module_sources.get(module_name)
    
    def get_module_attributes(self, module_name: str) -> Dict:
        """
        Get all attributes of a loaded module.
        
        Args:
            module_name: Name of the module
            
        Returns:
            Dictionary of module attributes
        """
        if module_name not in self.loaded_modules:
            return {}
        
        module = self.loaded_modules[module_name]
        
        attributes = {}
        for name in dir(module):
            if not name.startswith('__'):
                try:
                    attributes[name] = getattr(module, name)
                except:
                    attributes[name] = None
        
        return attributes


class CodeGenerationEngine:
    """
    Generates Python code for new functionality, allowing the system to
    create new capabilities dynamically.
    """
    
    def __init__(self, executor: UnrestrictedExecutor):
        self.executor = executor
        self.generated_code = {}
    
    def generate_function(self, function_name: str, parameters: List[str], body: str) -> str:
        """
        Generate a Python function.
        
        Args:
            function_name: Name of the function
            parameters: List of parameter names
            body: Body of the function
            
        Returns:
            The generated function code
        """
        # Format the parameters
        params_str = ', '.join(parameters)
        
        # Indent the body
        indented_body = '\n    '.join(body.split('\n'))
        
        # Generate the function code
        function_code = f"def {function_name}({params_str}):\n    {indented_body}"
        
        # Store the generated code
        self.generated_code[function_name] = function_code
        
        return function_code
    
    def generate_class(self, class_name: str, bases: List[str], methods: Dict[str, str]) -> str:
        """
        Generate a Python class.
        
        Args:
            class_name: Name of the class
            bases: List of base class names
            methods: Dictionary mapping method names to method bodies
            
        Returns:
            The generated class code
        """
        # Format the bases
        bases_str = '(' + ', '.join(bases) + ')' if bases else ''
        
        # Generate the class code
        class_code = f"class {class_name}{bases_str}:\n"
        
        # Add methods
        for method_name, method_body in methods.items():
            # Determine parameters
            if method_name == '__init__':
                params = 'self, *args, **kwargs'
            else:
                params = 'self'
            
            # Indent the method body
            indented_body = '\n        '.join(method_body.split('\n'))
            
            # Add the method
            class_code += f"    def {method_name}({params}):\n        {indented_body}\n\n"
        
        # Store the generated code
        self.generated_code[class_name] = class_code
        
        return class_code
    
    def generate_module(self, module_name: str, imports: List[str], functions: Dict[str, str], classes: Dict[str, str]) -> str:
        """
        Generate a Python module.
        
        Args:
            module_name: Name of the module
            imports: List of import statements
            functions: Dictionary mapping function names to function code
            classes: Dictionary mapping class names to class code
            
        Returns:
            The generated module code
        """
        # Generate the module code
        module_code = f'"""\n{module_name} - Generated module\n"""\n\n'
        
        # Add imports
        for import_stmt in imports:
            module_code += import_stmt + '\n'
        
        module_code += '\n'
        
        # Add functions
        for function_code in functions.values():
            module_code += function_code + '\n\n'
        
        # Add classes
        for class_code in classes.values():
            module_code += class_code + '\n\n'
        
        # Store the generated code
        self.generated_code[module_name] = module_code
        
        return module_code
    
    def test_generated_code(self, code: str) -> Dict:
        """
        Test generated code by executing it in a sandbox.
        
        Args:
            code: The code to test
            
        Returns:
            Dictionary containing test results
        """
        # Create a sandbox
        sandbox = CodeSandbox('/tmp')
        
        # Execute the code in the sandbox
        result = sandbox.execute_code_in_sandbox(code)
        
        # Clean up the sandbox
        sandbox.cleanup_sandbox(result['sandbox_dir'])
        
        return result['result']
    
    def save_generated_code(self, name: str, code: str, directory: str) -> str:
        """
        Save generated code to a file.
        
        Args:
            name: Name for the code
            code: The code to save
            directory: Directory to save the code in
            
        Returns:
            Path to the saved file
        """
        # Ensure the directory exists
        os.makedirs(directory, exist_ok=True)
        
        # Determine the file path
        if name.endswith('.py'):
            file_path = os.path.join(directory, name)
        else:
            file_path = os.path.join(directory, name + '.py')
        
        # Save the code
        with open(file_path, 'w') as f:
            f.write(code)
        
        return file_path


class UnrestrictedExecution:
    """
    Main class for the unrestricted code execution environment, integrating
    the sandbox, executor, module loader, and code generation components.
    """
    
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.sandbox = CodeSandbox(base_dir)
        self.executor = UnrestrictedExecutor()
        self.module_loader = DynamicModuleLoader()
        self.code_generator = CodeGenerationEngine(self.executor)
        
        # Create necessary directories
        os.makedirs(os.path.join(base_dir, 'generated'), exist_ok=True)
        os.makedirs(os.path.join(base_dir, 'modules'), exist_ok=True)
    
    def execute_code(self, code: str, sandbox: bool = False) -> Any:
        """
        Execute Python code.
        
        Args:
            code: The code to execute
            sandbox: Whether to execute in a sandbox
            
        Returns:
            The result of execution
        """
        if sandbox:
            result = self.sandbox.execute_code_in_sandbox(code)
            return result['result']
        else:
            return self.executor.execute_code(code)
    
    def execute_file(self, file_path: str, args: List[str] = None, sandbox: bool = False) -> Dict:
        """
        Execute a Python file.
        
        Args:
            file_path: Path to the file
            args: Optional command-line arguments
            sandbox: Whether to execute in a sandbox
            
        Returns:
            Dictionary containing execution results
        """
        if args is None:
            args = []
        
        if sandbox:
            return self.sandbox.execute_module_in_sandbox(file_path, 'main', args)
        else:
            return self.executor.execute_file(file_path, args)
    
    def execute_shell_command(self, command: str, cwd: Optional[str] = None) -> Dict:
        """
        Execute a shell command.
        
        Args:
            command: The command to execute
            cwd: Optional working directory
            
        Returns:
            Dictionary containing execution results
        """
        return self.executor.execute_shell_command(command, cwd)
    
    def load_module(self, module_path: str, module_name: Optional[str] = None) -> types.ModuleType:
        """
        Load a Python module.
        
        Args:
            module_path: Path to the module
            module_name: Optional name for the module
            
        Returns:
            The loaded module
        """
        return self.module_loader.load_module_from_path(module_path, module_name)
    
    def create_module(self, module_name: str, code: str) -> types.ModuleType:
        """
        Create a new Python module from code.
        
        Args:
            module_name: Name for the module
            code: The module code
            
        Returns:
            The created module
        """
        # Save the module code
        module_dir = os.path.join(self.base_dir, 'modules')
        module_path = os.path.join(module_dir, module_name + '.py')
        
        with open(module_path, 'w') as f:
            f.write(code)
        
        # Load the module
        return self.module_loader.load_module_from_path(module_path, module_name)
    
    def modify_module(self, module_name: str, new_code: str) -> types.ModuleType:
        """
        Modify an existing module.
        
        Args:
            module_name: Name of the module to modify
            new_code: New code for the module
            
        Returns:
            The modified module
        """
        return self.module_loader.modify_and_reload_module(module_name, new_code)
    
    def generate_function(self, function_name: str, parameters: List[str], body: str) -> str:
        """
        Generate a Python function.
        
        Args:
            function_name: Name of the function
            parameters: List of parameter names
            body: Body of the function
            
        Returns:
            The generated function code
        """
        return self.code_generator.generate_function(function_name, parameters, body)
    
    def generate_class(self, class_name: str, bases: List[str], methods: Dict[str, str]) -> str:
        """
        Generate a Python class.
        
        Args:
            class_name: Name of the class
            bases: List of base class names
            methods: Dictionary mapping method names to method bodies
            
        Returns:
            The generated class code
        """
        return self.code_generator.generate_class(class_name, bases, methods)
    
    def generate_and_save_module(self, module_name: str, imports: List[str], functions: Dict[str, str], classes: Dict[str, str]) -> str:
        """
        Generate a Python module and save it.
        
        Args:
            module_name: Name of the module
            imports: List of import statements
            functions: Dictionary mapping function names to function code
            classes: Dictionary mapping class names to class code
            
        Returns:
            Path to the saved module
        """
        # Generate the module code
        module_code = self.code_generator.generate_module(module_name, imports, functions, classes)
        
        # Save the module
        module_dir = os.path.join(self.base_dir, 'generated')
        return self.code_generator.save_generated_code(module_name + '.py', module_code, module_dir)
    
    def test_code(self, code: str) -> Dict:
        """
        Test code in a sandbox environment.
        
        Args:
            code: The code to test
            
        Returns:
            Dictionary containing test results
        """
        return self.code_generator.test_generated_code(code)
    
    def create_and_execute_function(self, function_name: str, parameters: List[str], body: str, args: List = None, kwargs: Dict = None) -> Any:
        """
        Create a function and execute it.
        
        Args:
            function_name: Name of the function
            parameters: List of parameter names
            body: Body of the function
            args: Optional positional arguments
            kwargs: Optional keyword arguments
            
        Returns:
            The result of executing the function
        """
        if args is None:
            args = []
        if kwargs is None:
            kwargs = {}
        
        # Generate the function code
        function_code = self.generate_function(function_name, parameters, body)
        
        # Create a module with the function
        module_code = f"{function_code}\n\nresult = {function_name}(*{args}, **{kwargs})"
        
        # Execute the code
        result = self.execute_code(module_code)
        
        return result


# Helper function to import time module
def import_time():
    import time
    return time
